# Fixed follow-up protocol (Refs #1452)

Baseline is immediate pre-refactor published 9732747e47fc549960256af9d4516644badfda1e,
compiled here before edits. Candidate is frozen after helper extraction. Dependencies,
ordered classpaths and path lengths are symmetric: before versus after_. No original
13f baseline or other source checkout is used.

Exactly 4 ABBA blocks (16 fresh JVMs), each with insertAsc4096, insertDesc4096,
insertDesc50000, commitDesc4096, commitDesc50000. Unchanged FinalHOTBenchmark and
HotBenchmarkFixture from the task proof. Each case gets 30 seconds real warmup,
50 JMH warmup batches, 36 retained measurements. Default asynchronous C2, CPU0,
heavy.sh with the inherited-lock exclusive-window protocol. No adaptive reruns,
no sample removal, no tuning after results. Stop if less than 60 GiB remains or
before the public cutoff 2026-11-19T02:30Z. All JVM/Gradle/javap commands use heavy.sh.

Decision: mean block-log-ratio point <= +1%, lower 95% log-ratio bound <= 0,
timed GC = 0. Four block contrasts use Student t critical 3.182446305284263 (df3).
Report process-wide commit and caller-thread insert allocation separately from
unchanged exact fold graphs, zero workspace/refusal, and pinned publication budgets.

# Combined final gate

4 ABBA blocks per case;16 fresh JVMs;five cases. Fixed95% block-log-ratio t interval,df3. All36 measured samples retained,30s real warmup plus50 JMH warmup batches. Commit allocation uses JVM-wide allocated bytes because commit runs on virtual/background threads; insert allocation uses caller-thread bytes. GC-profiler fixture totals are reported separately.

| Case | Units | Before | After | Paired change |95% interval| Bytes before/after |Median paired byte delta|Timed GC|Gate|
|---|---|---:|---:|---:|---|---|---:|---:|---|
|insertAsc4096|ns/key|1018.3827|1005.2103|-1.304%|[-6.248%,+3.901%]|584.946289/584.966064|+0.008301|0|PASS|
|insertDesc4096|ns/key|1262.0371|1231.6227|-2.387%|[-7.679%,+3.207%]|618.293945/618.298828|+0.001953|0|PASS|
|insertDesc50000|ns/key|1626.4909|1613.9221|-0.754%|[-3.903%,+2.499%]|812.245520/812.251040|+0.000320|0|PASS|
|commitDesc4096|ms/commit|4.6881|4.7702|+1.466%|[-11.714%,+16.613%]|241063.250000/241143.333333|+150.500000|0|HOLD|
|commitDesc50000|ms/commit|15.2528|15.8635|+3.417%|[-10.397%,+19.361%]|253183.583333/253307.888889|+112.055556|0|HOLD|

Overall: HOLD

Profiler fixture-inclusive allocation and GC totals:
- insertAsc4096: 671.450012->671.472683 B/key; all GC972,forced requests576,timed0.
- insertDesc4096: 691.433417->691.445041 B/key; all GC957,forced requests576,timed0.
- insertDesc50000: 818.355743->818.363415 B/key; all GC998,forced requests576,timed0.
- commitDesc4096: 3287703.138889->3288075.944444 B/commit fixture; all GC848,forced requests576,timed0.
- commitDesc50000: 41307209.777778->41307078.055556 B/commit fixture; all GC989,forced requests576,timed0.

from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
p = Path(__file__).resolve().parent
repo = Path("/home/johannes/.treehouse/sirix-cdde48/12/sirix")
status = Path('/home/johannes/IdeaProjects/firstmate/state/sirix-hot-lost-spine-fix.status')
ledger = '/home/johannes/IdeaProjects/firstmate/bin/fm-fleet-ledger.sh'
config = '/home/johannes/IdeaProjects/firstmate/config'
def notify(message):
    epoch = subprocess.check_output(['date', '+%s'], text=True).strip()
    with status.open('a') as output:
        output.write('resolved [at=' + epoch + ']: local24-block experiment driver returned; see outcome file\n')
        output.write('working [at=' + epoch + ']: ' + message + '\n')
    subprocess.run([ledger, 'appended', config, str(status)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
result = {'started': time.time(), 'protocol_sha256': hashlib.sha256((p/'protocol-24-blocks.md').read_bytes()).hexdigest()}
try:
    assert 'BUILD SUCCESSFUL' in (p/'focused.log').read_text()
    assert 'BUILD SUCCESSFUL' in (p/'budgets.log').read_text()
    assert (p/'shape/complete.json').exists()
    assert not (p/'timing').exists(), 'No repeat or overwrite of a started experiment'
    identity = json.loads((p/'local-compiled-identity.json').read_text())
    assert not identity['classMismatches'] and not identity['sourceMismatches']
    completed = subprocess.run(['bash', str(p/'run-24-blocks.sh')], cwd=repo, timeout=25300, check=False)
    result['returncode'] = completed.returncode
    if completed.returncode != 0:
        result['decision'] = 'INCOMPLETE_HOLD'
    else:
        subprocess.run(['python3', str(p/'analyze-timing.py')], cwd=repo, check=True)
        rows = json.loads((p/'timing/summary.json').read_text())
        result['decision'] = 'PASS' if all(row['pass'] for row in rows) else 'HOLD'
except Exception as failure:
    result['decision'] = 'INCOMPLETE_HOLD'
    result['error'] = str(failure)
finally:
    result['finished'] = time.time()
    (p/'experiment-outcome.json').write_text(json.dumps(result, indent=2) + '\n')
    notify('local24ABBA ' + result['decision'] + '; no commit or push; worker must inspect full evidence at ' + str(p/'experiment-outcome.json'))
print(json.dumps(result, indent=2), flush=True)

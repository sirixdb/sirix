"""Run inside heavy.sh; upgrade this job's inherited timing lock, never nest the wrappers.

Close admission with the existing gate, then convert OUR inherited open-file-description
from shared to exclusive. Other heavy jobs drain; the outer flock and this process share
the same lock description, so there is no self-deadlock. Keep gate and lock through the
bounded command. No daemon or shared wrapper is changed. A separate flock on the timing
path would deadlock against our outer heavy.sh process and is deliberately not used.
"""
import fcntl
import json
import shutil
import os
from pathlib import Path
import subprocess
import sys
import time

lock_path = os.environ.get('SPINE_TEST_TIMING_LOCK', '/var/tmp/fm-timing.lock')
gate_path = os.environ.get('SPINE_TEST_TIMING_GATE', '/var/tmp/fm-timing.gate')
lock_fd = None
for name in os.listdir('/proc/self/fd'):
    try:
        if os.readlink('/proc/self/fd/' + name) == lock_path:
            lock_fd = int(name)
            break
    except FileNotFoundError:
        pass
if lock_fd is None:
    raise SystemExit('Refusing: launch through heavy.sh; inherited timing lock missing')
gate_fd = os.open(gate_path, os.O_RDWR | os.O_CREAT, 0o600)
deadline = time.monotonic() + 240
for fd in (gate_fd, lock_fd):
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic() >= deadline:
                raise SystemExit('Exclusive timing admission timed out; no benchmark started')
            time.sleep(0.2)
# Three fresh observations after earlier timing windows have released their locks.
quiet_deadline = time.monotonic() + 1800
quiet_count = 0
admission = Path(__file__).parent / 'quiet-admission-24.jsonl'
while quiet_count < 3:
    loads = os.getloadavg()
    free = shutil.disk_usage(Path(__file__).parent).free
    acceptable = loads[0] < 4 and loads[1] < 6 and free >= 60 * 1024**3
    quiet_count = quiet_count + 1 if acceptable else 0
    with admission.open('a') as record:
        record.write(json.dumps({'at': time.time(), 'load': loads, 'free_bytes': free, 'consecutive': quiet_count}) + '\n')
    if time.monotonic() >= quiet_deadline:
        raise SystemExit('Quiet admission timed out; no benchmark started')
    if quiet_count < 3:
        time.sleep(30)
print('EXCLUSIVE TIMING START', time.time(), 'cpu=0', flush=True)
try:
    result = subprocess.run(['taskset', '-c', '0', *sys.argv[1:]], timeout=21600)
    raise SystemExit(result.returncode)
finally:
    print('EXCLUSIVE TIMING END', time.time(), flush=True)
    os.close(gate_fd)

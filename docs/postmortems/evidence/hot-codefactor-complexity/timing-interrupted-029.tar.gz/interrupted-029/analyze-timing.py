from pathlib import Path
import csv,json,math,statistics as st
p=Path(__file__).parent
out=p/'timing'
BLOCKS=24
T_CRITICAL=2.0686576104190406
CASES={'insertAsc4096':4096,'insertDesc4096':4096,'insertDesc50000':50000,'commitDesc4096':1,'commitDesc50000':1}
rows=[];blocks=[]
for case,alloc_scale in CASES.items():
 time_scale=1_000_000 if case.startswith('commit') else alloc_scale
 unit='ms/commit' if case.startswith('commit') else 'ns/key'
 contrasts=[];deltas=[];before=[];after=[];bbytes=[];abytes=[];bprof=[];aprof=[];timed_gc=0;timed_gc_ms=0;total_gc=0
 for block in range(BLOCKS):
  scores=[];allocs=[]
  for position,arm in enumerate(['before','after','after','before']):
   prefix=out/f'{block:02d}-{position}-{arm}'
   data=json.loads(Path(str(prefix)+'.json').read_text())
   matches=[x for x in data if x['params']=={'caseName':case}];assert len(matches)==1
   result=matches[0];assert result['warmupIterations']==50 and result['measurementIterations']==36;metric=result['primaryMetric'];assert metric['scoreUnit']=='ns/op'
   raw=metric['rawData'];assert len(raw)==1 and len(raw[0])==36
   score=metric['score']/time_scale
   assert math.isclose(score,st.mean(raw[0])/time_scale,rel_tol=1e-10)
   counters=list(csv.DictReader(Path(str(prefix)+'-'+case+'-counters.csv').open()));assert len(counters)==36
   assert all(int(x['allocated_bytes'])>=0 for x in counters)
   allocated=st.mean(int(x['allocated_bytes']) for x in counters)/alloc_scale
   timed_gc+=sum(int(x['timed_gc_count']) for x in counters)
   timed_gc_ms+=sum(int(x['timed_gc_ms']) for x in counters)
   warm=dict(x.split('=') for x in Path(str(prefix)+'-'+case+'-warmup.txt').read_text().split())
   assert warm['allocation_counter']==('all_threads' if case.startswith('commit') else 'caller_thread')
   assert int(warm['nanos'])>=30_000_000_000 and int(warm['forced_measurement_gc_requests'])==36
   total_gc+=int(warm['all_gc_count'])
   scores.append(score);allocs.append(allocated)
   (before if arm=='before' else after).append(score)
   (bbytes if arm=='before' else abytes).append(allocated)
   (bprof if arm=='before' else aprof).append(result['secondaryMetrics']['gc.alloc.rate.norm']['score']/alloc_scale)
  contrast=(math.log(scores[1]/scores[0])+math.log(scores[2]/scores[3]))/2
  delta=(allocs[1]+allocs[2]-allocs[0]-allocs[3])/2
  contrasts.append(contrast);deltas.append(delta)
  blocks.append({'case':case,'block':block,'log_ratio':contrast,'allocation_delta':delta,'ABBA_scores':scores,'ABBA_bytes':allocs})
 mean=st.mean(contrasts);half=T_CRITICAL*st.stdev(contrasts)/math.sqrt(BLOCKS)
 point=math.expm1(mean);lower=mean-half;upper=mean+half;delta=st.median(deltas)
 latency_pass=lower<=0 and point<=.01;allocation_pass=True # Exact subsystem budgets are checked separately.
 rows.append({'case':case,'unit':unit,'before':st.mean(before),'after':st.mean(after),'point_pct':100*point,'lower95_pct':100*math.expm1(lower),'upper95_pct':100*math.expm1(upper),'before_bytes':st.mean(bbytes),'after_bytes':st.mean(abytes),'median_paired_bytes_delta':delta,'before_profiler_bytes':st.mean(bprof),'after_profiler_bytes':st.mean(aprof),'timed_gc_count':timed_gc,'timed_gc_ms':timed_gc_ms,'all_gc_count':total_gc,'forced_requests':BLOCKS*4*36,'latency_pass':latency_pass,'allocation_pass':allocation_pass,'pass':latency_pass and allocation_pass and timed_gc==0})
(out/'paired-blocks.json').write_text(json.dumps(blocks,indent=2));(out/'summary.json').write_text(json.dumps(rows,indent=2))
lines=['# Combined final gate','', '24 ABBA blocks per case;96 fresh JVMs;five cases. Fixed95% block-log-ratio t interval,df23. All36 measured samples retained,30s real warmup plus50 JMH warmup batches. Commit allocation uses JVM-wide allocated bytes because commit runs on virtual/background threads; insert allocation uses caller-thread bytes. GC-profiler fixture totals are reported separately.','', '| Case | Units | Before | After | Paired change |95% interval| Bytes before/after |Median paired byte delta|Timed GC|Gate|','|---|---|---:|---:|---:|---|---|---:|---:|---|']
for x in rows:
 lines.append(f"|{x['case']}|{x['unit']}|{x['before']:.4f}|{x['after']:.4f}|{x['point_pct']:+.3f}%|[{x['lower95_pct']:+.3f}%,{x['upper95_pct']:+.3f}%]|{x['before_bytes']:.6f}/{x['after_bytes']:.6f}|{x['median_paired_bytes_delta']:+.6f}|{x['timed_gc_count']}|{'PASS' if x['pass'] else 'HOLD'}|")
lines+=['','Overall: '+('PASS' if all(x['pass'] for x in rows) else 'HOLD'),'','Profiler fixture-inclusive allocation and GC totals:']
for x in rows:lines.append(f"- {x['case']}: {x['before_profiler_bytes']:.6f}->{x['after_profiler_bytes']:.6f} B/{'commit fixture' if x['case'].startswith('commit') else 'key'}; all GC{x['all_gc_count']},forced requests{x['forced_requests']},timed{x['timed_gc_count']}.")
(p/'timing-report.md').write_text('\n'.join(lines)+'\n');print('\n'.join(lines))

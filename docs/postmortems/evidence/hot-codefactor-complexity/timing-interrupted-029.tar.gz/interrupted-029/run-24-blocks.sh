#!/usr/bin/env bash
set -euo pipefail
exec timeout 25200 /home/johannes/IdeaProjects/firstmate/data/tools/heavy.sh python3 '/home/johannes/IdeaProjects/firstmate/data/sirix-hot-lost-spine-fix/local-codefactor/inside-heavy-hft-replication-timing.py' python3 '/home/johannes/IdeaProjects/firstmate/data/sirix-hot-lost-spine-fix/local-codefactor/run-timing24.py' timing

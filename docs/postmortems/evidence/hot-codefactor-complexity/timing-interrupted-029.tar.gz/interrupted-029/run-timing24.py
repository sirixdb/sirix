from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,time,sys
p=Path(__file__).resolve().parent
mode=sys.argv[1];assert mode == 'timing';out=p/mode;out.mkdir(exist_ok=False)
assert len(str(p/'before'))==len(str(p/'after_'))
base=json.loads((p/'dependencies.json').read_text())
production=Path("/home/johannes/.no-mistakes/worktrees/41ebe26a67ec/01M7RATAT5RSTNS628WHAD4B1X/bundles/sirix-core/build/classes/java/main")
def classpath(arm):
 return ':'.join([str(p/'classes'),str(p/('before' if arm=='before' else 'after_')),*[x for x in base if x!=str(production)]])
audit={arm:classpath(arm).split(':') for arm in ['before','after']}
assert len(audit['before'])==len(audit['after'])
assert [(i,a,b) for i,(a,b) in enumerate(zip(audit['before'],audit['after'])) if a!=b]==[(1,str(p/'before'),str(p/'after_'))]
assert all(len(x)==len(set(x)) for x in audit.values())
(out/'classpath-audit.json').write_text(json.dumps(audit,indent=2))
def hashes():
 files=[f for arm in ['before','after_','classes','shared-runtime'] for f in sorted((p/arm).rglob('*')) if f.is_file()]
 result = {str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
 local_repo = Path("/home/johannes/.treehouse/sirix-cdde48/12/sirix")
 result.update({'local-source/'+str(f.relative_to(local_repo)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((local_repo/'bundles/sirix-core/src/main/java').rglob('*.java'))})
 return result
frozen=hashes();(out/'sha256.json').write_text(json.dumps(frozen,indent=2))
flags=['--enable-preview','--add-modules=jdk.incubator.vector','--enable-native-access=ALL-UNNAMED','-Xms2g','-Xmx2g','-XX:MaxDirectMemorySize=1g','-XX:-UseJVMCICompiler','-Dsirix.allocator.maxSize=1073741824','-Dsirix.hotLookupCache.maxEntries=0','-Djava.io.tmpdir='+str(p/'tmp'),'-Dlogback.configurationFile='+str(p/'logback-benchmark.xml')]
# Local validation only; publication remains forbidden until 17:30 Berlin.
cutoff=time.time()+21600
sequence=[(b,i,a) for b in range(24) for i,a in enumerate(['before','after','after','before'])] if mode=='timing' else [(0,i,a) for i,a in enumerate(['before','after'])]
for block,position,arm in sequence:
 assert shutil.disk_usage(p).free>=60*1024**3,'60 GiB disk floor'
 assert hashes()==frozen,'Frozen bytecode changed'
 if mode=='timing' and time.time()+600>=cutoff:raise RuntimeError('Cannot complete next JVM before cutoff; HOLD')
 stem=out/f'{block:02d}-{position}-{arm}'
 if mode=='timing':
  cmd=['java',*flags,'-Dspine.output='+str(stem),'-cp',classpath(arm),'org.openjdk.jmh.Main','^io.sirix.index.hot.FinalHOTBenchmark.operation$','-f','0','-t','1','-foe','true','-prof','gc','-wi','50','-i','36','-rf','json','-rff',str(stem)+'.json','-p','caseName=insertAsc4096,insertDesc4096,insertDesc50000,commitDesc4096,commitDesc50000']
 elif mode=='shape':
  methods=['io.sirix.access.trx.page.NodeStorageEngineWriter::commit','io.sirix.access.trx.page.NodeStorageEngineWriter::commitUnloggedReference','io.sirix.access.trx.page.NodeStorageEngineWriter::resolveClosedCommitReference','io.sirix.index.hot.HOTIncrementalInsert::prepareCompatibleChild','io.sirix.index.hot.HOTIncrementalInsert::isChildBelowParentPath','io.sirix.index.hot.HOTIncrementalInsert::mergeDiscriminativeBits','io.sirix.index.hot.HOTCommitNormalizer::normalize','io.sirix.index.hot.HOTCommitNormalizer::enterDirtySpine','io.sirix.index.hot.HOTCommitNormalizer::normalizeChildren','io.sirix.index.hot.HOTCommitNormalizer::materializeFold','io.sirix.index.hot.HOTCommitNormalizer::repairHeight']
  diagnostics=['-Xbatch','-XX:+UnlockDiagnosticVMOptions','-XX:+PrintCompilation']
  for method in methods:diagnostics+=['-XX:CompileCommand=print,'+method,'-XX:CompileCommand=PrintInlining,'+method]
  cmd=['taskset','-c','0','java',*flags,*diagnostics,'-Dspine.output='+str(stem),'-cp',classpath(arm),'org.openjdk.jmh.Main','^io.sirix.index.hot.FinalHOTBenchmark.operation$','-f','0','-t','1','-foe','true','-wi','50','-i','1','-rf','json','-rff',str(stem)+'.json','-p','caseName=insertAsc4096,insertDesc4096,insertDesc50000,commitDesc4096,commitDesc50000']
 else:raise ValueError(mode)
 Path(str(stem)+'-command.json').write_text(json.dumps(cmd,indent=2))
 print('START',stem.name,time.time(),flush=True)
 with Path(str(stem)+'.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600,check=True)
 if mode=='shape':
  kernel=['taskset','-c','0','java',*flags,*diagnostics,'-cp',classpath(arm),'io.sirix.index.hot.KernelCompiledShape']
  Path(str(stem)+'-kernel-command.json').write_text(json.dumps(kernel,indent=2))
  with Path(str(stem)+'-kernel.log').open('w') as log:subprocess.run(kernel,stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True)
  for class_name in ['io.sirix.access.trx.page.NodeStorageEngineWriter','io.sirix.index.hot.HOTIncrementalInsert','io.sirix.index.hot.HOTCommitNormalizer']:
   with (out/(arm+'-'+class_name.rsplit('.',1)[-1]+'.javap.txt')).open('w') as log:
    subprocess.run(['javap','-p','-c','-s','-cp',classpath(arm),class_name],stdout=log,stderr=subprocess.STDOUT,timeout=60,check=True)
 data=json.loads(Path(str(stem)+'.json').read_text());assert len(data)==5
 print('END',stem.name,time.time(),flush=True)
 (out/'progress.json').write_text(json.dumps({'block':block,'position':position,'arm':arm,'completed':block*4+position+1,'total':96}))
assert hashes()==frozen
(out/'complete.json').write_text(json.dumps({'at':time.time()}))

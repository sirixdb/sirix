"""Run inside heavy.sh; upgrade this job's inherited timing lock, never nest the wrappers.

Close admission with the existing gate, then convert OUR inherited open-file-description
from shared to exclusive. Other heavy jobs drain; the outer flock and this process share
the same lock description, so there is no self-deadlock. Keep gate and lock through the
bounded command. No daemon or shared wrapper is changed. A separate flock on the timing
path would deadlock against our outer heavy.sh process and is deliberately not used.
"""
import fcntl
import os
from pathlib import Path
import subprocess
import sys
import time

lock_path = os.environ.get('SPINE_TEST_TIMING_LOCK', '/var/tmp/fm-timing.lock')
gate_path = os.environ.get('SPINE_TEST_TIMING_GATE', '/var/tmp/fm-timing.gate')
lock_fd = None
for name in os.listdir('/proc/self/fd'):
    try:
        if os.readlink('/proc/self/fd/' + name) == lock_path:
            lock_fd = int(name)
            break
    except FileNotFoundError:
        pass
if lock_fd is None:
    raise SystemExit('Refusing: launch through heavy.sh; inherited timing lock missing')
gate_fd = os.open(gate_path, os.O_RDWR | os.O_CREAT, 0o600)
deadline = time.monotonic() + 240
for fd in (gate_fd, lock_fd):
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic() >= deadline:
                raise SystemExit('Exclusive timing admission timed out; no benchmark started')
            time.sleep(0.2)
print('EXCLUSIVE TIMING START', time.time(), 'cpu=0', flush=True)
try:
    result = subprocess.run(['taskset', '-c', '0', *sys.argv[1:]], timeout=18000)
    raise SystemExit(result.returncode)
finally:
    print('EXCLUSIVE TIMING END', time.time(), flush=True)
    os.close(gate_fd)

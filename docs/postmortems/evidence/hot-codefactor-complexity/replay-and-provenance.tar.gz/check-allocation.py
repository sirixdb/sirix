from pathlib import Path
import csv,json,statistics as st
p=Path(__file__).resolve().parent/'allocation';result={}
for case,(folds,outputs,publications) in {'commitDesc4096':(3,784,2),'commitDesc50000':(41,13392,24)}.items():
 arms={}
 for arm in ['before','after']:
  rows=json.loads((p/f'profile-{case}-{arm}-category-operations.json').read_text())
  assert len(rows)==40
  for row in rows:
   assert row['folds']==folds,(case,arm,row)
   assert row['fold output']==outputs,(case,arm,row)
   assert row['fold publication envelope']==publications*32,(case,arm,row)
   assert row['normalization other']<=publications*152,(case,arm,row)
   assert row.get('normalization workspace',0)==0,(case,arm,row)
  counters=list(csv.DictReader((p/f'profile-{case}-{arm}-counters.csv').open()))
  assert len(counters)==40
  assert sum(int(row['timed_gc_count']) for row in counters)==0
  arms[arm]={'folds':folds,'fold_output_bytes':outputs,'publications':publications,'publication_bound_bytes':publications*184,'workspace_bytes':0,'normalization_bound_bytes':outputs+publications*184,'normalization_bytes':sorted(set(row['fold output']+row['fold publication envelope']+row['normalization other'] for row in rows)),'all_40_within_bound':True,'whole_process_direct_mean':st.mean(int(row['direct_bytes']) for row in counters),'whole_process_native_mean':st.mean(int(row['native_bytes']) for row in counters),'timed_gc':0}
 result[case]=arms
(p/'budget-verification.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

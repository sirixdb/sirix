from pathlib import Path
root=Path('bundles/sirix-core/src/main/java/io/sirix')
p=root/'access/trx/page/NodeStorageEngineWriter.java'
s=p.read_text()
start=s.index('  @Override\n  public void commit(final @Nullable PageReference reference)')
end=s.index('\n  @Override\n  public UberPage commit(',start)
section=s[start:end]
a=section.index('      // Overflow pages')
b=section.index('\n    }\n\n    Page page',a)
unlogged=section[a:b]
section=section[:a]+'      commitUnloggedReference(reference);\n      return;'+section[b:]
a=section.index('      final int logKey = reference.getLogKey();')
b=section.index('\n      return;\n    }',a)
closed=section[a:b]
section=section[:a]+'      resolveClosedCommitReference(reference);'+section[b:]
a=section.index('      // Propagate disk offset')
b=section.index('      reference.refreshTransactionLogReference();',a)
propagate=section[a:b]
section=section[:a]+'      propagateCommittedReference(reference);\n'+section[b:]
# Keep the exact branches, order, exceptions and spill handling; only change their owner method.
def unindent(body):return '\n'.join(line[2:] if line.startswith('  ') else line for line in body.split('\n'))
section+='\n  private void commitUnloggedReference(final PageReference reference) {\n'+unindent(unlogged)+'\n  }\n'
section+='\n  private void resolveClosedCommitReference(final PageReference reference) {\n'+unindent(closed)+'\n  }\n'
section+='\n  private void propagateCommittedReference(final PageReference reference) {\n'+unindent(propagate).rstrip()+'\n  }\n'
s=s[:start]+section+s[end:];p.write_text(s)
p=root/'index/hot/HOTIncrementalInsert.java';s=p.read_text()
a=s.index('    int lo = 0;',s.index('  static int prepareCompatibleChild('))
b=s.index('    int unionCount = parentBitCount;',a)
path=s[a:b]
s=s[:a]+'''    if (!isChildBelowParentPath(parent, slot, parentBitCount, scratch)) {
      return 0;
    }
'''+s[b:]
a=s.index('    int unionCount = parentBitCount;',s.index('  static int prepareCompatibleChild('))
b=s.index('    final int firstByte = bits[0]',a)
union=s[a:b]
s=s[:a]+'''    final int unionCount = mergeDiscriminativeBits(parentBitCount, childBitCount, scratch);
    if (unionCount == 0) {
      return 0;
    }
    final int[] bits = scratch.unionBits;
'''+s[b:]
path=path.replace('return 0;', 'return false;')
helpers='''  /** Every decision above the selected slot must precede the child's first bit. */
  private static boolean isChildBelowParentPath(final HOTIndirectPage parent, final int slot,
      final int parentBitCount, final HOTCommitNormalizer.Scratch scratch) {
    final int[] parentPartials = parent.getPartialKeysRef();
    final int[] parentBits = scratch.parentBits;
    final int[] childBits = scratch.childBits;
'''+path+'''    return true;
  }

  /** Merge ordered mask columns into borrowed scratch; zero means the union exceeds 32 bits. */
  private static int mergeDiscriminativeBits(final int parentBitCount, final int childBitCount,
      final HOTCommitNormalizer.Scratch scratch) {
    final int[] parentBits = scratch.parentBits;
    final int[] childBits = scratch.childBits;
'''+union+'''    return unionCount;
  }

'''
pos=s.index('  /** Materialize using the height captured');s=s[:pos]+helpers+s[pos:];p.write_text(s)
p=root/'index/hot/HOTCommitNormalizer.java';s=p.read_text()
a=s.index('    if (depth >= scratch.ancestors.length)')
b=s.index('\n    boolean repairHeight = false;',a)
spine=s[a:b]
s=s[:a]+'    enterDirtySpine(page, scratch, depth);\n'+s[b:]
a=s.index('    boolean repairHeight = false;',s.index('  private static HOTIndirectPage normalize('))
b=s.index('\n    HOTIndirectPage result = page;',a)
children=s[a:b]
s=s[:a]+'    final boolean repairHeight = normalizeChildren(page, writer, scratch, depth);\n'+s[b:]
a=s.index('        // Only an accepted fold')
b=s.index('        // The child was already normalized;',a)
fold=s[a:b]
s=s[:a]+'        result = materializeFold(page, count, writer, scratch);\n'+s[b:]
a=s.index('      int height = 1;',s.index('    if (result == page && repairHeight)'))
b=s.index('\n    }',a)
height=s[a:b]
s=s[:a]+'      repairHeight(page, writer);'+s[b:]
helpers='''  private static void enterDirtySpine(final HOTIndirectPage page, final Scratch scratch, final int depth) {
'''+spine+'''
  }

  private static boolean normalizeChildren(final HOTIndirectPage page, final StorageEngineWriter writer,
      final Scratch scratch, final int depth) {
    final TransactionIntentLog log = writer.getLog();
'''+children+'''
    return repairHeight;
  }

  private static HOTIndirectPage materializeFold(final HOTIndirectPage page, final int count,
      final StorageEngineWriter writer, final Scratch scratch) {
'''+ '\n'.join(line[4:] for line in fold.splitlines())+'''
  }

  private static void repairHeight(final HOTIndirectPage page, final StorageEngineWriter writer) {
'''+ '\n'.join(line[2:] for line in height.splitlines())+'''
  }

'''
helpers=helpers.replace('    result =\n        HOTIncrementalInsert.materializePreparedFold', '    return HOTIncrementalInsert.materializePreparedFold')
pos=s.index('  private static Page resolveChild(');s=s[:pos]+helpers+s[pos:];p.write_text(s)

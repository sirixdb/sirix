from pathlib import Path
import hashlib,json,shutil,subprocess,time
p=Path(__file__).resolve().parent
out=p/'allocation';out.mkdir(exist_ok=False)
base=json.loads((p/'dependencies.json').read_text());production=p.parent.parent/'bundles/sirix-core/build/classes/java/main'
audit={}
for case in ['commitDesc4096','commitDesc50000']:
 for arm in ['before','after']:
  assert shutil.disk_usage(p).free>=60*1024**3
  stem=out/('profile-'+case+'-'+arm)
  cp=':'.join([str(p/'classes'),str(p/('before' if arm=='before' else 'after_')),*[x for x in base if x!=str(production)]])
  audit[arm]=cp.split(':')
  flags=['--enable-preview','--add-modules=jdk.incubator.vector','--enable-native-access=ALL-UNNAMED','-Xms2g','-Xmx2g','-XX:MaxDirectMemorySize=1g','-XX:-UseJVMCICompiler','-Dsirix.allocator.maxSize=1073741824','-Dsirix.hotLookupCache.maxEntries=0','-Djava.io.tmpdir='+str(p/'tmp'),'-Dlogback.configurationFile='+str(p/'logback-benchmark.xml'),'-agentpath:'+str(p/'libhotalloc.so')]
  cmd=['java',*flags,'-cp',cp,'io.sirix.index.hot.AllocationBudgetConfirmation',case,str(stem),'40']
  Path(str(stem)+'-command.json').write_text(json.dumps(cmd,indent=2))
  print('START',case,arm,time.time(),flush=True)
  with Path(str(stem)+'.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600,check=True)
  print('END',case,arm,time.time(),flush=True)
assert [(i,a,b) for i,(a,b) in enumerate(zip(audit['before'],audit['after'])) if a!=b]==[(1,str(p/'before'),str(p/'after_'))]
(out/'classpath-audit.json').write_text(json.dumps(audit,indent=2))
(out/'production-sha256.json').write_text(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for a in ['before','after_'] for f in sorted((p/a).rglob('*.class'))},indent=2))
(out/'complete.json').write_text(json.dumps({'at':time.time()}))

from pathlib import Path
import hashlib,json,shutil
p=Path(__file__).resolve().parent;r=p.parent.parent
production=r/'bundles/sirix-core/build/classes/java/main'
deps=json.loads((p/'dependencies.json').read_text());mapping={}
for index,entry in enumerate(deps):
 path=Path(entry)
 if path.is_relative_to(r) and path!=production:
  target=p/'shared-runtime'/str(index)
  shutil.copytree(path,target)
  mapping[entry]=str(target)
(p/'runtime-mapping.json').write_text(json.dumps(mapping,indent=2))
(p/'dependencies-pre-freeze.json').write_text(json.dumps(deps,indent=2))
(p/'dependencies.json').write_text(json.dumps([mapping.get(x,x) for x in deps],indent=2))
files=[f for f in (p/'shared-runtime').rglob('*') if f.is_file()]+[Path(x) for x in deps if x.endswith('.jar')]
(p/'dependency-sha256.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files)},indent=2))
print('Frozen project runtime directories:',len(mapping),'Dependency entries:',len(deps))

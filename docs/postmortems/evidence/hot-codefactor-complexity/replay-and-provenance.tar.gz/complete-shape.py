from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).resolve().parent;out=p/'shape'
source=out/'00-0-before'
main=json.loads(Path(str(source)+'-command.json').read_text())
kernel=json.loads(Path(str(source)+'-kernel-command.json').read_text())
cp=main[main.index('-cp')+1]
subprocess.run(['javac','--release','25','--enable-preview','-proc:none','-cp',cp,'-d',str(p/'classes'),str(p/'KernelCompiledShape.java')],check=True)
# Repair the diagnostic fixture only: 32 children require MultiNode, not SpanNode (2..16).
# Preserve the already completed baseline JMH capture; no timing-gate samples exist here.
(out/'corrected-diagnostic-sha256.json').write_text(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for arm in ['before','after_','classes'] for f in sorted((p/arm).rglob('*')) if f.is_file()},indent=2))
for arm in ['before','after']:
 stem=out/('00-0-before' if arm=='before' else '00-1-after')
 def adapt(command):
  return [x.replace(str(p/'before'),str(p/'after_') if arm=='after' else str(p/'before')).replace(str(source),str(stem)) for x in command]
 if arm=='after':
  cmd=adapt(main);Path(str(stem)+'-command.json').write_text(json.dumps(cmd,indent=2))
  print('START CANDIDATE JMH SHAPE',time.time(),flush=True)
  with Path(str(stem)+'.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=600,check=True)
 cmd=adapt(kernel);Path(str(stem)+'-kernel-corrected-command.json').write_text(json.dumps(cmd,indent=2))
 print('START KERNEL',arm,time.time(),flush=True)
 with Path(str(stem)+'-kernel-corrected.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True)
 for clazz in ['io.sirix.access.trx.page.NodeStorageEngineWriter','io.sirix.index.hot.HOTIncrementalInsert','io.sirix.index.hot.HOTCommitNormalizer']:
  with (out/(arm+'-'+clazz.rsplit('.',1)[-1]+'.javap.txt')).open('w') as log:subprocess.run(['javap','-p','-c','-s','-cp',cmd[cmd.index('-cp')+1],clazz],stdout=log,stderr=subprocess.STDOUT,timeout=60,check=True)
 print('DONE',arm,time.time(),flush=True)
(out/'complete.json').write_text(json.dumps({'at':time.time()}))

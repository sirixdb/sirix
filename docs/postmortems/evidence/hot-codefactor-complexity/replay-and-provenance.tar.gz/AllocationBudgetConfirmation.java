package io.sirix.index.hot;

import com.sun.management.ThreadMXBean;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public final class AllocationBudgetConfirmation {
  private static volatile Object escape;
  private static volatile long positiveCount;
  private static volatile long positiveBytes;

  static void controlAllocations() {
    for (int i=0;i<16;i++) escape = new byte[4096];
  }
  static void control() {
    AllocationProfiler.begin(-1);
    controlAllocations();
    AllocationProfiler.end();
    positiveCount=AllocationProfiler.controlCount();
    positiveBytes=AllocationProfiler.controlBytes();
  }
  static void checkControl() {
    if (positiveCount!=16 || positiveBytes!=16*4112) {
      throw new AssertionError("Zero-interval allocation control failed: "+positiveCount+" / "+positiveBytes);
    }
  }

  public static void main(String[] args) throws Exception {
    final Path prefix=Path.of(args[1]);
    final int iterations=Integer.parseInt(args[2]);
    control();checkControl();
    Thread.ofVirtual().start(AllocationBudgetConfirmation::control).join();checkControl();
    Files.writeString(Path.of(prefix+"-control.txt"),"platform_and_virtual:16 arrays,65792 bytes each; zero-interval control passed\n");
    final FinalHOTBenchmark.Operation state=new FinalHOTBenchmark.Operation();
    state.caseName=args[0];state.open();
    final FinalHOTBenchmark benchmark=new FinalHOTBenchmark();
    try {
      for(int i=0;i<50;i++){state.beginTransaction();benchmark.operation(state);state.endTransaction();}
      final List<String> counters=new ArrayList<>(iterations+1);
      counters.add("operation,direct_bytes,native_bytes,native_caller_bytes,timed_gc_count,timed_gc_ms");
      for(int i=0;i<iterations;i++) {
        state.beginTransaction();System.gc();
        final long gcCount=state.collections();final long gcMs=state.gcMillis();
        AllocationProfiler.begin(i);
        final long allocated=state.allocatedBytes();
        benchmark.operation(state);
        final long direct=state.allocatedBytes()-allocated;
        final long nativeBytes=AllocationProfiler.end();
        counters.add(i+","+direct+","+nativeBytes+","+AllocationProfiler.callerBytes()+","+(state.collections()-gcCount)+","+(state.gcMillis()-gcMs));
        AllocationProfiler.dump(prefix+"-"+i+"-stacks.tsv");
        state.endTransaction();
      }
      Files.write(Path.of(prefix+"-counters.csv"),counters);
    } finally {state.fixture.close();}
  }
}

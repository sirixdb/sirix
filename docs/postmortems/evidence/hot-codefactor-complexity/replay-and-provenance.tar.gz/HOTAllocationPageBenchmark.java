package io.sirix.index.hot;

import io.sirix.api.StorageEngineWriter;
import io.sirix.api.json.JsonNodeTrx;
import io.sirix.index.IndexType;
import io.sirix.index.hot.page.HOTIndirectPage;
import io.sirix.index.hot.page.HOTLeafPage;
import io.sirix.page.PageReference;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Level;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Param;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.TearDown;

import java.util.concurrent.TimeUnit;

@OutputTimeUnit(TimeUnit.NANOSECONDS)
public class HOTAllocationPageBenchmark {
  @State(Scope.Thread)
  public static class Dirty {
    final HotBenchmarkFixture fixture = new HotBenchmarkFixture();
    final HOTCommitNormalizer.Scratch scratch = new HOTCommitNormalizer.Scratch();
    JsonNodeTrx trx;
    StorageEngineWriter engine;
    PageReference reference;
    HOTIndirectPage root;
    boolean normalize;

    @Setup(Level.Trial)
    public void open() throws Exception {
      fixture.open(4096, "ascending");
      normalize = Boolean.getBoolean("spine.normalize");
      trx = fixture.session.beginNodeTrx();
      engine = trx.getStorageEngineWriter();
      HOTIndexWriter<Long> writer = HOTIndexWriter.create(engine, HotBenchmarkFixture.SERIALIZER, IndexType.CAS, 0);
      for (Long key : fixture.keys) writer.indexNodeKey(key, 1);
      reference = writer.getRootReference();
      root = (HOTIndirectPage) engine.loadHOTPage(reference);
      if (root.getHeight() != 1) throw new AssertionError("Expected one dirty indirect page");
      for (int i = 0; i < root.getNumChildren(); i++) {
        if (engine.loadHOTPage(root.getChildReference(i)) instanceof HOTIndirectPage) {
          throw new AssertionError("Dirty page must have only leaf children");
        }
      }
    }

    @TearDown(Level.Trial)
    public void close() {
      trx.rollback();
      trx.close();
      fixture.close();
    }
  }

  @State(Scope.Thread)
  public static class Output {
    @Param({"1", "72"})
    public int childBit;
    final HOTCommitNormalizer.Scratch scratch = new HOTCommitNormalizer.Scratch();
    final int[] partials = {0, 1, 2};
    final byte[] positions = {0, 9};
    final long[] masks = {0x8080000000000000L};
    final PageReference[] children = new PageReference[3];
    HOTLeafPage a;
    HOTLeafPage b;
    HOTLeafPage c;
    HOTIndirectPage child;
    HOTIndirectPage parent;
    boolean fold;

    @Setup(Level.Trial)
    public void open() {
      fold = Boolean.getBoolean("spine.normalize");
      a = new HOTLeafPage(1, 1, IndexType.CAS);
      b = new HOTLeafPage(2, 1, IndexType.CAS);
      c = new HOTLeafPage(3, 1, IndexType.CAS);
      children[0] = new PageReference(); children[0].setPage(a);
      children[1] = new PageReference(); children[1].setPage(b);
      children[2] = new PageReference(); children[2].setPage(c);
      child = HOTIndirectPage.createBiNode(4, 1, childBit, children[0], children[1], 1);
      PageReference childRef = new PageReference(); childRef.setPage(child);
      parent = HOTIndirectPage.createBiNode(5, 1, 0, childRef, children[2], 2);
    }

    @TearDown(Level.Trial)
    public void close() { a.close(); b.close(); c.close(); }
  }

  @Benchmark
  @BenchmarkMode(Mode.AverageTime)
  public HOTIndirectPage foldOutput(Output state) {
    if (state.fold) {
      return HOTIncrementalInsert.foldCompatibleChild(state.parent, 0, state.child, 1, 10, state.scratch);
    }
    return state.childBit == 72
        ? HOTIndirectPage.createSpanNodeMultiMask(10, 1, state.positions, state.masks, 2,
            state.partials, state.children, 1, (short) 0)
        : HOTIndirectPage.createSpanNode(10, 1, 0, 0xC000000000000000L, state.partials, state.children, 1);
  }

  @Benchmark
  @BenchmarkMode(Mode.AverageTime)
  public int visitOneDirtyPage(Dirty state) {
    return state.normalize
        ? HOTCommitNormalizer.normalize(state.reference, state.root, state.engine, state.scratch).getHeight()
        : state.root.getHeight();
  }
}

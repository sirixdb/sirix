package io.sirix.index.hot;
final class AllocationProfiler {
  static native void begin(int id);
  static native long end();
  static native long callerBytes();
  static native long controlCount();
  static native long controlBytes();
  static native void dump(String path);
}

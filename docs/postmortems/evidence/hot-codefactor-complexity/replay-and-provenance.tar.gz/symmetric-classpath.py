"""Symmetric production substitution; historical frozen gate commands remain immutable."""
from pathlib import Path

def classpath(prefixes, production, dependencies, production_roots):
    excluded = {str(Path(x).resolve()) for x in production_roots}
    entries = [str(Path(x).resolve()) for x in prefixes] + [str(Path(production).resolve())]
    entries += [str(Path(x).resolve()) for x in dependencies.split(":")
                if str(Path(x).resolve()) not in excluded]
    result = list(dict.fromkeys(entries))
    assert len(result) == len(set(result))
    assert sum(x in excluded or x == str(Path(production).resolve()) for x in result) == 1
    return ":".join(result)

from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).resolve().parent;out=p/'shape'
original=json.loads((out/'00-0-before-kernel-command.json').read_text())
mapping=json.loads((p/'runtime-mapping.json').read_text())
cp=':'.join(mapping.get(x,x) for x in original[original.index('-cp')+1].split(':'))
original[original.index('-cp')+1]=cp
subprocess.run(['javac','--release','25','--enable-preview','-proc:none','-cp',cp,'-d',str(p/'classes'),str(p/'KernelCompiledShape.java')],check=True)
(out/'closed-kv-diagnostic-sha256.json').write_text(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted((p/'classes').rglob('KernelCompiledShape*.class'))},indent=2))
for arm in ['before','after']:
 cmd=[x.replace(str(p/'before'),str(p/'after_') if arm=='after' else str(p/'before')) for x in original]
 stem=out/('closed-kv-frozen-'+arm);Path(str(stem)+'-command.json').write_text(json.dumps(cmd,indent=2))
 print('START',arm,time.time(),flush=True)
 with Path(str(stem)+'.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300,check=True)
 print('DONE',arm,time.time(),flush=True)

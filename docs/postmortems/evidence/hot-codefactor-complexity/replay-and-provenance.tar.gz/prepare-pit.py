from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'tools'))
import lizard
p=Path(__file__).resolve().parent
files=['bundles/sirix-core/src/main/java/io/sirix/access/trx/page/NodeStorageEngineWriter.java','bundles/sirix-core/src/main/java/io/sirix/index/hot/HOTIncrementalInsert.java','bundles/sirix-core/src/main/java/io/sirix/index/hot/HOTCommitNormalizer.java']
allow={'commit','commitUnloggedReference','resolveClosedCommitReference','prepareCompatibleChild','isChildBelowParentPath','mergeDiscriminativeBits','normalize','normalizeChildren','enterDirtySpine','materializeFold','repairHeight'}
all_names={f.name.split('::')[-1] for path in files for f in lizard.analyze_file(path).function_list}
excluded=sorted((all_names-allow)|{'<init>','<clinit>','lambda$*'})
(p/'pit-scope.json').write_text(json.dumps({'allowedMethods':sorted(allow),'excludedMethods':excluded},indent=2))
(p/'pit.init.gradle').write_text("gradle.projectsEvaluated { gradle.rootProject.project(':sirix-core') { pitest { excludedMethods = "+repr(excluded)+"; threads = 1; jvmArgs.add('-Xmx1536m'); jvmArgs.add('-Dsirix.allocator.maxSize=1073741824') } } }\n")
(p/'pit-targets.txt').write_text('io.sirix.access.trx.page.NodeStorageEngineWriter\nio.sirix.index.hot.HOTIncrementalInsert\nio.sirix.index.hot.HOTCommitNormalizer\n')

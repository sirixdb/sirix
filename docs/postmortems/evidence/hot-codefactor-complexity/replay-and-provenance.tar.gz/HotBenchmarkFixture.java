package io.sirix.index.hot;

import io.sirix.access.DatabaseConfiguration;
import io.sirix.access.Databases;
import io.sirix.access.ResourceConfiguration;
import io.sirix.api.Database;
import io.sirix.api.json.JsonResourceSession;
import io.sirix.settings.VersioningType;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;
import java.util.TreeSet;

/** Plain helper with no JMH annotations or inheritance. Each state owns its lifecycle. */
final class HotBenchmarkFixture {
  static final HOTKeySerializer<Long> SERIALIZER = new HOTKeySerializer<>() {
    public int serialize(Long value, byte[] bytes, int offset) {
      for (int i = 0; i < 8; i++) {
        bytes[offset + i] = 0;
        bytes[offset + 8 + i] = (byte) (value >>> (56 - i * 8));
      }
      return 16;
    }
    public int maxSerializedLength(Long value) { return 16; }
    public Long deserialize(byte[] bytes, int offset, int length) {
      long value = 0;
      for (int i = 8; i < 16; i++) value = (value << 8) | (bytes[offset + i] & 255);
      return value;
    }
  };
  Path path;
  Database<JsonResourceSession> db;
  JsonResourceSession session;
  Long[] keys;
  void open(int count, String order) throws Exception {
    path = Files.createTempDirectory("hot-spine-jmh");
    Databases.createJsonDatabase(new DatabaseConfiguration(path));
    db = Databases.openJsonDatabase(path);
    db.createResource(ResourceConfiguration.newBuilder("r").storeDiffs(false)
        .versioningApproach(VersioningType.FULL).build());
    session = db.beginResourceSession("r");
    keys = new Long[count];
    TreeSet<Long> sorted = new TreeSet<>();
    Random random = new Random(5);
    for (int i = 0; sorted.size() < count; i++) {
      sorted.add(count == 50000 && i >= 45000 ? random.nextLong() & Long.MAX_VALUE : (long) i);
    }
    sorted.toArray(keys);
    if (order.equals("descending")) Collections.reverse(Arrays.asList(keys));
    if (order.equals("shuffled")) Collections.shuffle(Arrays.asList(keys), new Random(9002));
  }
  void close() {
    session.close(); db.close(); Databases.removeDatabase(path); Databases.clearGlobalCaches();
  }
}

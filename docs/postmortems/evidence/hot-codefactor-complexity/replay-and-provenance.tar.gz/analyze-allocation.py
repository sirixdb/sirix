from pathlib import Path
import csv,collections,statistics as st,re,json
p=Path(__file__).parent/'allocation'

def norm(s):return re.sub(r'\.0x[0-9a-fA-F]+','.0xADDRESS',s)
def category(row):
 s=row['stack'];c=row['class']
 if 'Ljdk/jfr/' in s:return 'JFR instrumentation'
 if 'HOTIndirectPage;.createFoldedNode(' in s:return 'fold output'
 if 'HOTCommitNormalizer$Scratch;' in c or 'HOTCommitNormalizer$Scratch;.<init>' in s:return 'normalization workspace'
 if 'HOTCommitNormalizer;.normalize(' in s:
  return 'fold publication envelope' if c=='Lio/sirix/cache/PageContainer;' else 'normalization other'
 return 'other commit/insert work'
summary={};all_delta=[]
for case in ['commitDesc4096','commitDesc50000','insertAsc4096']:
 counters={};categories={};stacks={};folds={}
 for arm in ['before','after']:
  counterfile=p/f'profile-{case}-{arm}-counters.csv'
  if not counterfile.exists():break
  counters[arm]=list(csv.DictReader(counterfile.open()))
  categories[arm]=collections.Counter();stacks[arm]=collections.Counter();folds[arm]=collections.Counter()
  per_op=[]
  for cr in counters[arm]:
   f=p/f"profile-{case}-{arm}-{cr['operation']}-stacks.tsv"
   rows=list(csv.DictReader(f.open(),delimiter='\t'))
   assert sum(int(row['bytes']) for row in rows)==int(cr['native_bytes'])
   assert sum(int(row['bytes']) for row in rows if row['thread_role']=='caller')==int(cr['native_caller_bytes'])
   cats=collections.Counter();fc=0
   for row in rows:
    if case.startswith('insert') and row['thread_role']!='caller':continue
    cat=category(row);n=int(row['bytes']);categories[arm][cat]+=n;cats[cat]+=n
    key=(cat,norm(row['class']),row['object_size'],row['thread_role'],norm(row['stack']))
    stacks[arm][key]+=n
    if cat=='fold output':
     folds[arm][(row['class'],row['object_size'])]+=int(row['count'])
     if row['class']=='Lio/sirix/index/hot/page/HOTIndirectPage;':fc+=int(row['count'])
   per_op.append({'operation':int(cr['operation']),'folds':fc,**cats})
  (p/f'profile-{case}-{arm}-category-operations.json').write_text(json.dumps(per_op,indent=2))
 else:
  n=len(counters['before']);assert n==len(counters['after'])==40
  direct={a:st.mean(int(x['direct_bytes']) for x in counters[a]) for a in counters}
  col='native_caller_bytes' if case.startswith('insert') else 'native_bytes'
  native={a:st.mean(int(x[col]) for x in counters[a]) for a in counters}
  differences=[]
  for key in stacks['before'].keys()|stacks['after'].keys():
   delta=(stacks['after'][key]-stacks['before'][key])/n
   if delta:
    cat,c,size,role,s=key;differences.append({'category':cat,'class':c,'object_size':size,'thread_role':role,'before_bytes':stacks['before'][key]/n,'after_bytes':stacks['after'][key]/n,'delta_bytes':delta,'stack':s})
  differences.sort(key=lambda x:abs(x['delta_bytes']),reverse=True)
  with (p/f'{case}-stack-deltas.tsv').open('w') as f:
   writer=csv.DictWriter(f,fieldnames=list(differences[0]),delimiter='\t');writer.writeheader();writer.writerows(differences)
  cats={key:{'before':categories['before'][key]/n,'after':categories['after'][key]/n,'delta':(categories['after'][key]-categories['before'][key])/n} for key in categories['before'].keys()|categories['after'].keys()}
  summary[case]={'direct_bytes':direct,'native_bytes':native,'categories':cats,'fold_objects_per_op':[{ 'class':k[0],'size':int(k[1]),'count':v/n,'bytes':int(k[1])*v/n} for k,v in sorted(folds['after'].items())], 'counter_residuals':{a:dict(collections.Counter(int(x['direct_bytes'])-int(x[col]) for x in counters[a])) for a in counters},'top_deltas':differences[:30]}
(p/'summary.json').write_text(json.dumps(summary,indent=2))
for case,x in summary.items():
 print(case,'direct',x['direct_bytes'],'native',x['native_bytes'])
 print('categories',x['categories'])
 print('folds',x['fold_objects_per_op'])
 for d in x['top_deltas'][:12]:print(d['delta_bytes'],d['category'],d['class'],d['stack'][:210])

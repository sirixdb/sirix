from pathlib import Path
import json,subprocess
p=Path(__file__).resolve().parent;r=p.parent.parent
cp=(p/'classpath.txt').read_text().strip().split(':')
proof=Path('/home/johannes/IdeaProjects/firstmate/data/sirix-hot-lost-spine-fix')
# Reuse dependency artifacts only; never refer to an alternate project checkout.
extra=[x for x in (proof/'benchmark-classpath').read_text().strip().split(':') if x.endswith('.jar') and any('/'+n+'/' in x for n in ['jmh-core','jmh-generator-annprocess','jopt-simple','commons-math3'])]
cp=list(dict.fromkeys(cp+extra))
assert all(Path(x).exists() for x in cp),[x for x in cp if not Path(x).exists()]
(p/'dependencies.json').write_text(json.dumps(cp,indent=2))
(p/'classes').mkdir(exist_ok=True);(p/'tmp').mkdir(exist_ok=True)
cmd=['javac','--release','25','--enable-preview','-cp',':'.join(cp),'-processor','org.openjdk.jmh.generators.BenchmarkProcessor','-d',str(p/'classes'),'-s',str(p/'generated'),*[str(p/x) for x in ['FinalHOTBenchmark.java','HotBenchmarkFixture.java','HOTAllocationPageBenchmark.java','AllocationProfiler.java','AllocationBudgetConfirmation.java','KernelCompiledShape.java']]]
(p/'javac-command.json').write_text(json.dumps(cmd,indent=2));subprocess.run(cmd,check=True)

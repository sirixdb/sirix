from pathlib import Path
import gzip,hashlib,json,tarfile
p=Path(__file__).resolve().parent;r=p.parent.parent
out=r/'docs/postmortems/evidence/hot-codefactor-complexity'
def archive(name,files):
 path=out/name
 with tarfile.open(path,'w:gz',compresslevel=6) as tar:
  for f in sorted(set(files)):
   if f.is_file():tar.add(f,arcname=str(f.relative_to(p)),recursive=False)
 print(name,path.stat().st_size,flush=True)
archive('allocation.tar.gz',list((p/'allocation').rglob('*'))+[p/'allocation-analysis.log',p/'allocation-budget-check.log',p/'allocation-driver.log'])
archive('compiled-shape.tar.gz',list((p/'shape').rglob('*'))+[p/'shape-analysis-final.log',p/'shape-completion.log',p/'cold-shape-frozen.log'])
files=list((p/'focused-xml').rglob('*.xml'))+list((p/'budget-xml').rglob('*.xml'))+list((p/'mutation-regression-xml').rglob('*.xml'))
files += [p/'pit-initial-report/mutations.xml',p/'pit-report/mutations.xml',p/'pit-zero-report/mutations.xml']
files += [p/n for n in ['baseline-build.log','focused-corrected-launch.log','budgets.log','mutation-regressions.log','pit-corrected-launch.log','pit-strengthened.log','pit-zero.log','focused-counts.json','budget-counts.json','mutation-regression-counts.json','pit-summary-final.json']]
archive('verification.tar.gz',files)
files=[f for pattern in ['*.py','*.sh','*.gradle','*.java','*.md','*.json','*.txt'] for f in p.glob(pattern)]
# Include the input baseline's source/class hashes and scripts, never installed tool packages or binary class trees.
archive('replay-and-provenance.tar.gz',files)
manifest={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(out.glob('*.tar.gz'))}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(json.dumps(manifest,indent=2))

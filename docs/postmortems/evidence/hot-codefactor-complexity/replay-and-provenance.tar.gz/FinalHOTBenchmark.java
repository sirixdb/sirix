package io.sirix.index.hot;

import com.sun.management.ThreadMXBean;
import io.sirix.api.json.JsonNodeTrx;
import io.sirix.index.IndexType;
import org.openjdk.jmh.annotations.Benchmark;
import org.openjdk.jmh.annotations.BenchmarkMode;
import org.openjdk.jmh.annotations.Level;
import org.openjdk.jmh.annotations.Mode;
import org.openjdk.jmh.annotations.OutputTimeUnit;
import org.openjdk.jmh.annotations.Param;
import org.openjdk.jmh.annotations.Scope;
import org.openjdk.jmh.annotations.Setup;
import org.openjdk.jmh.annotations.State;
import org.openjdk.jmh.annotations.TearDown;
import org.openjdk.jmh.infra.IterationParams;
import org.openjdk.jmh.runner.IterationType;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.TimeUnit;

@OutputTimeUnit(TimeUnit.NANOSECONDS)
public class FinalHOTBenchmark {
  private static volatile Object allocationControl;
  @State(Scope.Thread)
  public static class Operation {
    @Param({"insertAsc4096", "insertDesc4096", "insertDesc50000", "commitDesc4096", "commitDesc50000"})
    public String caseName;
    int count;
    String order;
    boolean commit;
    final HotBenchmarkFixture fixture = new HotBenchmarkFixture();
    JsonNodeTrx trx;
    HOTIndexWriter<Long> writer;
    final ThreadMXBean allocation = (ThreadMXBean) ManagementFactory.getThreadMXBean();
    final List<GarbageCollectorMXBean> collectors = ManagementFactory.getGarbageCollectorMXBeans();
    final long[] bytes = new long[256];
    final long[] collections = new long[256];
    final long[] gcMillis = new long[256];
    long thread;
    long allocatedBefore;
    long collectionsBefore;
    long gcMillisBefore;
    long warmupBatches;
    long warmupNanos;
    long totalCollectionsBefore;
    int samples;
    boolean measurement;

    long collections() {
      long sum = 0;
      for (GarbageCollectorMXBean collector : collectors) sum += Math.max(0, collector.getCollectionCount());
      return sum;
    }
    long gcMillis() {
      long sum = 0;
      for (GarbageCollectorMXBean collector : collectors) sum += Math.max(0, collector.getCollectionTime());
      return sum;
    }
    void beginTransaction() {
      trx = fixture.session.beginNodeTrx();
      if (commit) trx.revertTo(0);
      writer = HOTIndexWriter.create(trx.getStorageEngineWriter(), HotBenchmarkFixture.SERIALIZER, IndexType.CAS, 0);
      if (commit) {
        for (Long key : fixture.keys) writer.indexNodeKey(key, 1);
      }
    }
    long allocatedBytes() {
      // Commit executes on virtual/background threads: include their allocation, not only the caller.
      return commit ? allocation.getTotalThreadAllocatedBytes() : allocation.getThreadAllocatedBytes(thread);
    }
    void endTransaction() { trx.rollback(); trx.close(); }

    @Setup(Level.Trial)
    public void open() throws Exception {
      count = caseName.endsWith("50000") ? 50000 : 4096;
      order = caseName.equals("insertAsc4096") ? "ascending" : "descending";
      commit = caseName.startsWith("commit");
      fixture.open(count, order);
      warmSteadyState();
    }

    void warmSteadyState() throws InterruptedException {
      thread = Thread.currentThread().threadId();
      allocation.setThreadAllocatedMemoryEnabled(true);
      final long counterStart = allocatedBytes();
      if (counterStart < 0) throw new IllegalStateException("Required allocation counter is unavailable");
      final int controlSize = commit ? 1024 * 1024 : 4096;
      if (commit) {
        Thread.ofVirtual().start(() -> allocationControl = new byte[controlSize]).join();
      } else {
        allocationControl = new byte[controlSize];
      }
      if (allocatedBytes() - counterStart < controlSize) {
        throw new IllegalStateException("Allocation counter failed its escaping positive control");
      }
      allocationControl = null;
      totalCollectionsBefore = collections();
      FinalHOTBenchmark benchmark = new FinalHOTBenchmark();
      final long started = System.nanoTime();
      final long duration = Long.getLong("spine.warmupNanos", 30_000_000_000L);
      do {
        beginTransaction();
        benchmark.operation(this);
        endTransaction();
        warmupBatches++;
      } while (System.nanoTime() - started < duration);
      warmupNanos = System.nanoTime() - started;
    }

    @Setup(Level.Iteration)
    public void iteration(IterationParams params) {
      measurement = params.getType() == IterationType.MEASUREMENT;
    }

    @Setup(Level.Invocation)
    public void begin() {
      beginTransaction();
      // For commit, the untimed insertion fixture must also be reclaimed before primary timing.
      if (measurement) System.gc();
      collectionsBefore = collections();
      gcMillisBefore = gcMillis();
      allocatedBefore = allocatedBytes();
    }

    @TearDown(Level.Invocation)
    public void finish() {
      final long allocated = allocatedBytes() - allocatedBefore;
      if (measurement) {
        bytes[samples] = allocated;
        collections[samples] = collections() - collectionsBefore;
        gcMillis[samples] = gcMillis() - gcMillisBefore;
        samples++;
      }
      endTransaction();
    }

    @TearDown(Level.Trial)
    public void close() {
      try {
        saveCounters();
      } catch (Exception failure) {
        throw new IllegalStateException(failure);
      } finally {
        fixture.close();
      }
    }

    void saveCounters() throws Exception {
      StringBuilder out = new StringBuilder();
      out.append("sample,allocated_bytes,timed_gc_count,timed_gc_ms\n");
      for (int i = 0; i < samples; i++) {
        out.append(i).append(',').append(bytes[i]).append(',').append(collections[i])
            .append(',').append(gcMillis[i]).append('\n');
      }
      Path prefix = Path.of(System.getProperty("spine.output") + "-" + caseName);
      Files.writeString(Path.of(prefix + "-counters.csv"), out);
      Files.writeString(Path.of(prefix + "-warmup.txt"), "batches=" + warmupBatches
          + " nanos=" + warmupNanos + " all_gc_count=" + (collections() - totalCollectionsBefore)
          + " forced_measurement_gc_requests=" + samples
          + " allocation_counter=" + (commit ? "all_threads" : "caller_thread") + "\n");
    }
  }

  @Benchmark
  @BenchmarkMode(Mode.SingleShotTime)
  public void operation(Operation state) {
    if (state.commit) {
      state.trx.commit();
    } else {
      for (Long key : state.fixture.keys) state.writer.indexNodeKey(key, 1);
    }
  }
}

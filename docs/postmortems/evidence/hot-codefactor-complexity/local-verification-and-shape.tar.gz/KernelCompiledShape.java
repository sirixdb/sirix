package io.sirix.index.hot;

import io.sirix.api.StorageEngineWriter;
import io.sirix.api.json.JsonNodeTrx;
import io.sirix.cache.PageContainer;
import io.sirix.index.IndexType;
import io.sirix.index.hot.page.HOTIndirectPage;
import io.sirix.index.hot.page.HOTLeafPage;
import io.sirix.page.PageReference;
import io.sirix.page.KeyValueLeafPage;
import io.sirix.page.interfaces.Page;

/** Untimed diagnostic: exercise full-parent height repair and cold commit-reference returns. */
public final class KernelCompiledShape {
  private static volatile Object sink;

  private static PageReference reference(final Page page) {
    final PageReference reference = new PageReference();
    reference.setPage(page);
    return reference;
  }

  public static void main(final String[] args) throws Exception {
    final HotBenchmarkFixture fixture = new HotBenchmarkFixture();
    fixture.open(4096, "ascending");
    try (JsonNodeTrx trx = fixture.session.beginNodeTrx();
        HOTLeafPage a = new HOTLeafPage(1, 1, IndexType.CAS);
        HOTLeafPage b = new HOTLeafPage(2, 1, IndexType.CAS);
        HOTLeafPage c = new HOTLeafPage(3, 1, IndexType.CAS)) {
      final StorageEngineWriter writer = trx.getStorageEngineWriter();
      final HOTCommitNormalizer.Scratch scratch = new HOTCommitNormalizer.Scratch();
      final PageReference ar = reference(a);
      final PageReference br = reference(b);
      final PageReference cr = reference(c);
      writer.getLog().put(ar, PageContainer.getInstance(a, a));
      writer.getLog().put(br, PageContainer.getInstance(b, b));
      writer.getLog().put(cr, PageContainer.getInstance(c, c));
      final PageReference bottom = new PageReference();
      final PageReference middle = new PageReference();
      final PageReference rootRef = new PageReference();
      final PageReference[] children = new PageReference[32];
      final int[] partials = new int[32];
      children[0] = middle;
      for (int i = 1; i < 32; i++) {
        children[i] = cr;
        partials[i] = i;
      }
      final PageReference durable = new PageReference();
      durable.setKey(42);
      final KeyValueLeafPage closed = new KeyValueLeafPage(43, IndexType.DOCUMENT,
          fixture.session.getResourceConfig(), writer.getRevisionNumber(), null, null, false);
      final PageReference closedRef = reference(closed);
      writer.getLog().put(closedRef, PageContainer.getInstance(closed, closed));
      closed.close();
      closedRef.setKey(43);
      final PageReference copiedClosedRef = new PageReference(closedRef);
      copiedClosedRef.setKey(-1);
      for (int i = 0; i < 40000; i++) {
        final HOTIndirectPage lower = HOTIndirectPage.createBiNode(40, 1, 6, ar, br, 1);
        writer.getLog().put(bottom, PageContainer.getInstance(lower, lower));
        final HOTIndirectPage upper = HOTIndirectPage.createBiNode(41, 1, 5, bottom, cr, 2);
        writer.getLog().put(middle, PageContainer.getInstance(upper, upper));
        final HOTIndirectPage root = HOTIndirectPage.createMultiNode(42, 1, 0, 0xF800000000000000L, partials, children, 3);
        writer.getLog().put(rootRef, PageContainer.getInstance(root, root));
        final HOTIndirectPage normalized = HOTCommitNormalizer.normalize(rootRef, root, writer, scratch);
        if (normalized.getHeight() != 2 || normalized.getNumChildren() != 32) {
          throw new AssertionError("Full parent must retain all children and repair its height");
        }
        sink = normalized;
        writer.commit(durable);
        writer.commit(copiedClosedRef);
      }
      trx.rollback();
    } finally {
      fixture.close();
    }
  }
}

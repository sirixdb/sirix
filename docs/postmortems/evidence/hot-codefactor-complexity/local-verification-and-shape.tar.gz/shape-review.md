# Fresh local compiled-shape review

All1854 local production class hashes match the frozen candidate. The fresh two-arm diagnostic capture completed; analysis includes all successful kernel logs. There are71compiled profiles,33C2. Kernel bytecode sizes remain438->275(commit),572->360(prepareCompatibleChild),633->238(recursive normalize).

All eight helpers are exercised. Four have standalone C2 profiles; the two reference-resolution and two mask helpers have recorded hot inlining in their exercised C2 kernels. Early C1 refusal and later inlining are retained, not collapsed into a universal inlining claim. Native code sizes vary by call profile and recompilation; the full table and logs remain authoritative. Diagnostic timings are not latency evidence.

No production changes were made after either the original4-block result or this capture. The independently authorized24-block trial remains pending.

from pathlib import Path
import hashlib,json,re
p=Path(__file__).resolve().parent/'shape'
rows=[]
for log in sorted(p.glob('*.log')):
 text=log.read_text(errors='replace')
 for m in re.finditer(r'^Compiled method \((c[12])\) [^\n]*?((?:io\.sirix\.)[^\s]+::[^\s]+) \((\d+) bytes\)\n',text,re.M):
  after=text[m.end():];end=after.find('Compiled method (');body=after if end<0 else after[:end]
  heap=re.search(r'total in heap\s+\[[^\n]*?=\s*(\d+)',body)
  main=re.search(r'main code\s+\[[^\n]*?=\s*(\d+)',body)
  if not(heap and main):continue
  rows.append({'capture':log.name,'compiler':m[1],'method':m[2],'bytecodes':int(m[3]),'main_bytes':int(main[1]),'heap_bytes':int(heap[1])})
(p/'compiled-shape-summary.json').write_text(json.dumps(rows,indent=2))
lines=['# Fresh compiled-shape capture','', 'JDK25, C2, CPU0, synchronous compilation for diagnostics only. Every recompilation and entry point remains distinct. These diagnostics do not supply timing-gate scores. Frozen production hashes and exact commands accompany the raw logs.','', '| Capture | Compiler | Method | Bytecodes | Main bytes | Heap bytes |','|---|---|---|---:|---:|---:|']
for row in rows:
 lines.append('|'+ '|'.join(str(row[k]) for k in ['capture','compiler','method','bytecodes','main_bytes','heap_bytes'])+'|')
(p/'compiled-shape.md').write_text('\n'.join(lines)+'\n')
print('captures=',len(rows),'C2=',sum(row['compiler']=='c2' for row in rows))
for method in sorted({row['method'] for row in rows}):
 print(method,sorted(set((row['compiler'],row['bytecodes'],row['main_bytes']) for row in rows if row['method']==method)))

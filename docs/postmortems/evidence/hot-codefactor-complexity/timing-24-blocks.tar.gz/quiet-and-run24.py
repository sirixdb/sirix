from pathlib import Path
import json,os,shutil,subprocess,sys,time
p=Path(__file__).resolve().parent
assert os.sched_getaffinity(0)=={0}, 'The direct timing wrapper must pin CPU0'
deadline=time.monotonic()+1800
consecutive=0
while consecutive<3:
    loads=os.getloadavg();free=shutil.disk_usage(p).free
    consecutive=consecutive+1 if loads[0]<4 and loads[1]<6 and free>=60*1024**3 else 0
    with (p/'quiet-admission-direct.jsonl').open('a') as output:
        output.write(json.dumps({'at':time.time(),'load':loads,'free_bytes':free,'consecutive':consecutive})+'\n')
    if time.monotonic()>=deadline:raise SystemExit('Quiet admission timed out; no benchmark started')
    if consecutive<3:time.sleep(30)
print('DIRECT EXCLUSIVE TIMING START',time.time(),'cpu=0',flush=True)
try:
    result=subprocess.run(sys.argv[1:],timeout=21600)
    raise SystemExit(result.returncode)
finally:
    print('DIRECT EXCLUSIVE TIMING END',time.time(),flush=True)

# Combined final gate

24 ABBA blocks per case;96 fresh JVMs;five cases. Fixed95% block-log-ratio t interval,df23. All36 measured samples retained,30s real warmup plus50 JMH warmup batches. Commit allocation uses JVM-wide allocated bytes because commit runs on virtual/background threads; insert allocation uses caller-thread bytes. GC-profiler fixture totals are reported separately.

| Case | Units | Before | After | Paired change |95% interval| Bytes before/after |Median paired byte delta|Timed GC|Gate|
|---|---|---:|---:|---:|---|---|---:|---:|---|
|insertAsc4096|ns/key|1025.6665|1028.4748|+0.301%|[-1.149%,+1.773%]|584.467719/583.455566|-0.011719|0|PASS|
|insertDesc4096|ns/key|1259.0910|1249.6007|-0.708%|[-2.247%,+0.856%]|617.816081/616.808594|-0.025391|0|PASS|
|insertDesc50000|ns/key|1624.3371|1625.2312|+0.054%|[-0.518%,+0.630%]|811.749684/810.741279|-0.002080|0|PASS|
|commitDesc4096|ms/commit|5.0922|5.1300|+0.513%|[-3.598%,+4.799%]|240589.731481/240647.152778|+107.666667|0|PASS|
|commitDesc50000|ms/commit|16.1277|15.8614|-1.555%|[-8.853%,+6.328%]|252884.675926/252859.273148|-58.833333|0|PASS|

Overall: PASS

Profiler fixture-inclusive allocation and GC totals:
- insertAsc4096: 670.880216->669.835638 B/key; all GC5827,forced requests3456,timed0.
- insertDesc4096: 690.887573->689.892834 B/key; all GC5749,forced requests3456,timed0.
- insertDesc50000: 817.854850->816.847212 B/key; all GC5990,forced requests3456,timed0.
- commitDesc4096: 3281386.361111->3277204.421296 B/commit fixture; all GC5036,forced requests3456,timed0.
- commitDesc50000: 41280518.745370->41230069.111111 B/commit fixture; all GC5918,forced requests3456,timed0.

#!/usr/bin/env bash
set -euo pipefail
exec env FM_TIMING_CPUS=0 timeout 86400 /home/johannes/IdeaProjects/firstmate/data/tools/timing-window.sh python3 '/home/johannes/IdeaProjects/firstmate/data/sirix-hot-lost-spine-fix/local-codefactor/quiet-and-run24.py' python3 '/home/johannes/IdeaProjects/firstmate/data/sirix-hot-lost-spine-fix/local-codefactor/run-timing24.py' timing

"""Share identical immutable artifacts by hard link while preserving every manifest path and byte."""
from collections import defaultdict
import json
import os
from pathlib import Path
import shutil
import time

from campaign_100m import BASE, EVIDENCE, digest

record_path = EVIDENCE / 'dict-count-frozen-jar-deduplication.json'
if record_path.exists():
    raise RuntimeError('refusing to overwrite deduplication evidence')
known = {}


def retained_entries(value):
    if isinstance(value, list):
        for child in value:
            yield from retained_entries(child)
    elif isinstance(value, dict):
        if 'retained' in value and 'sha256' in value:
            yield value
        else:
            for child in value.values():
                yield from retained_entries(child)


for manifest_path in EVIDENCE.glob('*runtime-manifest.json'):
    manifest = json.loads(manifest_path.read_text())
    for entry in retained_entries(manifest.get('classpath', [])):
        path = Path(entry.get('retained', ''))
        if path.parent.parent != BASE or not path.parent.name.startswith('runtime-') or not path.is_file() or path.suffix != '.jar':
            continue
        if path in known and known[path] != entry['sha256']:
            raise RuntimeError('conflicting immutable artifact manifest: ' + str(path))
        known[path] = entry['sha256']

groups = defaultdict(list)
for path, expected in sorted(known.items()):
    if path.is_symlink() or digest(path) != expected:
        raise RuntimeError('frozen artifact changed: ' + str(path))
    groups[expected].append(path)
record = dict(started=time.time(), before_free_bytes=shutil.disk_usage(BASE).free,
              scope='identical immutable group-repeat/dict-count runtime jars only; all logical paths, bytes and modes retained',
              artifact_count=len(known), unique_hashes=len(groups), replacements=[])


def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')


save()
for checksum, paths in groups.items():
    paths.sort(key=lambda path: ('group-repeat' in path.parent.name or 'dict-count' in path.parent.name, str(path)))
    canonical = paths[0]
    canonical_stat = canonical.stat()
    for target in paths[1:]:
        if 'group-repeat' not in target.parent.name and 'dict-count' not in target.parent.name:
            continue
        target_stat = target.stat()
        if (canonical_stat.st_dev, canonical_stat.st_ino) == (target_stat.st_dev, target_stat.st_ino):
            continue
        if (canonical_stat.st_uid, canonical_stat.st_gid, canonical_stat.st_mode) != (
                target_stat.st_uid, target_stat.st_gid, target_stat.st_mode):
            continue
        temporary = target.with_name(target.name + '.dedup-pending')
        if temporary.exists():
            raise RuntimeError('unexpected pending replacement: ' + str(temporary))
        os.link(canonical, temporary)
        os.replace(temporary, target)
        if digest(target) != checksum:
            raise RuntimeError('deduplicated artifact checksum changed: ' + str(target))
        record['replacements'].append(dict(path=str(target), shared_with=str(canonical), sha256=checksum,
                                           bytes=target_stat.st_size))
        save()
record.update(finished=time.time(), after_free_bytes=shutil.disk_usage(BASE).free)
save()
print(json.dumps(dict(artifacts=len(known), replacements=len(record['replacements']),
                     reclaimed_bytes=record['after_free_bytes'] - record['before_free_bytes'])))


"""Losslessly archive completed profiler captures and inactive native binaries only."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

from campaign_100m import BASE, EVIDENCE, digest

record_path = EVIDENCE / 'dict-count-v3-native-preservation.json'
if record_path.exists():
    raise RuntimeError('refusing to overwrite compaction evidence')
paths = {BASE / relative for relative in (
    'pgo-dict-count-v3-retry1-100m/jb-instr', 'pgo-dict-count-v3-retry1-100m/jb')}
# All source/build trees, databases, active runtimes, training profiles and raw timing logs are excluded.
record = dict(started=time.time(), before_free_bytes=shutil.disk_usage(BASE).free,
              scope='completed profiling captures and explicitly inactive PGO executables/debug files', files=[])


def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')


save()
for source in sorted(paths):
    if source.is_symlink() or not source.is_file() or not source.resolve().is_relative_to(BASE):
        raise RuntimeError('invalid archival source: ' + str(source))
    target = source.with_name(source.name + '.gz')
    expected = digest(source)
    original_stat = source.stat()
    with source.open('rb') as content, target.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as compressed:
            shutil.copyfileobj(content, compressed, 1024 * 1024)
        raw.flush()
        os.fsync(raw.fileno())
    hasher = hashlib.sha256()
    with gzip.open(target, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            hasher.update(block)
    if hasher.hexdigest() != expected or digest(source) != expected:
        raise RuntimeError('exact archival verification failed: ' + str(source))
    entry = dict(original=str(source), original_bytes=original_stat.st_size, original_sha256=expected,
                 retained=str(target), retained_bytes=target.stat().st_size, retained_sha256=digest(target),
                 mode=original_stat.st_mode & 0o777, exact_decompression_verified=True, expanded_removed=False)
    record['files'].append(entry)
    save()
    source.unlink()
    entry['expanded_removed'] = True
    save()
    print('verified and compressed ' + str(source.relative_to(BASE)), flush=True)
record.update(finished=time.time(), after_free_bytes=shutil.disk_usage(BASE).free)
save()
print(json.dumps(dict(files=len(record['files']), reclaimed_bytes=record['after_free_bytes'] - record['before_free_bytes'])))

"""Revalidate the one-off recovery, preservation, and remaining native build peak before retry."""
import json
import math
from pathlib import Path
import shutil
import subprocess

from campaign_100m import BASE, EVIDENCE, digest

output = EVIDENCE / 'dict-count-v3-recovery-budget.json'
if output.exists():
    raise RuntimeError('refusing to overwrite recovery audit')
budget = json.loads((EVIDENCE / 'group-repeat-budget.json').read_text())
assert budget['guard_min_free_gib'] == 66
assert budget['additional_build_allowance_bytes'] == 4 * 1024 ** 3
assert budget['permanent_floor_gib'] == 20
assert budget['column_major_capacity_decision'] == 'open'
guard_names = ('deduplicate-dict-count-base-archives-recovery1', 'deduplicate-dict-count-frozen-jars-attempt1',
               'deduplicate-group-repeat-base-archive-attempt1', 'preserve-inactive-dict-count-images-attempt1',
               'audit-dict-count-v3-preservation-attempt1')
guards = {}
for name in guard_names:
    verdict = json.loads((EVIDENCE / (name + '.verdict.json')).read_text())
    assert verdict['exit_code'] == 0 and not verdict['failures'], name
    guards[name] = dict(samples=verdict['samples'], failures=verdict['failures'])
archives = [BASE / ('source-dict-count-v' + str(version) + '-base.tar.gz') for version in (1, 2, 3)]
expected = 'beae4d882ded4273b3bb58897223b9b578a6e789189f4baccf9fc5e44ee8b828'
archive_stats = []
for path in archives:
    stat = path.stat()
    assert digest(path) == expected and stat.st_size == 110781821 and stat.st_mode & 0o777 == 0o664
    archive_stats.append(dict(path=str(path), sha256=expected, bytes=stat.st_size,
                              inode=stat.st_ino, device=stat.st_dev, mode=stat.st_mode & 0o777))
assert len({(row['device'], row['inode']) for row in archive_stats}) == 1
preservation = json.loads((EVIDENCE / 'column-major-runtime-preservation-audit-dict-count-recovery.json').read_text())
assert preservation['all_manifest_artifacts_available']
baseline = json.loads((EVIDENCE / 'group-repeat-optimized-100m-runtime-manifest.json').read_text())
assert digest(baseline['binary']) == baseline['binary_sha256']
source = json.loads((EVIDENCE / 'dict-count-v3-source.json').read_text())
for relative, checksum in source['overrides'].items():
    assert digest(BASE.parents[1] / relative) == checksum
    assert digest(Path(source['source']) / relative) == checksum
owned = sorted([path for path in BASE.iterdir() if 'group-repeat' in path.name or 'dict-count' in path.name]
    + [path for path in (BASE / 'archived-sources').iterdir() if 'group-repeat' in path.name or 'dict-count' in path.name])
allocations = {str(path): int(subprocess.check_output(['du', '-s', '-B1', str(path)], text=True).split()[0]) for path in owned}
conservative_allocated = sum(allocations.values())
unique_allocated = int(subprocess.check_output(['du', '-s', '-c', '-B1', *map(str, owned)], text=True).splitlines()[-1].split()[0])
telemetry = [json.loads(line) for line in (EVIDENCE / 'instrument-dict-count-v1-100m-attempt1.telemetry.jsonl').read_text().splitlines()]
observed_peak = telemetry[0]['disk_free_bytes'] - min(row['disk_free_bytes'] for row in telemetry)
runtime_copies = max(sum(path.stat().st_blocks * 512 for path in (BASE / name).iterdir() if path.is_file())
    for name in ('runtime-dict-count-v1-instrument-100m', 'runtime-dict-count-v1-optimized-100m'))
profile_size = (BASE / 'pgo-dict-count-v1-100m/jsonbench-100m.iprof').stat().st_size
native_preservation = json.loads((EVIDENCE / 'dict-count-native-preservation.json').read_text())
optimized_size = next(row['original_bytes'] for row in native_preservation['files']
                      if row['original'] == str(BASE / 'pgo-dict-count-v1-100m/jb'))
components = dict(observed_instrument_build_peak=observed_peak, two_runtime_copies=2 * runtime_copies,
                  two_training_profile_copies=2 * profile_size, two_optimized_image_copies=2 * optimized_size,
                  logs_and_attempts_reserve=32 * 1024 ** 2, margin=max(128 * 1024 ** 2, math.ceil(observed_peak * .25)))
projected_peak = sum(components.values())
free = shutil.disk_usage(BASE).free
floor = 66 * 1024 ** 3
record = dict(ordinary_guard_floor_bytes=floor, permanent_floor_bytes=20 * 1024 ** 3,
    one_off_floor_gib=65, one_off_execution_count=1, one_off_scope='only deduplicate-dict-count-base-archives.py',
    guards=guards, archive_stats=archive_stats, free_bytes=free, headroom_above_guard_bytes=free - floor,
    projected_remaining_peak_components=components, projected_remaining_peak_bytes=projected_peak,
    projected_free_at_peak_bytes=free - projected_peak,
    conservative_allocated_bytes=conservative_allocated, unique_allocated_bytes=unique_allocated,
    conservative_projected_peak_allocation=conservative_allocated + projected_peak,
    cumulative_allowance_bytes=budget['additional_build_allowance_bytes'], allocations=allocations,
    disk_fit=free - projected_peak >= floor,
    cumulative_fit=conservative_allocated + projected_peak <= budget['additional_build_allowance_bytes'],
    column_major_capacity_decision='open', all_manifest_artifacts_available=True,
    accepted_timed_binary_unchanged=True, frozen_v3_source_unchanged=True)
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key not in ('allocations', 'archive_stats')}, indent=2), flush=True)
if not record['disk_fit'] or not record['cumulative_fit']:
    raise RuntimeError('remaining build peak plus margin does not fit; do not retry native build')

"""Exact 1M answers and paired JVM layout steering; unranked and independent of native PGO."""
import argparse
import importlib.util
import json
import math
import os
from pathlib import Path

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
label = parser.parse_args().label
manifests = {'before': json.loads((EVIDENCE / 'group-repeat-optimized-100m-runtime-manifest.json').read_text()),
             'after': json.loads((EVIDENCE / (label + '-jvm-runtime-manifest.json')).read_text())}
jdk = BASE / 'graal-25i4'
for name in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS'):
    os.environ.pop(name, None)
flags = ['--enable-preview', '--add-modules', 'jdk.incubator.vector', '--enable-native-access=ALL-UNNAMED',
         '--add-opens', 'java.base/sun.nio.ch=ALL-UNNAMED', '--add-opens', 'java.base/java.nio=ALL-UNNAMED',
         '-Xmx8g', '-Xms2g', '-XX:ActiveProcessorCount=20', '-Dsirix.offheap.bytes=8589934592',
         '-Djava.io.tmpdir=' + str(BASE / 'tmp'), '-Duser.home=' + str(BASE / 'home')]
commands = {}
for name, manifest in manifests.items():
    for entry in manifest['classpath']:
        if digest(entry['retained']) != entry['sha256']:
            raise RuntimeError('changed runtime artifact: ' + entry['retained'])
    for relative, checksum in manifest['runtime_hashes'].items():
        if digest(jdk / relative) != checksum:
            raise RuntimeError('changed JDK: ' + relative)
    commands[name] = [jdk / 'bin/java', *flags, '-cp', ':'.join(entry['retained'] for entry in manifest['classpath'])]
query_main = 'io.sirix.query.bench.jsonbench.JsonBenchRunMain'
databases = {name: BASE / 'db-1m-retention-repaired' for name in commands}
out = BASE / ('paired-' + label + '-jvm-1m-attempt1')
out.mkdir(exist_ok=False)
(out / 'protocol.json').write_text(json.dumps(dict(
    purpose='1M JVM steering of dictionary count fold; not a leaderboard or native PGO score', ranked=False,
    runtime_manifests=manifests, same_database_for_both=True, flags=flags,
    databases={name: str(path) for name, path in databases.items()}, rows=1_000_000,
    source_data_sha256='7beb29f6c036fe784754ff34d68d1f216c6cc89de12155da06f725bdf5c8536e',
    rounds=2, tries=3, order='per-query before/after round1, after/before round2',
    cache='mincore-verified own database eviction before first try; fresh JVM each try; subsequent tries warm OS cache',
    score='geomean((after seconds + .010)/(before seconds + .010))',
    timing='engine query latency including catalog; process wall separately retained'), indent=2) + '\n')
routes = {}
for name, database in databases.items():
    for query in range(1, 6):
        paired.cool()
        stem = out / f'correctness-{name}-q{query}'
        dump = out / f'dump-{name}-q{query}'
        paired.run([*commands[name], '-Dsirix.projDiag=true', '-Dsirix.lz77Codec.diag=true', query_main,
                    database, '--queries', query, '--tries', 1, '--dump', dump], stem)
        routes[name, query] = paired.routes(stem)
        definition = paired.compare.SPECS[query]
        failures = paired.compare.compare(definition, paired.compare.read_dump(dump / f'q{query}.jsonl', definition),
            paired.compare.read_reference(BASE / f'ch26/ch-ref-1m/q{query}.tsv', definition), False)
        (out / f'differential-{name}-q{query}.json').write_text(json.dumps(failures) + '\n')
        if failures:
            raise RuntimeError(f'{name} Q{query} exact mismatch: {failures}')
        if name == 'after' and routes[name, query] != routes['before', query]:
            raise RuntimeError('query route changed with count fold')
        print(f'{name} Q{query}: exact MATCH', flush=True)
rounds = []
for round_number in (1, 2):
    matrix = {name: [] for name in databases}
    for query in range(1, 6):
        order = ('before', 'after') if round_number == 1 else ('after', 'before')
        for name in order:
            database = databases[name]
            paired.cool()
            paired.cold_cache(database, out / f'r{round_number}-q{query}-{name}-eviction.json')
            times = []
            for attempt in (1, 2, 3):
                stem = out / f'r{round_number}-q{query}-{name}-a{attempt}'
                result = stem.with_suffix('.result.json')
                wall = paired.run([*commands[name], query_main, database, '--queries', query, '--tries', 1,
                                   '--json', result], stem)
                counters = paired.routes(stem)
                if counters != routes[name, query]:
                    raise RuntimeError('timing route changed')
                seconds = json.loads(result.read_text())['result'][query - 1][0]
                if not math.isfinite(seconds) or seconds <= 0:
                    raise RuntimeError('invalid query timing')
                times.append(seconds)
                with (out / 'attempts.jsonl').open('a') as stream:
                    stream.write(json.dumps(dict(round=round_number, query=query, variant=name, attempt=attempt,
                                                 seconds=seconds, process_wall_s=wall, counters=counters)) + '\n')
            matrix[name].append(dict(query=query, times=times, cold=times[0], hot=min(times[1:])))
            print(f'round {round_number} {name} Q{query}: {times} (JVM, unranked)', flush=True)
    scores = {mode: math.exp(sum(math.log((a[mode] + .010) / (b[mode] + .010))
                                  for a, b in zip(matrix['after'], matrix['before'])) / 5)
              for mode in ('cold', 'hot')}
    rounds.append(dict(round=round_number, after_over_before=scores, queries=matrix, ranked=False))
    (out / 'rounds.json').write_text(json.dumps(rounds, indent=2) + '\n')
    print(json.dumps(rounds[-1]), flush=True)


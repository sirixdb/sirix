"""Normal-guard metadata preservation for one duplicate immutable source archive."""
import json
import os
import shutil

from campaign_100m import BASE, EVIDENCE, digest

output = EVIDENCE / 'dict-count-recovery-group-base-deduplication.json'
if output.exists():
    raise RuntimeError('refusing to overwrite preservation evidence')
canonical = BASE / 'source-column-major-v5-base.tar.gz'
target = BASE / 'source-group-repeat-v1-base.tar.gz'
expected = json.loads((EVIDENCE / 'column-major-v5-source.json').read_text())['base_archive_sha256']
if json.loads((EVIDENCE / 'group-repeat-v1-source.json').read_text())['base_archive_sha256'] != expected:
    raise RuntimeError('base manifests differ')
before = shutil.disk_usage(BASE).free
old = target.stat()
reference = canonical.stat()
for path in (canonical, target):
    if path.is_symlink() or digest(path) != expected:
        raise RuntimeError('archive checksum differs')
if (old.st_mode, old.st_uid, old.st_gid) != (reference.st_mode, reference.st_uid, reference.st_gid):
    raise RuntimeError('archive ownership or modes differ')
temporary = target.with_name(target.name + '.verified-link')
os.link(canonical, temporary)
os.replace(temporary, target)
if digest(target) != expected or target.stat().st_ino != reference.st_ino:
    raise RuntimeError('archive link verification failed')
record = dict(canonical=str(canonical), path=str(target), bytes=old.st_size, sha256=expected,
              mode=old.st_mode & 0o777, original_inode=old.st_ino, retained_inode=target.stat().st_ino,
              before_free_bytes=before, after_free_bytes=shutil.disk_usage(BASE).free)
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

import com.sun.jdi.ArrayReference;
import com.sun.jdi.Bootstrap;
import com.sun.jdi.LocalVariable;
import com.sun.jdi.Location;
import com.sun.jdi.StackFrame;
import com.sun.jdi.Value;
import com.sun.jdi.VirtualMachine;
import com.sun.jdi.VMDisconnectedException;
import com.sun.jdi.connect.Connector;
import com.sun.jdi.connect.LaunchingConnector;
import com.sun.jdi.event.BreakpointEvent;
import com.sun.jdi.event.ClassPrepareEvent;
import com.sun.jdi.event.Event;
import com.sun.jdi.event.EventSet;
import com.sun.jdi.event.VMDeathEvent;
import com.sun.jdi.event.VMDisconnectEvent;
import com.sun.jdi.request.BreakpointRequest;
import com.sun.jdi.request.ClassPrepareRequest;
import com.sun.jdi.request.EventRequest;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;

/** Diagnostic only: observe the existing compiled kernel without changing its bytecode. */
public final class ObserveDictionaryCount {
  public static void main(String[] args) throws Exception {
    final List<String> config = Files.readAllLines(Path.of(args[0]));
    final LaunchingConnector connector = Bootstrap.virtualMachineManager().defaultConnector();
    final Map<String, Connector.Argument> arguments = connector.defaultArguments();
    arguments.get("home").setValue(config.get(0));
    arguments.get("options").setValue(config.get(1));
    arguments.get("main").setValue(config.get(2));
    final VirtualMachine vm = connector.launch(arguments);
    final Thread stdout = copy(vm.process().getInputStream(), Path.of(args[1] + ".stdout"));
    final Thread stderr = copy(vm.process().getErrorStream(), Path.of(args[1] + ".stderr"));
    final ClassPrepareRequest prepare = vm.eventRequestManager().createClassPrepareRequest();
    prepare.addClassFilter("io.sirix.index.projection.ProjectionColumnGroupScan");
    prepare.setSuspendPolicy(EventRequest.SUSPEND_ALL);
    prepare.enable();
    boolean done = false;
    vm.resume();
    try {
      while (!done) {
        final EventSet events = vm.eventQueue().remove();
        for (final Event event : events) {
          if (event instanceof ClassPrepareEvent loaded) {
            for (int i = 3; i < config.size(); i++) {
              final String[] target = config.get(i).split("=", 2);
              final List<Location> locations = loaded.referenceType().locationsOfLine(Integer.parseInt(target[1]));
              if (locations.size() != 1) {
                throw new IllegalStateException("ambiguous breakpoint " + config.get(i) + ": " + locations);
              }
              final BreakpointRequest request = vm.eventRequestManager().createBreakpointRequest(locations.get(0));
              request.putProperty("label", target[0]);
              request.setSuspendPolicy(EventRequest.SUSPEND_ALL);
              request.enable();
            }
          } else if (event instanceof BreakpointEvent hit) {
            final String label = (String) hit.request().getProperty("label");
            System.out.println("OBSERVED " + label + " " + hit.location());
            if (label.equals("eligibility")) {
              final StackFrame frame = hit.thread().frame(0);
              for (final String name : List.of("countOnly", "keyCount", "keyKinds", "keyOffsets", "keySubstr", "keyDivMod", "keyCondCols")) {
                final LocalVariable variable = frame.visibleVariableByName(name);
                if (variable == null) {
                  throw new IllegalStateException("missing debug variable " + name);
                }
                final Value value = frame.getValue(variable);
                System.out.println("ANNOTATION " + name + "=" + (value instanceof ArrayReference array ? array.getValues() : value));
              }
            }
            // One observation proves execution. Further debugger stops add no evidence.
            hit.request().disable();
          } else if (event instanceof VMDeathEvent || event instanceof VMDisconnectEvent) {
            done = true;
          }
        }
        events.resume();
      }
    } catch (VMDisconnectedException disconnected) {
      done = true;
    }
    final int result = vm.process().waitFor();
    stdout.join();
    stderr.join();
    System.out.println("TARGET_EXIT " + result);
    if (result != 0) {
      throw new IllegalStateException("query process failed: " + result);
    }
  }

  private static Thread copy(final InputStream stream, final Path path) {
    final Thread thread = new Thread(() -> {
      try (stream; var out = Files.newOutputStream(path)) {
        stream.transferTo(out);
      } catch (Exception failure) {
        throw new IllegalStateException(failure);
      }
    });
    thread.start();
    return thread;
  }
}

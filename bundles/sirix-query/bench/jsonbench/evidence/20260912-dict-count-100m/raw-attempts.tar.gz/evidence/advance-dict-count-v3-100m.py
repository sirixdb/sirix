"""Fresh native training and full-size comparisons after the complete JVM gate."""
import json
from datetime import datetime, timezone

from group_repeat_campaign import BASE, EVIDENCE, phase

candidate = 'dict-count-v3'
prerequisite = json.loads((EVIDENCE / ('check-' + candidate + '-jvm-1m-attempt1.verdict.json')).read_text())
if prerequisite['exit_code'] or prerequisite['failures']:
    raise RuntimeError('1M correctness and steering must pass first')

positive = json.loads((BASE / 'diagnostic-dict-count-v3-compiler-q1/result.json').read_text())
negative = json.loads((BASE / 'diagnostic-dict-count-v3-transform-control-attempt2/result.json').read_text())
if not positive['shortcut_observed'] or not positive['exact_match']:
    raise RuntimeError('actual canonical Q1 shortcut proof required')
if negative['shortcut_observed'] or not negative['nonzero_substring_observed']:
    raise RuntimeError('actual transformed-key negative control required')
for guard in ('observe-dict-count-v3-compiler-q1-attempt1', 'control-dict-count-v3-transforms-attempt2'):
    verdict = json.loads((EVIDENCE / (guard + '.verdict.json')).read_text())
    if verdict['exit_code'] or verdict['failures']:
        raise RuntimeError('compiler proof guard failed')


def stage(name, command):
    state_path = EVIDENCE / 'active-campaign-state.json'
    state = json.loads(state_path.read_text())
    state.update(phase=name, driver=str(EVIDENCE / 'advance-dict-count-v3-100m.py'),
                 updated_utc=datetime.now(timezone.utc).isoformat())
    state_path.write_text(json.dumps(state, indent=2) + '\n')
    phase(name, command)


stage('instrument-dict-count-v3-100m-attempt1',
      ['bash', EVIDENCE / 'dict-count-lane.sh', 'instrument', candidate])
stage('freeze-instrument-dict-count-v3-100m',
      ['python3', EVIDENCE / 'freeze-runtime.py', '--label', 'dict-count-v3-instrument-100m',
       '--log', EVIDENCE / 'instrument-dict-count-v3-100m-attempt1.log',
       '--binary', BASE / 'pgo-dict-count-v3-100m/jb-instr', '--jdk', BASE / 'graal-25i4'])
stage('train-dict-count-v3-100m-attempt1', ['python3', EVIDENCE / 'train-dict-count-v3-100m.py'])
stage('optimize-dict-count-v3-100m-attempt1',
      ['bash', EVIDENCE / 'dict-count-lane.sh', 'optimize', candidate])
stage('freeze-optimized-dict-count-v3-100m',
      ['python3', EVIDENCE / 'freeze-runtime.py', '--label', 'dict-count-v3-optimized-100m',
       '--log', EVIDENCE / 'optimize-dict-count-v3-100m-attempt1.log',
       '--binary', BASE / 'pgo-dict-count-v3-100m/jb',
       '--profile', BASE / 'pgo-dict-count-v3-100m/jsonbench-100m.iprof', '--jdk', BASE / 'graal-25i4'])
stage('check-dict-count-v3-before-after-100m-attempt1',
      ['python3', EVIDENCE / 'check-dict-count-v3-before-after-100m.py'])
stage('audit-dict-count-v3-before-after-100m-attempt1',
      ['python3', EVIDENCE / 'audit-dict-count-v3-comparison.py', '--tier', '100m'])
stage('paired-dict-count-v3-100m-attempt1',
      ['python3', EVIDENCE / 'paired-retention-100m.py', '--tier', '100m',
       '--sirix', BASE / 'pgo-dict-count-v3-100m/jb', '--db', BASE / 'db-100m-retention',
       '--ch-db', BASE / 'ch26/ch-data-100m', '--rows', '99999968', '--tries', '3', '--rounds', '2',
       '--out', BASE / 'paired-dict-count-v3-100m-attempt1'])
stage('audit-dict-count-v3-paired-100m-attempt1', ['python3', EVIDENCE / 'audit-dict-count-v3-paired-100m.py'])
state_path = EVIDENCE / 'active-campaign-state.json'
state = json.loads(state_path.read_text())
state.update(phase='dict-count-v3-full-size-pairs-complete-awaiting-assessment',
             exec_session=None, driver_pid=None, updated_utc=datetime.now(timezone.utc).isoformat())
state_path.write_text(json.dumps(state, indent=2) + '\n')
print('Complete paired 100M evidence retained; assess the candidate and remaining leader gap.', flush=True)


"""Freeze the fresh JVM build, checking every reported dependency against the prior toolchain."""
import argparse
import json
from pathlib import Path
import shutil

from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
args = parser.parse_args()
if not args.label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in args.label):
    parser.error('invalid candidate label')
label = args.label
source = BASE / ('source-' + label)
manifest_path = EVIDENCE / (label + '-source.json')
source_manifest = json.loads(manifest_path.read_text())
for relative, expected in source_manifest['overrides'].items():
    if digest(source / relative) != expected:
        raise RuntimeError('source changed after freeze: ' + relative)
for phase in ('test-', 'jvm-'):
    verdict = json.loads((EVIDENCE / (phase + label + '.verdict.json')).read_text())
    if verdict['exit_code'] or verdict['failures']:
        raise RuntimeError('phase did not pass: ' + phase + label)
prior = json.loads((EVIDENCE / 'retention-final-jvm-runtime-manifest.json').read_text())
log_path = EVIDENCE / ('jvm-' + label + '.log')
reported = next(line for line in log_path.read_text().splitlines()
                if line.startswith(str(source / 'bundles/sirix-query/build/classes/java/main') + ':'))
expected_reported = prior['reported_classpath'].replace('/source-retention-final/', '/source-' + label + '/')
if reported != expected_reported:
    raise RuntimeError('runtime classpath changed; review every dependency before freezing')
store = BASE / ('runtime-' + label + '-jvm')
store.mkdir()
artifacts = []
for i, entry in enumerate(prior['classpath']):
    path = Path(entry['source'].replace('/source-retention-final/', '/source-' + label + '/'))
    if not path.is_relative_to(source) and digest(path) != entry['sha256']:
        raise RuntimeError('dependency changed: ' + str(path))
    dest = store / (str(i) + '-' + path.name)
    shutil.copy2(path, dest)
    artifacts.append(dict(source=str(path), retained=str(dest), sha256=digest(dest)))
jdk = BASE / 'graal-25i4'
runtime_hashes = {relative: digest(jdk / relative) for relative in prior['runtime_hashes']}
if runtime_hashes != prior['runtime_hashes']:
    raise RuntimeError('JDK changed')
manifest = dict(label=label, source_manifest=str(manifest_path), source_manifest_sha256=digest(manifest_path),
                classpath=artifacts, reported_classpath=reported, build_log_sha256=digest(log_path),
                jdk=str(jdk), jdk_release=(jdk / 'release').read_text(), runtime_hashes=runtime_hashes)
output = EVIDENCE / (label + '-jvm-runtime-manifest.json')
with output.open('x') as stream:
    stream.write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(label=label, classpath_artifacts=len(artifacts))))


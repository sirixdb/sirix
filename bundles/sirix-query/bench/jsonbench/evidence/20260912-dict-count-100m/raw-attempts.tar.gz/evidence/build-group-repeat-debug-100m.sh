#!/usr/bin/env bash
set -euo pipefail
campaign_dir='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign'
export JAVA_HOME="$campaign_dir/graal-25i4"
export PATH="$JAVA_HOME/bin:$PATH"
export GRADLE_USER_HOME="$campaign_dir/gradle-home"
export TMPDIR="$campaign_dir/tmp"
export GRADLE="$GRADLE_USER_HOME/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle"
export GRADLE_FLAGS="--offline --no-daemon --no-build-cache --rerun-tasks --max-workers=4 --init-script=$campaign_dir/evidence/build-debug.gradle -Dorg.gradle.jvmargs=-Xmx2g"
export JAVA_TOOL_OPTIONS="-XX:ActiveProcessorCount=6 -Djava.io.tmpdir=$campaign_dir/tmp -Duser.home=$campaign_dir/home"
unset _JAVA_OPTIONS JDK_JAVA_OPTIONS
export BUILDER_XMX=12g
test ! -e "$campaign_dir/pgo-group-repeat-debug-100m"
mkdir "$campaign_dir/pgo-group-repeat-debug-100m"
cp "$campaign_dir/pgo-group-repeat-100m/jsonbench-100m.iprof" "$campaign_dir/pgo-group-repeat-debug-100m/jsonbench-100m.iprof"
cmp "$campaign_dir/pgo-group-repeat-100m/jsonbench-100m.iprof" "$campaign_dir/pgo-group-repeat-debug-100m/jsonbench-100m.iprof"
bash "$campaign_dir/source-group-repeat-v1/bundles/sirix-query/bench/jsonbench/pgo-native.sh" \
    "$campaign_dir/db-100m-retention" --tier 100m --out "$campaign_dir/pgo-group-repeat-debug-100m" --steps 3
cp "$campaign_dir/source-group-repeat-v1/bundles/sirix-query/build/native/nativeCompile/jb.debug" "$campaign_dir/pgo-group-repeat-debug-100m/jb.debug"

import io.brackit.query.Query;
import io.brackit.query.compiler.translator.SequentialPipelineStrategy;
import io.sirix.api.json.JsonResourceSession;
import io.sirix.index.projection.ProjectionIndexCatalog;
import io.sirix.index.projection.ProjectionIndexRegistry;
import io.sirix.query.SirixCompileChain;
import io.sirix.query.SirixQueryContext;
import io.sirix.query.json.BasicJsonDBStore;
import io.sirix.query.json.JsonDBCollection;
import io.sirix.query.scan.SirixVectorizedExecutor;
import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.nio.file.Path;

/** Diagnostic control for the exact transformed query from the failed v2 regression. */
public final class DictionaryTransformControl {
  public static void main(String[] args) throws Exception {
    final Path location = Path.of(args[0]);
    if (args[1].equals("create")) {
      final String[] values = {"10", "11", "20", "21"};
      final StringBuilder data = new StringBuilder(8192).append('[');
      for (int row = 0; row < 240; row++) {
        if (row != 0) {
          data.append(',');
        }
        data.append("{\"commit\":{\"collection\":\"").append(values[row % values.length]).append("\"}}");
      }
      data.append(']');
      try (final BasicJsonDBStore store = BasicJsonDBStore.newBuilder().location(location).build();
          final SirixQueryContext ctx = SirixQueryContext.createWithJsonStore(store);
          final SirixCompileChain chain = SirixCompileChain.createWithJsonStore(store)) {
        new Query(chain, "jn:store('json-path1','jbshape.jn','" + data + "')").evaluate(ctx);
        new Query(chain, """
            let $doc := jn:doc('json-path1','jbshape.jn')
            let $stats := jn:create-projection-index($doc, '/[]',
                ('/[]/kind', '/[]/did', '/[]/time_us', '/[]/commit/collection', '/[]/commit/operation', '/[]/commit/rev'),
                ('string', 'string', 'long', 'string', 'string', 'long'))
            return {"revision": sdb:commit($doc)}
            """).evaluate(ctx);
      }
    }
    ProjectionIndexRegistry.clear();
    ProjectionIndexCatalog.clearCache();
    SequentialPipelineStrategy.setVectorizedExecutor(null);
    try (final BasicJsonDBStore store = BasicJsonDBStore.newBuilder().location(location).build();
        final SirixQueryContext ctx = SirixQueryContext.createWithJsonStore(store);
        final SirixCompileChain chain = SirixCompileChain.createWithJsonStore(store)) {
      final JsonDBCollection collection = (JsonDBCollection) store.lookup("json-path1");
      final JsonResourceSession session = collection.getDatabase().beginResourceSession("jbshape.jn");
      final SirixVectorizedExecutor executor = new SirixVectorizedExecutor(session, session.getMostRecentRevisionNumber(), 2);
      try {
        final String[] suffixes = {" + 0", "", " + 3"};
        for (int i = 0; i < suffixes.length; i++) {
          final String query = """
              for $e in jn:doc('json-path1','jbshape.jn')[]
              let $k := xs:integer(substring($e.commit.collection, 1, 1))%s
              group by $k
              let $c := count($e)
              order by $c descending
              return {"event": $k, "count": $c}
              """.formatted(suffixes[i]);
          System.out.println("QUERY\t" + i + "\t" + query.replace("\n", "\\n"));
          SequentialPipelineStrategy.setVectorizedExecutor(null);
          final String interpreted = evaluate(chain, ctx, query);
          SequentialPipelineStrategy.setVectorizedExecutor(executor);
          final long before = SirixVectorizedExecutor.groupAggServedCount();
          final String served = evaluate(chain, ctx, query);
          final long route = SirixVectorizedExecutor.groupAggServedCount() - before;
          System.out.println("CASE\t" + i + "\t" + route + "\t" + interpreted + "\t" + served);
          final int offset = i == 2 ? 3 : 0;
          final String expected = "{\"event\":" + (1 + offset) + ",\"count\":120} {\"event\":" + (2 + offset) + ",\"count\":120}";
          if (!expected.equals(interpreted) || !interpreted.equals(served) || route != (i == 1 ? 1 : 0)) {
            throw new IllegalStateException("transformed query contract differs in case " + i);
          }
        }
      } finally {
        SequentialPipelineStrategy.setVectorizedExecutor(null);
        executor.close();
      }
    }
  }

  private static String evaluate(final SirixCompileChain chain, final SirixQueryContext ctx, final String query) throws Exception {
    try (final ByteArrayOutputStream out = new ByteArrayOutputStream(); final PrintWriter writer = new PrintWriter(out)) {
      new Query(chain, query).serialize(ctx, writer);
      writer.flush();
      return out.toString();
    }
  }
}

# Read-only assessment requested by inbox 030

The proposed filesystem copy-on-write clone is not available on the database's current filesystem.
No clone, database write, index rebuild, migration or mount change was attempted. The separate
column-major capacity decision remains open, and the exact-group experiment continues independently.

Observed with `findmnt -T` and `stat -f`: the database lives on an eCryptfs mount at
`/home/johannes`, backed by `/home/.ecryptfs/johannes/.Private` on ext4 `/dev/nvme0n1p7`.
The running kernel is `6.8.0-138-generic`. Merely having XFS/Btrfs modules configured does not
provide their capabilities to these mounted files.

The upstream Linux v6.8 implementations of both
[eCryptfs file operations](https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/refs/tags/v6.8/fs/ecryptfs/file.c)
and [ext4 file operations](https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/refs/tags/v6.8/fs/ext4/file.c)
have no `remap_file_range` operation. The
[VFS clone implementation](https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/refs/tags/v6.8/fs/remap_range.c)
returns `EOPNOTSUPP` when that operation is absent (lines 391–392). This source inspection supports
the negative feasibility conclusion; it is not presented as an executed clone test against the
Ubuntu kernel. The three inspected source files and their SHA-256 hashes are retained in
`reflink-feasibility-kernel-6.8/downloads.json` (52,703 downloaded bytes total).

An ordinary copy would allocate another full document store. Hard links would share writable
inodes and violate baseline isolation. Neither is a substitute for a supported independent CoW
clone, and neither was attempted.

## Sirix semantics if storage support were available elsewhere

`CreateProjectionIndex.buildViaController` creates the index through `JsonIndexController`, with
the next unallocated physical index id; it does not commit on the caller's behalf. Creation of an
existing valid definition returns that definition; a stale/populated definition cannot be rebuilt
in place. The replacement sequence is drop the definition, commit, then create a new definition
and commit. `ProjectionIndexHOTStorage.requireVirginTreeForInitialBuild` explicitly enforces the
empty-tree boundary. With v5, the fresh tree could select column-major slots; its metadata records
that layout, while old revisions retain the old tree and row-major format.

`JsonIndexController.createIndexes` / `ProjectionIndexBuilder.buildAndPersist` traverse the finished
resource to create all projection payloads. This is a full-resource setup pass, not merely rewriting
directory keys. It would write a new projection, its side pages, dictionary and revision/catalog
metadata; historical pages remain reachable. Therefore a hypothetical CoW clone would still need
new physical extents for the complete new projection and changed file metadata. The retained
whole-store size and in-memory projected weights do not establish that disk delta. There is no
evidence that such a rebuild fits the 4 GiB allowance. A space estimate and explicit authorization
for this setup path would still be required; the feasibility question grants neither.

To validate such a future experiment, the baseline would need to remain closed for writes with
independent cloned inodes and verified pre/post file identities and hashes. The query revision,
new index id, root path, fields/types, persisted layout and active catalog selection would need to
be recorded. Metadata row count and all five exact ClickHouse differential answers would need to
match before accepting timing; route counters would need to prove the new index is actually used.
Old and new catalog entries must not compete to answer the same query.

Cold-cache comparison would also require a separately documented protocol. Both inode sets would
need matching fsync/advice/mincore treatment and alternating run order; shared physical extents
cannot be called device-cold merely because one inode's resident-page check is zero. Any underlying
eCryptfs cache behavior must retain the same explicit cache classification for both sides. Rebuild,
verification and PGO training stay outside ranked latency under the same continuous guard.

Conclusion: this is not an available smaller route on the present eCryptfs/ext4 stack. The existing
database exact-group experiment needs no filesystem clone and remains within its separate build
allowance; it does not resolve the captain-held new-database capacity decision.

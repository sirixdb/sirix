"""Canonical Q1, actual compiler, diagnostic JDI branch observation; never ranked."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess

from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--expect-shortcut', choices=('yes', 'no'), required=True)
args = parser.parse_args()
label = args.label
out = BASE / ('diagnostic-' + label + '-compiler-q1')
out.mkdir(exist_ok=False)
manifest = json.loads((EVIDENCE / (label + '-jvm-runtime-manifest.json')).read_text())
for entry in manifest['classpath']:
    if digest(entry['retained']) != entry['sha256']:
        raise RuntimeError('runtime changed: ' + entry['retained'])
source = BASE / ('source-' + label) / 'bundles/sirix-core/src/main/java/io/sirix/index/projection/ProjectionColumnGroupScan.java'
lines = source.read_text().splitlines()
markers = {'eligibility': 'final boolean dictionaryCount =', 'shortcut': 'final int missingId = keyCols[0][leaf].dictSize();',
           'fallback': 'final boolean subTransformed = keySubstr != null'}
breakpoints = {}
for name, marker in markers.items():
    matches = [i + 1 for i, line in enumerate(lines) if marker in line]
    if len(matches) != 1:
        raise RuntimeError('ambiguous source marker: ' + marker)
    breakpoints[name] = matches[0]
flags = ['--enable-preview', '--add-modules=jdk.incubator.vector', '--enable-native-access=ALL-UNNAMED',
         '--add-opens=java.base/sun.nio.ch=ALL-UNNAMED', '--add-opens=java.base/java.nio=ALL-UNNAMED',
         '-Xmx8g', '-Xms2g', '-XX:ActiveProcessorCount=20', '-Dsirix.offheap.bytes=8589934592',
         '-Djava.io.tmpdir=' + str(BASE / 'tmp'), '-Duser.home=' + str(BASE / 'home'),
         '-Dsirix.projDiag=true', '-cp', ':'.join(entry['retained'] for entry in manifest['classpath'])]
main = ['io.sirix.query.bench.jsonbench.JsonBenchRunMain', str(BASE / 'db-1m-retention-repaired'),
        '--queries', '1', '--tries', '1', '--dump', str(out / 'dump')]
if any(any(c.isspace() for c in arg) for arg in flags + main):
    raise RuntimeError('JDI command quoting required')
config = out / 'launch.txt'
config.write_text('\n'.join([str(BASE / 'graal-25i4'), ' '.join(flags), ' '.join(main),
                             *[name + '=' + str(line) for name, line in breakpoints.items()]]) + '\n')
env = {k: v for k, v in os.environ.items() if k not in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')}
with (out / 'observation.txt').open('x') as stream:
    subprocess.run([BASE / 'graal-25i4/bin/java', '--add-modules=jdk.jdi', '-XX:ActiveProcessorCount=6',
                    '-Djava.io.tmpdir=' + str(BASE / 'tmp'), EVIDENCE / 'ObserveDictionaryCount.java',
                    config, out / 'q1'], stdout=stream, stderr=subprocess.STDOUT, env=env, check=True)
observations = (out / 'observation.txt').read_text()
if ('OBSERVED shortcut ' in observations) != (args.expect_shortcut == 'yes'):
    raise RuntimeError('shortcut observation differs from expected counterfactual')
required = ['OBSERVED eligibility ', 'ANNOTATION countOnly=true', 'ANNOTATION keyCount=1',
            'ANNOTATION keyOffsets=[0]', 'ANNOTATION keySubstr=[0, 0]', 'ANNOTATION keyDivMod=null',
            'ANNOTATION keyCondCols=[-1, -1]', 'TARGET_EXIT 0']
if any(value not in observations for value in required):
    raise RuntimeError('actual compiler annotations differ: ' + observations)
spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
definition = paired.compare.SPECS[1]
failures = paired.compare.compare(definition, paired.compare.read_dump(out / 'dump/q1.jsonl', definition),
    paired.compare.read_reference(BASE / 'ch26/ch-ref-1m/q1.tsv', definition), False)
if failures:
    raise RuntimeError('Q1 exact mismatch: ' + str(failures))
record = dict(ranked=False, purpose='actual canonical Q1 compiler counterfactual, JDI breakpoints',
              shortcut_observed=args.expect_shortcut == 'yes', exact_match=True,
              route=paired.routes(out / 'q1'), breakpoints=breakpoints, runtime_manifest=manifest,
              source_sha256=digest(source), observation=observations)
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(observations, flush=True)
print('PASS exact canonical Q1 and expected shortcut observation', flush=True)

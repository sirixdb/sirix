"""Freeze, test and observe the corrected compiler path before any further native build."""
import json
from datetime import datetime, timezone
import shutil
import xml.etree.ElementTree as ET

from group_repeat_campaign import BASE, EVIDENCE, phase

candidate = 'dict-count-v3'


def stage(name, command):
    state_path = EVIDENCE / 'active-campaign-state.json'
    state = json.loads(state_path.read_text())
    state.update(phase=name, candidate=candidate, driver=str(EVIDENCE / 'preflight-dict-count-v3.py'),
                 updated_utc=datetime.now(timezone.utc).isoformat())
    state_path.write_text(json.dumps(state, indent=2) + '\n')
    phase(name, command)


stage('freeze-dict-count-v3-source', ['python3', EVIDENCE / 'freeze-candidate-source.py', '--label', candidate,
    '--include', 'bundles/sirix-core/src/main/java/io/sirix/index/projection/ProjectionColumnGroupScan.java',
    '--include', 'bundles/sirix-core/src/test/java/io/sirix/index/projection/DictionaryCountFoldTest.java',
    '--include', 'bundles/sirix-query/src/test/java/io/sirix/query/JsonBenchShapeServingTest.java'])
stage('test-' + candidate, ['bash', EVIDENCE / 'dict-count-lane.sh', 'test', candidate])
results = EVIDENCE / (candidate + '-test-results')
results.mkdir(exist_ok=False)
suites = []
for module in ('sirix-core', 'sirix-query'):
    for path in sorted((BASE / ('source-' + candidate) / 'bundles' / module / 'build/test-results/test').glob('TEST-*.xml')):
        root = ET.parse(path).getroot()
        if int(root.attrib['failures']) or int(root.attrib['errors']) or int(root.attrib['skipped']):
            raise RuntimeError('test suite did not pass: ' + str(path))
        shutil.copy2(path, results / path.name)
        suites.append(dict(name=root.attrib['name'], tests=int(root.attrib['tests'])))
if sum(suite['tests'] for suite in suites) != 83:
    raise RuntimeError('unexpected focused test count')
(results / 'manifest.json').write_text(json.dumps(dict(tests=83, suites=suites,
    source_manifest=json.loads((EVIDENCE / (candidate + '-source.json')).read_text())), indent=2) + '\n')
stage('jvm-' + candidate, ['bash', EVIDENCE / 'dict-count-lane.sh', 'jvm', candidate])
stage('freeze-' + candidate + '-jvm', ['python3', EVIDENCE / 'freeze-dict-count-jvm.py', '--label', candidate])
stage('observe-' + candidate + '-compiler-q1-attempt1',
      ['python3', EVIDENCE / 'observe-dict-count.py', '--label', candidate, '--expect-shortcut', 'yes'])
stage('check-' + candidate + '-jvm-1m-attempt1',
      ['python3', EVIDENCE / 'check-dict-count-jvm-1m.py', '--label', candidate])
stage('audit-' + candidate + '-jvm-1m-attempt1',
      ['python3', EVIDENCE / 'audit-dict-count-v3-comparison.py', '--tier', '1m'])
print('Preflight passed; inspect actual compiler observation before native build.', flush=True)

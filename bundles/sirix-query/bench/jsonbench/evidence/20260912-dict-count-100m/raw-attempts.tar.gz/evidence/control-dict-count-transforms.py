"""Baseline/candidate control and diagnostic-only proof of transformed-key exclusion."""
import json
import os
from pathlib import Path
import subprocess

from campaign_100m import BASE, EVIDENCE, digest

out = BASE / 'diagnostic-dict-count-v3-transform-control-attempt2'
out.mkdir(exist_ok=False)
classes = out / 'classes'
classes.mkdir()
fixture = out / 'fixture'
jdk = BASE / 'graal-25i4'
manifests = {'baseline': json.loads((EVIDENCE / 'group-repeat-optimized-100m-runtime-manifest.json').read_text()),
             'candidate': json.loads((EVIDENCE / 'dict-count-v3-jvm-runtime-manifest.json').read_text())}
env = {key: value for key, value in os.environ.items() if key not in ('JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS')}
classpath = {}
for name, manifest in manifests.items():
    for entry in manifest['classpath']:
        if digest(entry['retained']) != entry['sha256']:
            raise RuntimeError('runtime artifact changed')
    classpath[name] = str(classes) + ':' + ':'.join(entry['retained'] for entry in manifest['classpath'])
subprocess.run([jdk / 'bin/javac', '--enable-preview', '--release', '25', '-cp', classpath['baseline'],
                '-d', classes, EVIDENCE / 'DictionaryTransformControl.java'], check=True, env=env)
flags = ['--enable-preview', '--add-modules=jdk.incubator.vector', '--enable-native-access=ALL-UNNAMED',
         '--add-opens=java.base/sun.nio.ch=ALL-UNNAMED', '--add-opens=java.base/java.nio=ALL-UNNAMED',
         '-Xmx2g', '-XX:ActiveProcessorCount=6', '-Dsirix.offheap.bytes=268435456',
         '-Djava.io.tmpdir=' + str(BASE / 'tmp'), '-Duser.home=' + str(BASE / 'home')]
with (out / 'baseline.stdout').open('x') as stdout, (out / 'baseline.stderr').open('x') as stderr:
    subprocess.run([jdk / 'bin/java', *flags, '-cp', classpath['baseline'], 'DictionaryTransformControl', fixture, 'create'],
                   stdout=stdout, stderr=stderr, check=True, env=env)
source = BASE / 'source-dict-count-v3/bundles/sirix-core/src/main/java/io/sirix/index/projection/ProjectionColumnGroupScan.java'
lines = source.read_text().splitlines()
markers = {'eligibility': 'final boolean dictionaryCount =', 'shortcut': 'final int missingId = keyCols[0][leaf].dictSize();',
           'fallback': 'final boolean subTransformed = keySubstr != null'}
breakpoints = {}
for name, marker in markers.items():
    matches = [i + 1 for i, line in enumerate(lines) if marker in line]
    if len(matches) != 1:
        raise RuntimeError('ambiguous source marker')
    breakpoints[name] = matches[0]
config = out / 'launch.txt'
config.write_text('\n'.join([str(jdk), ' '.join([*flags, '-cp', classpath['candidate']]),
    ' '.join(['DictionaryTransformControl', str(fixture), 'run']),
    *[name + '=' + str(line) for name, line in breakpoints.items()]]) + '\n')
with (out / 'observation.txt').open('x') as stream:
    subprocess.run([jdk / 'bin/java', '--add-modules=jdk.jdi', '-XX:ActiveProcessorCount=6',
        '-Djava.io.tmpdir=' + str(BASE / 'tmp'), EVIDENCE / 'ObserveDictionaryCount.java', config, out / 'candidate'],
        stdout=stream, stderr=subprocess.STDOUT, env=env, check=True)
observations = (out / 'observation.txt').read_text()
if 'OBSERVED shortcut ' in observations or 'TARGET_EXIT 0' not in observations:
    raise RuntimeError('transformed keys entered the histogram or target failed')
if 'ANNOTATION keySubstr=[1, 1]' not in observations or 'OBSERVED fallback ' not in observations:
    raise RuntimeError('missing direct negative proof for a nonzero substring transform')
records = {name: [line for line in (out / (name + '.stdout')).read_text().splitlines() if line.startswith(('QUERY\t', 'CASE\t'))]
           for name in ('baseline', 'candidate')}
if records['baseline'] != records['candidate'] or len(records['baseline']) != 6:
    raise RuntimeError('baseline/candidate results or routes differ')
record = dict(ranked=False, baseline_commit='d685cae276ae7055311a64e4e4b62b92d443f9a8',
              fixture_rows=240, same_fixture=True, runtime_manifests=manifests, records=records,
              expected_routes={'cast_plus_zero': 0, 'bare_cast': 1, 'cast_plus_three': 0},
              shortcut_observed=False, nonzero_substring_observed=True, observation=observations,
              helper_sha256=digest(EVIDENCE / 'DictionaryTransformControl.java'))
(out / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({key: value for key, value in record.items() if key != 'runtime_manifests'}, indent=2), flush=True)

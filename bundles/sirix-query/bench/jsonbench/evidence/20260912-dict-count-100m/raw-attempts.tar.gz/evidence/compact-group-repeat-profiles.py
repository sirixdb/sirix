"""Losslessly compress completed per-attempt profiles; no databases, builds or training inputs touched."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

from campaign_100m import BASE, EVIDENCE, digest

record_path = EVIDENCE / 'group-repeat-profile-compaction.json'
if record_path.exists():
    raise RuntimeError('refusing to overwrite compaction evidence')
guard = json.loads((EVIDENCE / 'check-group-repeat-instrument-1m-attempt1.verdict.json').read_text())
if guard['exit_code'] or guard['failures']:
    raise RuntimeError('current instrumented attempts have not finished successfully')
paths = sorted((BASE / 'paired-group-repeat-instrument-1m-attempt1').glob('*.iprof'))
if len(paths) != 70:
    raise RuntimeError('expected exactly 70 completed group-repeat profiles')
record = dict(started=time.time(), before_free_bytes=shutil.disk_usage(BASE).free,
              scope='completed paired-attempt profiles only; training profiles and all databases preserved', files=[])


def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')


save()
for source in paths:
    if source.is_symlink() or not source.is_file() or not source.resolve().is_relative_to(BASE):
        raise RuntimeError('invalid campaign profile path: ' + str(source))
    target = source.with_suffix('.iprof.gz')
    checksum = digest(source)
    size = source.stat().st_size
    with source.open('rb') as content, target.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as compressed:
            shutil.copyfileobj(content, compressed, 1024 * 1024)
        raw.flush()
        os.fsync(raw.fileno())
    restored = hashlib.sha256()
    with gzip.open(target, 'rb') as content:
        for block in iter(lambda: content.read(1024 * 1024), b''):
            restored.update(block)
    if restored.hexdigest() != checksum or digest(source) != checksum:
        raise RuntimeError('profile verification failed: ' + str(source))
    entry = dict(original=str(source), original_bytes=size, original_sha256=checksum,
                 retained=str(target), retained_bytes=target.stat().st_size, retained_sha256=digest(target),
                 exact_decompression_verified=True, expanded_removed=False)
    record['files'].append(entry)
    save()
    source.unlink()
    entry['expanded_removed'] = True
    save()
    if len(record['files']) % 70 == 0:
        print('verified and compressed ' + str(len(record['files'])) + ' profiles', flush=True)
record.update(finished=time.time(), after_free_bytes=shutil.disk_usage(BASE).free)
save()
print(json.dumps(dict(profiles=len(record['files']), reclaimed_bytes=record['after_free_bytes'] - record['before_free_bytes'])))


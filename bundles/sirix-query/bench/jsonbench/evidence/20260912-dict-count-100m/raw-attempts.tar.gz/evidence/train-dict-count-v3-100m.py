"""Collect fresh canonical-tier dict-count-v3 PGO; exact answers and routes are mandatory."""
import importlib.util
import json
from pathlib import Path
import re

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
output = BASE / 'training-dict-count-v3-100m-attempt1'
output.mkdir(exist_ok=False)
profile = BASE / 'pgo-dict-count-v3-retry1-100m/jsonbench-100m.iprof'
if profile.exists():
    raise RuntimeError('refusing to overwrite a training profile')
manifest = json.loads((EVIDENCE / 'dict-count-v3-instrument-100m-runtime-manifest.json').read_text())
binary = Path(manifest['binary'])
if digest(binary) != manifest['binary_sha256']:
    raise RuntimeError('instrumented binary changed after validation')
count = json.loads((EVIDENCE / 'reopened-rowcount-retention-100m.count.json').read_text())
if count.get('persisted_child_count') != 99_999_968 or count.get('exact') is not True:
    raise RuntimeError('canonical persisted import row count was not verified')
if Path(count['database']) != BASE / 'db-100m-retention/jsonbench' or count['revision'] != 1:
    raise RuntimeError('import count belongs to a different database or revision')
paired.cool()
stem = output / 'training'
paired.run([binary, BASE / 'db-100m-retention', '--tries', 2, '--dump', output / 'dump',
            '--json', output / 'unranked-training-results.json', '-XX:ProfilesDumpFile=' + str(profile),
            '-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
            '-Dsirix.projection.promoteMaxBytes=0', '-Djava.io.tmpdir=' + str(BASE / 'tmp')], stem)
served = [line for line in stem.with_suffix('.stdout').read_text().splitlines() if line.startswith('# served:')]
if len(served) != 1:
    raise RuntimeError('missing or ambiguous training routes')
counters = {key: int(value) for key, value in re.findall(r'(\w+)=(\d+)', served[0])}
if any(counters.get(key) != expected for key, expected in
       [('groupAggregates', 10), ('numericGroupBys', 4), ('groupSliced', 10), ('groupDense', 4)]):
    raise RuntimeError(f'training took an unexpected route: {counters}')
for query in range(1, 6):
    definition = paired.compare.SPECS[query]
    failures = paired.compare.compare(
        definition, paired.compare.read_dump(output / f'dump/q{query}.jsonl', definition),
        paired.compare.read_reference(BASE / f'ch26/ch-ref-100m/q{query}.tsv', definition), False)
    (output / f'q{query}-differential.json').write_text(json.dumps(failures) + '\n')
    if failures:
        raise RuntimeError(f'Q{query} training differential mismatch: {failures}')
    print(f'Q{query}: exact 100M training MATCH', flush=True)
if not profile.is_file() or profile.stat().st_size == 0:
    raise RuntimeError('missing training profile')
(EVIDENCE / 'training-dict-count-v3-100m-manifest.json').write_text(json.dumps(dict(
    tier='100m', rows=99_999_968, tries=2, ranked=False, all_five_exact=True,
    binary_sha256=manifest['binary_sha256'], source_manifest_sha256=digest(EVIDENCE / 'dict-count-v3-source.json'),
    profile=str(profile), profile_sha256=digest(profile), routes=counters,
    persisted_import_count_evidence=count), indent=2) + '\n')


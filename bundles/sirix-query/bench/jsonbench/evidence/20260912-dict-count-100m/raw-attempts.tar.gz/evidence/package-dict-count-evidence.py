"""Package dictionary-count attempts and compiler controls, retaining all rejected evidence."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from campaign_100m import BASE, EVIDENCE, digest

destination = BASE.parents[1] / 'bundles/sirix-query/bench/jsonbench/evidence/20260912-dict-count-100m'
destination.mkdir(exist_ok=False)
files = set()
for name in ('paired-dict-count-v1-jvm-1m-attempt1',
             'paired-dict-count-v1-before-after-100m-attempt1',
             'paired-dict-count-v1-100m-attempt1', 'training-dict-count-v1-100m-attempt1',
             'paired-dict-count-v3-jvm-1m-attempt1',
             'paired-dict-count-v3-before-after-100m-attempt1',
             'paired-dict-count-v3-100m-attempt1', 'training-dict-count-v3-100m-attempt1',
             'diagnostic-dict-count-v1-compiler-q1', 'diagnostic-dict-count-v3-compiler-q1',
             'diagnostic-dict-count-v3-transform-control-attempt2',
             'profile-group-repeat-100m-attempt1'):
    directory = BASE / name
    assert directory.is_dir(), directory
    files.update(path for path in directory.rglob('*') if path.is_file())
for path in EVIDENCE.iterdir():
    if 'dict-count' in path.name or path.name.startswith(('group-repeat-profile-', 'profile-group-repeat-',
            'build-group-repeat-debug-', 'freeze-group-repeat-debug-', 'group-repeat-debug-',
            'compact-group-repeat-', 'deduplicate-group-repeat-')) or path.name in ('group_repeat_campaign.py', 'group-repeat-budget.json',
            'profile-group-repeat-100m.py', 'advance-group-repeat-profile.py',
            'archive-group-repeat-build.py', 'group-repeat-build-archives.json',
            'archive-group-repeat-expanded-build-attempt1.log',
            'archive-group-repeat-expanded-build-attempt1.verdict.json',
            'archive-group-repeat-expanded-build-attempt1.telemetry.jsonl',
            'archive-group-repeat-expanded-build-attempt1.scope.json',
            'ObserveDictionaryCount.java', 'DictionaryTransformControl.java',
            'DictionaryTransformControl.java.attempt1.txt'):
        if path.is_dir():
            files.update(child for child in path.rglob('*') if child.is_file() and '__pycache__' not in child.parts)
        elif path.is_file():
            files.add(path)
for name in ('guard-100m-storage.py', 'scope-exec-100m.py', 'prior_thermal_guard.py',
             'campaign_100m.py', 'freeze-runtime.py', 'freeze-candidate-source.py',
             'paired-retention-100m.py', 'build-limits.gradle', 'upstream-pin.json',
             'group-repeat-v1-source.json', 'group-repeat-instrument-100m-runtime-manifest.json',
             'group-repeat-optimized-100m-runtime-manifest.json', 'build-debug.gradle',
             'restore-campaign-artifact.py', 'audit-runtime-retention.py', 'paired-group-repeat-100m-attempt1-validation.json',
             'retention-import-100m-completion.json', 'reopened-rowcount-retention-100m.count.json',
             'corpus-100m-manifest.json', 'clean-corpus-100m-manifest.json',
             'compressed-corpus-100m-manifest.json', 'reflink-feasibility.md'):
    path = EVIDENCE / name
    assert path.is_file(), path
    files.add(path)
files.add(EVIDENCE / 'reflink-feasibility-kernel-6.8/downloads.json')
for label in ('dict-count-v1', 'dict-count-v3-retry1'):
    for name in ('jb', 'jb-instr', 'jsonbench-100m.iprof'):
        files.add(BASE / ('pgo-' + label + '-100m') / name)
for name in ('jb', 'jb.debug', 'jsonbench-100m.iprof'):
    files.add(BASE / 'pgo-group-repeat-debug-100m' / name)
for label in ('dict-count-v1', 'dict-count-v2', 'dict-count-v3'):
    for suffix in ('.tar.gz', '-base.tar.gz'):
        files.add(BASE / ('source-' + label + suffix))
for label in ('group-repeat-v1', 'dict-count-v1', 'dict-count-v2', 'dict-count-v3'):
    files.add(BASE / 'archived-sources' / ('source-' + label + '-validated.tar.gz'))
compressed = {Path(entry['original']): entry
              for name in ('dict-count-native-preservation.json', 'dict-count-v3-native-preservation.json')
              for entry in json.loads((EVIDENCE / name).read_text())['files']}
files.update(Path(entry['retained']) for entry in compressed.values())
retained_files = set()
for path in files:
    if path.is_file():
        retained_files.add(path)
    else:
        entry = compressed[path]
        retained = Path(entry['retained'])
        assert digest(retained) == entry['retained_sha256']
        retained_files.add(retained)
files = retained_files
large, small = [], []
for path in sorted(files):
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(BASE), path
    if path.suffix in ('.iprof', '.data', '.jfr', '.debug') or path.stat().st_size > 16 * 1024 ** 2:
        large.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
    else:
        small.append(path)
(destination / 'retained-large-files.json').write_text(json.dumps(large, indent=2) + '\n')
archive = destination / 'raw-attempts.tar.gz'
members = []
with archive.open('xb') as target, gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as stream:
        for path in small:
            relative = str(path.relative_to(BASE))
            stream.add(path, arcname=relative, recursive=False)
            members.append(dict(path=relative, bytes=path.stat().st_size, sha256=digest(path)))
with tarfile.open(archive) as stream:
    actual = {member.name: hashlib.sha256(stream.extractfile(member).read()).hexdigest()
              for member in stream.getmembers()}
assert actual == {row['path']: row['sha256'] for row in members}
record = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), files=members)
(destination / 'raw-files.json').write_text(json.dumps(record, indent=2) + '\n')
for name in ('upstream-pin.json', 'group-repeat-upstream-recheck.json', 'dict-count-v1-source.json',
             'dict-count-v1-jvm-1m-validation.json', 'dict-count-v1-before-after-100m-validation.json',
             'paired-dict-count-v1-100m-attempt1-validation.json', 'group-repeat-profile-assessment.md',
             'dict-count-v3-source.json', 'dict-count-v3-jvm-1m-validation.json',
             'dict-count-v3-before-after-100m-validation.json', 'paired-dict-count-v3-100m-attempt1-validation.json',
             'dict-count-compiler-counterfactual.md', 'group-repeat-build-archives.json',
             'dict-count-build-archives.json', 'group-repeat-profile-compaction.json', 'restore-campaign-artifact.py',
             'dict-count-v3-recovery.md', 'dict-count-v3-recovery-budget.json', 'dict-count-native-preservation.json',
             'dict-count-v3-assessment.md', 'dict-count-v3-build-archives.json', 'dict-count-v3-native-preservation.json'):
    shutil.copy2(EVIDENCE / name, destination / name)
shutil.copy2(EVIDENCE / 'dict-count-v1-test-results/manifest.json', destination / 'v1-tests.json')
shutil.copy2(EVIDENCE / 'dict-count-v3-test-results/manifest.json', destination / 'tests.json')
print(json.dumps(dict(archive=str(archive), members=len(members), bytes=record['bytes'],
                     sha256=record['sha256'], retained_large_files=len(large))))

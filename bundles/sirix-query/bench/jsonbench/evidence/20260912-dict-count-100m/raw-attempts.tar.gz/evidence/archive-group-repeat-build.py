"""Archive obsolete campaign checkouts, retaining source and non-regenerable validation artifacts."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
import time

from campaign_100m import BASE, EVIDENCE, digest

labels = ('group-repeat-v1',)
output_dir = BASE / 'archived-sources'
record_path = EVIDENCE / 'group-repeat-build-archives.json'
if record_path.exists():
    raise RuntimeError('refusing to overwrite archival evidence')
record = dict(started=time.time(), before_free_bytes=shutil.disk_usage(BASE).free,
              scope='inactive group-repeat expanded build only; every file archived; frozen runtime, source archive, native binaries and all databases remain in place',
              generated_exclusions='none; every file retained and decompression verified',
              sources=[])


def save():
    record_path.write_text(json.dumps(record, indent=2) + '\n')


save()
for label in labels:
    source = BASE / ('source-' + label)
    if source.is_symlink() or not source.is_dir() or source.parent != BASE:
        raise RuntimeError('invalid owned source directory: ' + str(source))
    manifest_path = EVIDENCE / (label + '-source.json')
    manifest = json.loads(manifest_path.read_text())
    if Path(manifest['source']) != source or digest(Path(manifest['archive'])) != manifest['archive_sha256']:
        raise RuntimeError('frozen source provenance mismatch: ' + label)
    target = output_dir / (source.name + '-validated.tar.gz')
    members = []
    with target.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for path in sorted(source.rglob('*')):
                if not path.is_file() and not path.is_symlink():
                    continue
                relative = path.relative_to(source)
                parts = relative.parts
                generated = parts[0] in ('.gradle', '.kotlin', 'build') or (
                    len(parts) > 2 and parts[0] == 'bundles' and parts[2] == 'build')
                preserve = path.suffix in ('.jar', '.args', '.debug', '.iprof', '.jfr', '.data') or (
                    'test-results' in parts and path.suffix == '.xml')
                if False:
                    continue
                name = str(Path(source.name) / relative)
                archive.add(path, arcname=name, recursive=False)
                if path.is_symlink():
                    members.append(dict(path=name, symlink=str(path.readlink())))
                else:
                    members.append(dict(path=name, bytes=path.stat().st_size, sha256=digest(path)))
    expected = {entry['path']: entry for entry in members}
    with tarfile.open(target) as archive:
        for member in archive:
            entry = expected.pop(member.name)
            if 'symlink' in entry:
                if not member.issym() or member.linkname != entry['symlink']:
                    raise RuntimeError('symlink archive mismatch: ' + member.name)
            else:
                hasher = hashlib.sha256()
                with archive.extractfile(member) as stream:
                    for block in iter(lambda: stream.read(1024 * 1024), b''):
                        hasher.update(block)
                if hasher.hexdigest() != entry['sha256']:
                    raise RuntimeError('archive mismatch: ' + member.name)
    if expected:
        raise RuntimeError('incomplete archive: ' + label)
    entry = dict(source=str(source), source_manifest_sha256=digest(manifest_path),
                 archive=str(target), archive_sha256=digest(target), members=members,
                 exact_archive_verified=True, expanded_removed=False)
    record['sources'].append(entry)
    save()
    shutil.rmtree(source)
    entry['expanded_removed'] = True
    save()
    print('archived and verified ' + source.name, flush=True)
record.update(finished=time.time(), after_free_bytes=shutil.disk_usage(BASE).free)
save()
print(json.dumps(dict(sources=len(record['sources']), reclaimed_bytes=record['after_free_bytes'] - record['before_free_bytes'])))


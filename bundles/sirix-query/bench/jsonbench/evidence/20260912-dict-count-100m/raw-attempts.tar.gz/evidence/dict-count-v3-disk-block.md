# Repeated disk-guard blocker: dictionary-count v3

The 100M goal is not complete. The best accepted implementation remains commit `d685cae276ae7055311a64e4e4b62b92d443f9a8`; its two hot paired ratios against ClickHouse were 9.2938541674589 and 9.229435424858233. Dictionary-count v3 is uncommitted and unaccepted pending fresh native 100M evidence.

## Exact blocker

1. `instrument-dict-count-v3-100m-attempt1` was terminated by the guard with exit -15 after 407 samples. The recorded failure was `disk free 70815444992 bytes below floor 70866960384`. The guard stopped the owned benchmark process tree. The build reached native compilation and layout but produced no accepted instrumented executable.
2. `deduplicate-dict-count-base-archives-attempt1` then failed its initial guard check, before executing maintenance: `RuntimeError: disk free 70815375360 bytes below floor 70866960384`. It collected zero samples and made no archive changes.

The brief requires reporting and stopping after the same genuine obstacle is encountered twice. No guard threshold was relaxed and no unrelated process or service was changed.

At the retained checkpoint, free space was **70,815,195,136 bytes**, **51,765,248 bytes (49.37 MiB)** below the unchanged 66 GiB guard floor. The permanent floor remains 20 GiB. Conservative candidate-artifact accounting was 3,441,057,792 bytes against the original cumulative 4,294,967,296-byte allowance. That accounting does not override the independent free-space guard.

`dict-count-v3-disk-block.json` records both complete verdicts and current allocations. `dict-count-v3-native-temp-inventory.json` found no `SVM-*`, `svm-*` or `native-image*` entries in the campaign's 204,800-byte `tmp/` directory; no temporary files were deleted.

## Concrete recovery option

`deduplicate-dict-count-base-archives.py` is prepared but has not run. V1, v2 and v3's immutable base source archives all have the manifest checksum `beae4d882ded4273b3bb58897223b9b578a6e789189f4baccf9fc5e44ee8b828`. The helper verifies checksums and modes, then atomically replaces only v2/v3 copies with hardlinks to v1, preserving all paths and bytes. Their logical sizes are 110,781,821 bytes each (110,796,800 allocated bytes); sharing the two duplicate copies would recover approximately 211 MiB of allocated space. The helper does not touch databases, runtime jars, native binaries or source overrides.

The shortest external change is enough free space to start that maintenance under the unchanged guard (currently at least 50 MiB), followed by a fresh peak-space audit before retrying native compilation. Alternatively, Firstmate can decide whether this strictly scoped, non-benchmark maintenance may run below the build floor while retaining the permanent floor and every benchmark guard. Neither option authorizes a new 100M database or resolves the separate column-major capacity decision.

A retry must retain the failed attempt and use new guard/output paths; the existing runner refuses overwrites. No native PGO training, optimized v3 image or v3 paired 100M result exists yet.

## Valid work retained

- V3 source archive: `source-dict-count-v3.tar.gz`, SHA-256 `5322156f9fa73930e76f77f2953ae811d95559a7f51a5920685bbbc796631b7b`.
- 83 focused tests across ten suites passed. The complete 1M JVM gate passed all five exact queries, 60 attempts and 20 cold blocks with 289 clean telemetry samples; hot after/before ratios were 0.9191260551696799 and 0.9673513454277921.
- Actual canonical Q1 JDI controls prove v1 received neutral annotations and skipped the histogram, while v3 received the same annotations and executed it. Both exact answers matched ClickHouse.
- The accepted-baseline transform control proves the failed v2 `substring cast + 0` route expectation was already unsupported. Baseline and v3 have identical answers and routes for `+ 0`, the bare cast and `+ 3`. The candidate trace observes nonzero substring annotations and the general loop, with no histogram hit.
- `dict-count-compiler-counterfactual.md` explains all controls and the retained failed v2 test. All failed attempts, frozen source/runtime manifests and lossless archive maps remain available.

The evidence packaging script is prepared but has not run; it intentionally requires the still-missing v3 native comparisons. No PR has been opened and no merge has been performed.

"""Bounded native self samples; exact diagnostics are excluded from ranking."""
import importlib.util
import json
import subprocess

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
manifest_path = EVIDENCE / 'group-repeat-debug-100m-runtime-manifest.json'
manifest = json.loads(manifest_path.read_text())
binary = BASE / 'pgo-group-repeat-debug-100m/jb'
assert str(binary) == manifest['binary'] and digest(binary) == manifest['binary_sha256']
source = json.loads((EVIDENCE / 'group-repeat-v1-source.json').read_text())
for name, expected in source['overrides'].items():
    assert digest(BASE / 'source-group-repeat-v1' / name) == expected, name
out = BASE / 'profile-group-repeat-100m-attempt1'
out.mkdir(exist_ok=False)
flags = ['-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
         '-Dsirix.projection.promoteMaxBytes=0', '-Djava.io.tmpdir=' + str(BASE / 'tmp'),
         '-Dsirix.lz77Codec.diag=true']
records = []
for query in (1, 4):
    for kind in ('diagnostic', 'profile'):
        paired.cool()
        stem = out / f'q{query}-{kind}'
        dump = out / f'q{query}-{kind}-dump'
        command = [binary, BASE / 'db-100m-retention', '--queries', query, '--tries', 1, '--dump', dump, *flags]
        if kind == 'diagnostic':
            paired.cold_cache(BASE / 'db-100m-retention', out / f'q{query}-eviction.json')
            command.extend(['-Dsirix.projDiag=true', '-Dsirix.projection.fillDiag=true'])
        else:
            profile = out / f'q{query}.perf.data'
            command = ['perf', 'record', '-e', 'cycles:u', '-F', '997', '-o', profile, '--', *command]
        paired.run(command, stem)
        definition = paired.compare.SPECS[query]
        failures = paired.compare.compare(definition,
            paired.compare.read_dump(dump / f'q{query}.jsonl', definition),
            paired.compare.read_reference(BASE / f'ch26/ch-ref-100m/q{query}.tsv', definition), False)
        (out / f'q{query}-{kind}-differential.json').write_text(json.dumps(failures) + '\n')
        if failures:
            raise RuntimeError(f'{kind} Q{query} not exact: {failures}')
        record = dict(query=query, kind=kind, exact=True, routes=paired.routes(stem), ranked=False)
        if kind == 'profile':
            record.update(profile_sha256=digest(profile), profile_bytes=profile.stat().st_size)
            with (out / f'q{query}-symbols-self.txt').open('x') as stdout, (out / f'q{query}-report.stderr').open('x') as stderr:
                subprocess.run(['perf', 'report', '-i', str(profile), '--stdio', '--sort', 'symbol',
                                '--no-children', '--call-graph', 'none', '--percent-limit', '0.2'],
                               stdout=stdout, stderr=stderr, check=True)
        records.append(record)
        (out / 'manifest.json').write_text(json.dumps(dict(runtime_manifest_sha256=digest(manifest_path),
            binary_sha256=manifest['binary_sha256'], debug_sha256=digest(binary.with_suffix('.debug')),
            rows=99_999_968, ranked=False, records=records), indent=2) + '\n')
        print(f'{kind} Q{query}: exact and routes checked', flush=True)

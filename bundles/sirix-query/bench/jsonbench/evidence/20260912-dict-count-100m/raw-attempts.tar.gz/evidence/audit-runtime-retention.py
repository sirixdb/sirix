"""Verify measured artifacts by manifest identity, including native and archived artifacts."""
from collections import defaultdict
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import time
import zipfile

from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('--label', default='')
args = parser.parse_args()
if any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in args.label):
    parser.error('invalid audit label')
output = EVIDENCE / ('column-major-runtime-preservation-audit' + ('-' + args.label if args.label else '') + '.json')
if output.exists():
    raise RuntimeError('refusing to overwrite preservation evidence')
cache = {}


def checked_digest(path):
    path = Path(path)
    stat = path.stat()
    key = (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns)
    if key not in cache:
        cache[key] = digest(path)
    return cache[key]


def stream_digest(stream):
    result = hashlib.sha256()
    for block in iter(lambda: stream.read(1024 * 1024), b''):
        result.update(block)
    return result.hexdigest()


def entries(value):
    if isinstance(value, list):
        for child in value:
            yield from entries(child)
    elif isinstance(value, dict):
        if 'retained' in value:
            yield value['retained'], value['sha256']
        else:
            for key, child in value.items():
                if key.startswith('/') and isinstance(child, str):
                    yield key, child
                else:
                    yield from entries(child)


compressed = json.loads((EVIDENCE / 'archived-native-images.json').read_text())
for name in ('column-major-secondary-compaction.json', 'dict-count-native-preservation.json',
             'dict-count-v3-native-preservation.json'):
    secondary = EVIDENCE / name
    if secondary.exists():
        for entry in json.loads(secondary.read_text())['files']:
            if entry['expanded_removed']:
                compressed.append(dict(source=entry['original'], archive=entry['retained'],
                                       sha256=entry['original_sha256'], archive_sha256=entry['retained_sha256'],
                                       logical_bytes=entry['original_bytes']))
archives = []
for name in ('owned-artifact-compaction.json', 'column-major-old-build-archives.json',
             'group-repeat-build-archives.json', 'dict-count-build-archives.json',
             'dict-count-v3-build-archives.json'):
    archives.extend(json.loads((EVIDENCE / name).read_text())['sources'])
available = defaultdict(list)
for path in BASE.glob('runtime-*/*'):
    if path.is_file():
        available[checked_digest(path)].append(path)
for entry in compressed:
    available[entry['sha256']].append(entry)
for archive in archives:
    for member in archive['members']:
        if 'sha256' in member:
            available[member['sha256']].append((archive, member))


def resolve(path, expected):
    path = Path(path)
    if path.is_file() and checked_digest(path) == expected:
        return dict(kind='file', path=str(path), sha256=expected, bytes=path.stat().st_size)
    for candidate in available[expected]:
        if isinstance(candidate, Path):
            return dict(kind='equivalent-retained-file', original=str(path), path=str(candidate), sha256=expected,
                        bytes=candidate.stat().st_size)
        if isinstance(candidate, dict):
            archive_path = Path(candidate['archive'])
            if checked_digest(archive_path) != candidate['archive_sha256']:
                raise RuntimeError('compressed native image changed: ' + str(archive_path))
            with gzip.open(archive_path, 'rb') as stream:
                if stream_digest(stream) != expected:
                    raise RuntimeError('native image decompression mismatch')
            return dict(kind='gzip', original=str(path), path=str(archive_path), sha256=expected,
                        archive_sha256=candidate['archive_sha256'], bytes=candidate['logical_bytes'])
        archive, member = candidate
        archive_path = Path(archive['archive'])
        if checked_digest(archive_path) != archive['archive_sha256']:
            raise RuntimeError('source archive changed: ' + str(archive_path))
        with tarfile.open(archive_path) as stream:
            with stream.extractfile(member['path']) as content:
                if stream_digest(content) != expected:
                    raise RuntimeError('archived runtime member mismatch')
        return dict(kind='tar-member', original=str(path), path=str(archive_path), member=member['path'],
                    sha256=expected, archive_sha256=archive['archive_sha256'], bytes=member['bytes'])
    raise RuntimeError('manifest artifact unavailable: ' + str(path) + ' SHA256=' + expected)


record = dict(started=time.time(), manifests=[], shared_libraries=[], source_archives=[], failures=[])
native_files = []
core_jars = set()
for manifest_path in sorted(EVIDENCE.glob('*runtime-manifest.json')):
    manifest = json.loads(manifest_path.read_text())
    requests = list(entries(manifest.get('classpath', [])))
    if 'binary' in manifest:
        requests.append((manifest['binary'], manifest['binary_sha256']))
        if Path(manifest['binary']).is_file():
            native_files.append(Path(manifest['binary']))
    if 'native_binary_sha256' in manifest:
        requests.extend([(BASE / 'pgo-1m/jb', manifest['native_binary_sha256']),
                         (BASE / 'pgo-1m/jb-instr', manifest['instrumented_binary_sha256']),
                         (BASE / 'pgo-1m/jsonbench-1m.iprof', manifest['profile_sha256'])])
    for relative, checksum in manifest.get('runtime_hashes', {}).items():
        requests.append((Path(manifest['jdk']) / relative, checksum))
    if isinstance(manifest.get('profile'), dict):
        requests.append((manifest['profile']['path'], manifest['profile']['sha256']))
    resolved = []
    for path, checksum in requests:
        try:
            retained = resolve(path, checksum)
            resolved.append(dict(requested=str(path), **retained))
            if 'sirix-core' in str(path) and retained['kind'] in ('file', 'equivalent-retained-file'):
                core_jars.add(retained['path'])
        except RuntimeError as error:
            record['failures'].append(str(error))
    record['manifests'].append(dict(path=str(manifest_path), sha256=checked_digest(manifest_path),
                                   artifacts=resolved, requested_count=len(requests)))
    print('audited ' + manifest_path.name, flush=True)

# Record embedded libraries and the extracted load path independently of filename-based archival rules.
for jar in sorted(core_jars):
    with zipfile.ZipFile(jar) as stream:
        for name in stream.namelist():
            if name.startswith('native/') and '.so' in Path(name).name:
                data = stream.read(name)
                record['shared_libraries'].append(dict(kind='jar-member', path=jar, member=name,
                    sha256=hashlib.sha256(data).hexdigest(), bytes=len(data)))
for path in sorted((BASE / 'tmp').glob('sirix-native-*/*')):
    if path.is_file():
        record['shared_libraries'].append(dict(kind='extracted-library', path=str(path),
                                               sha256=checked_digest(path), bytes=path.stat().st_size))
# ldd is only applied to our own already-built executable. Dependencies are recorded read-only.
system_libraries = set()
for binary in native_files:
    report = subprocess.run(['ldd', str(binary)], check=True, text=True, capture_output=True).stdout
    for match in re.findall(r'(/[^\s()]+)', report):
        if Path(match).is_file():
            system_libraries.add(Path(match).resolve())
for path in sorted(system_libraries):
    record['shared_libraries'].append(dict(kind='system-dependency', path=str(path),
                                           sha256=checked_digest(path), bytes=path.stat().st_size))
for archive in archives:
    actual = checked_digest(archive['archive'])
    if actual != archive['archive_sha256']:
        record['failures'].append('source archive checksum mismatch: ' + archive['archive'])
    record['source_archives'].append(dict(path=archive['archive'], sha256=actual,
                                         members=len(archive['members'])))
record.update(finished=time.time(), all_manifest_artifacts_available=not record['failures'])
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(manifests=len(record['manifests']), shared_libraries=len(record['shared_libraries']),
                     failures=record['failures'])), flush=True)
if record['failures']:
    raise RuntimeError('runtime preservation audit failed')

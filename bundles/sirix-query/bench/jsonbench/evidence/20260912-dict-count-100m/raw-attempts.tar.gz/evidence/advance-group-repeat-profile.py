"""Guard each diagnostic build, provenance capture, and query profile independently."""
from campaign_100m import BASE, EVIDENCE
from group_repeat_campaign import phase

phase('build-group-repeat-debug-100m-attempt1', ['bash', EVIDENCE / 'build-group-repeat-debug-100m.sh'])
phase('freeze-group-repeat-debug-100m', ['python3', EVIDENCE / 'freeze-runtime.py',
      '--label', 'group-repeat-debug-100m', '--log', EVIDENCE / 'build-group-repeat-debug-100m-attempt1.log',
      '--binary', BASE / 'pgo-group-repeat-debug-100m/jb',
      '--profile', BASE / 'pgo-group-repeat-debug-100m/jsonbench-100m.iprof', '--jdk', BASE / 'graal-25i4'])
phase('profile-group-repeat-100m-attempt1', ['python3', EVIDENCE / 'profile-group-repeat-100m.py'])

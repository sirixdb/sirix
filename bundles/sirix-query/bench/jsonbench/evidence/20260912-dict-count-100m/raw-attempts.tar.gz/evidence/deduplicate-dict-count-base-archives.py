"""Share identical immutable Git archives; preserve every path, byte and provenance hash."""
import json
import os
import shutil
from pathlib import Path

from campaign_100m import BASE, EVIDENCE, digest

output = EVIDENCE / 'dict-count-base-archive-deduplication.json'
if output.exists():
    raise RuntimeError('refusing to overwrite deduplication evidence')
canonical = BASE / 'source-dict-count-v1-base.tar.gz'
expected = json.loads((EVIDENCE / 'dict-count-v1-source.json').read_text())['base_archive_sha256']
if canonical.is_symlink() or digest(canonical) != expected:
    raise RuntimeError('canonical archive provenance mismatch')
record = dict(before_free_bytes=shutil.disk_usage(BASE).free, canonical=str(canonical), sha256=expected, files=[])
for label in ('dict-count-v2', 'dict-count-v3'):
    target = BASE / ('source-' + label + '-base.tar.gz')
    manifest = json.loads((EVIDENCE / (label + '-source.json')).read_text())
    if target.is_symlink() or manifest['base_archive_sha256'] != expected or digest(target) != expected:
        raise RuntimeError('archive differs: ' + str(target))
    previous = target.stat()
    if previous.st_mode != canonical.stat().st_mode:
        raise RuntimeError('archive modes differ')
    temporary = target.with_suffix(target.suffix + '.verified-link')
    os.link(canonical, temporary)
    os.replace(temporary, target)
    if digest(target) != expected or target.stat().st_ino != canonical.stat().st_ino:
        raise RuntimeError('hardlink verification failed')
    record['files'].append(dict(path=str(target), bytes=target.stat().st_size, sha256=expected,
        previous_inode=previous.st_ino, retained_inode=target.stat().st_ino))
record['after_free_bytes'] = shutil.disk_usage(BASE).free
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record), flush=True)

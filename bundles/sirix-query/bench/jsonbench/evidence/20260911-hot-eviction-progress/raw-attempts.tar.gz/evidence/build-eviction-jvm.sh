#!/usr/bin/env bash
set -euo pipefail
export JAVA_HOME='/home/johannes/.sdkman/candidates/java/25.0.3-graal'
export PATH='/home/johannes/.sdkman/candidates/java/25.0.3-graal/bin':"$PATH"
export GRADLE_USER_HOME='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/gradle-home'
export TMPDIR='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/tmp'
export GRADLE='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/gradle-home/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle'
export GRADLE_FLAGS='--offline --no-daemon --no-build-cache --rerun-tasks --max-workers=4 --init-script=/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/evidence/build-limits.gradle -Dorg.gradle.jvmargs=-Xmx2g'
export JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=6 -Djava.io.tmpdir=/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/tmp -Duser.home=/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/home'
unset _JAVA_OPTIONS JDK_JAVA_OPTIONS
export BUILDER_XMX=12g
"$GRADLE" $GRADLE_FLAGS -p /home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/source-eviction-final :sirix-query:jar

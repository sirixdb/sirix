from pathlib import Path
import importlib.util
import json
import math

base = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('pair', base / 'evidence/paired-usage.py')
pair = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pair)
from pause_owned_downloads import paused_downloads
original_run=pair.run
def isolated_run(command,stem):
    with paused_downloads(base / "evidence/eviction-jvm-download-pauses.jsonl"):
        return original_run(command,stem)
pair.run=isolated_run
out = base / 'paired-eviction-jvm-1m-attempt1'
out.mkdir()
db = base / 'db-1m'
variants = {'before': base / 'evidence/eviction-jvm-before', 'after': base / 'evidence/eviction-jvm-after'}
flags = ['-Djava.io.tmpdir=' + str(base / 'tmp')]
(out / 'protocol.json').write_text(json.dumps(dict(variants={k:str(v) for k,v in variants.items()},
    database=str(db), rounds=2, tries=4, cache='verified file eviction for try 1; fresh process for each try',
    order='before/after per query in round 1; after/before in round 2',
    score='geomean((after seconds + .010)/(before seconds + .010))',
    timing='engine-reported query latency; separate process wall and GNU time resource usage'),indent=2)+'\n')
for variant, binary in variants.items():
    for q in range(1,6):
        stem = out / f'correctness-{variant}-q{q}'
        dump = out / f'dump-{variant}-q{q}'
        pair.run([binary,db,'--queries',q,'--tries',1,'--dump',dump,*flags],stem)
        pair.routes(stem)
        query_spec = pair.compare.SPECS[q]
        failures = pair.compare.compare(query_spec,
            pair.compare.read_dump(dump / f'q{q}.jsonl',query_spec),
            pair.compare.read_reference(base / f'ch26/ch-ref-1m/q{q}.tsv',query_spec),False)
        (out / f'differential-{variant}-q{q}.json').write_text(json.dumps(failures)+'\n')
        if failures: raise RuntimeError(f'{variant} Q{q} mismatch: {failures}')
        print(f'{variant} Q{q}: MATCH',flush=True)
raw=[]
rounds=[]
for rnd in (1,2):
    matrix={key:[] for key in variants}
    for q in range(1,6):
        for variant in (('before','after') if rnd==1 else ('after','before')):
            pair.cool()
            pair.cold_cache(db,out / f'r{rnd}-q{q}-{variant}-eviction.json')
            times=[]
            for attempt in range(1,5):
                stem=out / f'r{rnd}-q{q}-{variant}-a{attempt}'
                result=stem.with_suffix('.result.json')
                wall=pair.run([variants[variant],db,'--queries',q,'--tries',1,'--json',result,*flags],stem)
                counters=pair.routes(stem)
                data=json.loads(result.read_text())
                seconds=data['result'][q-1][0]
                times.append(seconds)
                raw.append(dict(round=rnd,query=q,variant=variant,attempt=attempt,seconds=seconds,
                    process_wall_s=wall,counters=counters))
                (out/'attempts.jsonl').write_text(''.join(json.dumps(row)+'\n' for row in raw))
            matrix[variant].append(dict(query=q,cold=times[0],hot=min(times[1:]),times=times))
    scores={mode:math.exp(sum(math.log((a[mode]+.010)/(b[mode]+.010)) for a,b in zip(matrix['after'],matrix['before']))/5) for mode in ('cold','hot')}
    rounds.append(dict(round=rnd,after_over_before=scores,queries=matrix))
    (out/'rounds.json').write_text(json.dumps(rounds,indent=2)+'\n')
    print(json.dumps(rounds[-1]),flush=True)

"""Temporarily suspend only verified campaign download trees; leave their guards running."""
from contextlib import contextmanager
from pathlib import Path
import json
import os
import signal
import time

ROOTS = {
    1486053: ['node', '/home/johannes/.nvm/versions/node/v22.21.1/bin/gh-axi',
              'release', 'download', 'jdk-25i4-25.0.4.1.1-ea.01', '-R',
              'graalvm/oracle-graalvm-ea-builds', '--pattern',
              'graalvm-jdk-25i4-25.0.4.1.1-ea.01_linux-x64_bin.tar.gz', '--dir',
              'build/jsonbench-campaign/data/graal-25i4'],
    1489356: ['python3', 'build/jsonbench-campaign/evidence/download_parallel4-attempt5.py'],
}


@contextmanager
def paused_downloads(log):
    descriptors = {}
    started = time.time()
    try:
        for root, expected in ROOTS.items():
            try:
                descriptor = os.pidfd_open(root)
                actual = [x.decode() for x in (Path('/proc') / str(root) / 'cmdline').read_bytes().split(b'\0') if x]
            except (FileNotFoundError, ProcessLookupError):
                continue
            if actual != expected:
                os.close(descriptor)
                raise RuntimeError(f'download root {root} changed identity; refusing signal')
            pending = [(root, descriptor)]
            while pending:
                pid, descriptor = pending.pop()
                if pid in descriptors:
                    os.close(descriptor)
                    continue
                descriptors[pid] = descriptor
                try:
                    signal.pidfd_send_signal(descriptor, signal.SIGSTOP)
                except ProcessLookupError:
                    continue
                for thread in (Path('/proc') / str(pid) / 'task').glob('*'):
                    try:
                        children = (thread / 'children').read_text().split()
                    except FileNotFoundError:
                        continue
                    for child in children:
                        child = int(child)
                        try:
                            pending.append((child, os.pidfd_open(child)))
                        except ProcessLookupError:
                            pass
        yield
    finally:
        for descriptor in descriptors.values():
            try:
                signal.pidfd_send_signal(descriptor, signal.SIGCONT)
            except ProcessLookupError:
                pass
            finally:
                os.close(descriptor)
        with log.open('a') as stream:
            stream.write(json.dumps({'start_epoch': started, 'end_epoch': time.time(),
                'pids': list(descriptors), 'operation': 'SIGSTOP then SIGCONT via PIDfds'}) + '\n')

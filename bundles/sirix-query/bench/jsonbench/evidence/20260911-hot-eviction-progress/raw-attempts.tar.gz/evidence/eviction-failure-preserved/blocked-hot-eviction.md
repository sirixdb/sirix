# Blocked: HOT eviction retry exhaustion reproduced twice

Key: `hot-eviction-64-retries`.

The standalone Gradle stress test `io.sirix.index.hot.HOTLeafUseAfterCloseTest.everyKeySurvivesReadbackUnderEviction`
failed on both the new scalar-handle candidate and its unchanged production baseline. Both failures are:

    java.lang.IllegalStateException: HOT: chunk walk failed stamp validation on every one of 64 attempts — sustained allocator thrashing
    at io.sirix.index.hot.AbstractHOTIndexReader.collectChunksViaLowerBoundWalk(AbstractHOTIndexReader.java:487)
    at io.sirix.index.hot.AbstractHOTIndexReader.pointLookup(AbstractHOTIndexReader.java:329)
    at io.sirix.index.hot.HOTIndexReader.get(HOTIndexReader.java:139)
    at io.sirix.index.hot.HOTLeafUseAfterCloseTest.everyKeySurvivesReadbackUnderEviction(HOTLeafUseAfterCloseTest.java:139)

Exact runs:

- Candidate: `test-handles.sh`, `test-handles.log`, `test-handles.verdict.json`; 64 tests passed and this one failed. The six new scalar-access tests all passed. Query tests were not reached after the core test failure.
- Baseline: `test-handles-baseline.sh`, `test-handles-baseline.log`, `test-handles-baseline.verdict.json`; same suite excluding the new scalar helper test class; same sole failure. `baseline-production-proof.json` verifies relevant baseline production files against committed HEAD.
- XML is retained beneath `../source-handles/bundles/sirix-core/build/test-results/test/` and `../source-bulk-sparse/bundles/sirix-core/build/test-results/test/`.
- Both guards stayed valid (`failures: []`); exit 1 is the functional test failure, not thermal or pipeline failure. No no-mistakes run is active here.

The brief requires stopping when the same obstacle is hit twice. The shortest decision is whether to
investigate/fix the existing optimistic HOT read-progress problem as the next generic lane, or to
explicitly isolate this pre-existing stress-test failure for the benchmark campaign. The worker has
not waived the test, raised retry limits, or bypassed its lifetime checks. A supervisor resolution
carrying this exact key is required before resuming.

## Preserved work

- Branch `fm/sirix-cb-top10`, committed improvement `b5374bda3` (single-leaf offset bulk read): 31 selected tests, 5/5 differential correctness for both variants, 80 paired timed attempts, 9.7–10.5% hot score reduction. Evidence is committed under `bundles/sirix-query/bench/jsonbench/evidence/20260911-hot-leaf-offsets/`. This is not rank-one evidence.
- WIP `SegmentAccess` constant typed handles, confined to HOT leaf and scalar page-input reads, is uncommitted. `handles-uncommitted-at-block.patch` and `handles-source-manifest.json` preserve the candidate. The synthetic GA 25.0.3 probe shows approximately 16x faster short reads with exact sums for heap/native segments; `run-scalar-probe.log` has raw results. There is no native query measurement for this candidate yet.
- GA native baseline remains 5.19x ClickHouse hot at 1M before the committed bulk change. The final 100M paired result is not done.
- Corpus and EA tool downloads were intentionally stopped through their own guards when this blocker opened. No unrelated process was signaled. Cancellation records and per-file logs are retained; `download-checkpoint-sha256.json` hashes all full/partial local files. Resume incomplete corpus files with wget range continuation and a fresh attempt log directory. The partial EA archive is not an accepted toolchain.
- Earlier native builds, profiles, raw comparisons, manifests and perf captures remain in this isolated worktree. No PR, push, merge, daemon restart or cloud resource use occurred.

#!/usr/bin/env bash
set -euo pipefail
export JAVA_HOME='/home/johannes/.sdkman/candidates/java/25.0.3-graal'
export PATH='/home/johannes/.sdkman/candidates/java/25.0.3-graal/bin':"$PATH"
export GRADLE='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/gradle-home/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle'
export GRADLE_USER_HOME='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/gradle-home'
export TMPDIR='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/tmp'
unset JAVA_TOOL_OPTIONS _JAVA_OPTIONS JDK_JAVA_OPTIONS
bash '/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/source-bulk/bundles/sirix-query/bench/jsonbench/pgo-native.sh' '/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/db-1m' --tier 1m --out '/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/pgo-bulk-1m' --steps 2 --tries 2

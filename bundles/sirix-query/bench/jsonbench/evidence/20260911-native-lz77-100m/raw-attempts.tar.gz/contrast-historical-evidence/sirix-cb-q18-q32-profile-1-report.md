# Sirix ClickBench q18/q32 bounded profile scout

Date: 2026-09-10 19:00 Europe/Berlin  
Scope: disposable Sirix worktree only; bounded 1M fixture; diagnostic evidence, not a
publication or rank result.

## Executive finding

**Measurement:** On the established 1M segment fixture, current Sirix main completed q18,
q32, and the selected cohort correctly under the repository rig. q18 and q32 each used one
bounded group-aggregate pass. The standalone diagnostic phase counters show q18 scan/merge
of 255/76 ms and q32 183/142 ms on try 1; top-k is not a separately dominant phase in the
available counters. The cohort q32 retained state rose to 117 MiB while its computed group
budget fell to 52,195,783 groups, but it still used one pass.

**Inference:** The largest remaining causal target is shared per-group acquisition/merge work
in the composite group kernel, with residency and allocator/cache state as an amplifier. The
retained 100M evidence is consistent with this: q32/q18/q16 had substantial lookup/merge
samples after pass-count reduction and larger state increased GC time. The 1M profile cannot
measure the 100M multi-pass regime.

**Unknown:** Whether the same mechanism dominates a fresh current-main 100M run, how much of
the 100M gap is filesystem/page residency versus group-table CPU, and whether a lower-residency
implementation improves the full 43-query score. No 100M leg was run.

## Provenance and exact protocol

Source checkout: `/home/johannes/.treehouse/sirix-cdde48/1/sirix`  
Source status before and after preparation: clean  
Source commit: `df9b763fbc5e5387a3cd01715975cc28b3aeba19`  
Prepared runtime: [`evidence/runtime-prep-4/frozen/runtime.json`](evidence/runtime-prep-4/frozen/runtime.json)  
Runtime ID: `98de7d37bae826a3ba8ffc647cac25dbf28dace6eaecd6131a1c55dbac845fb3`  
Runtime manifest SHA-256: `25e94b0971f2d346d29b32188954e17111eefecf0986ee7ad4a216fe7aef6c7b`

Build invocation (performed by `measure.py prepare`):

```sh
python3 bundles/sirix-query/bench/clickbench/rig/measure.py prepare \
  --db "$PWD/bundles/sirix-query/build/diagnostics/seg1m/db" \
  --out /home/johannes/IdeaProjects/firstmate/data/sirix-cb-q18-q32-profile-1/evidence/runtime-prep-4 \
  --jvm-args ''
```

The rig executed `./gradlew --no-daemon --console=plain --rerun-tasks --no-build-cache -I
bundles/sirix-query/bench/clickbench/rig/export-runtime.gradle :sirix-query:exportRigRuntime`
and recorded fresh work for `:sirix-core:compileJava`, `:sirix-core:processResources`,
`:sirix-core:jar`, `:sirix-query:compileJava`, and `:sirix-query:processResources`.

JDK: Oracle GraalVM 25.0.3+9.1, Java 25.0.3 LTS. Java executable:
`/home/johannes/.sdkman/candidates/java/25.0.3-graal/bin/java`. JDK hashes are retained in
the manifest (`bin/java` `7c4c7cf8156d47c85de69d9136efe042fefee946234b04e1f39d551e1bf4cff7`,
`lib/modules` `c471168a33c621864a766b38b3ea7b97683e0539a16d9b1f7348b51629c73405`,
`lib/server/libjvm.so` `14f23fee39a4d440bbe8950df5941d3c85e0ea4c5418d757c7b0f941de12cd7c`,
`release` `0b5b52f61a381a209ac04f324691b30ac0ac94bd5e77beb59c23c7e4b476e3ea`).

Canonical JVM envelope: `-Xms6g -Xmx14g -Dsirix.offheap.bytes=10737418240
-XX:+UnlockExperimentalVMOptions -XX:-UseJVMCICompiler
-Dsirix.projection.eagerMaterializeBytes=5368709120 -Dsirix.query.autoVectorize=true
-Dsirix.chunkedBody.enable=true -Dsirix.chunkedBody.targetChunkBytes=16384`, plus the
module/access flags in the frozen manifest. The manifest contains 46 frozen classpath artifacts
and their individual SHA-256 values. Harness hashes are `ClickBenchRunMain.java`
`bd8f1d825359ca93d5dc6c1983254c28bc8f404c0a6b29fdd5ba877e2afdc8e9`, `ClickBenchLoadMain.java`
`1ebe629643624a4e9d709ea29754f832238a6e39e182a5b9b238a772a9f99a54`, and
`ClickBenchRigLease.java` `4d179c1a6aa1ed6635b9bf8d4d5191b708a7664f4b25ed5b9f27ada631b924a3`.
Query catalog SHA-256: `dbc185e55701af11a52a238f4a19462ab0d36ce1d5f03f2cacf2489bab626221`.

The runner was `bundles/sirix-query/bench/clickbench/rig/measure.py run --diagnostic`.
Every run used a fresh JVM, three tries, the exclusive rig lease, Java-process census,
cooldown gate, CPU-policy check, and 50,000,000 uW MSR verification. No machine-wide setting
was changed. The rig recorded any platform-managed RAPL changes in telemetry.

## Dataset and fixture

Fixture database: `/home/johannes/.treehouse/sirix-cdde48/1/sirix/bundles/sirix-query/build/diagnostics/seg1m/db`.
It was not reloaded. Five database files total 445,057,968 bytes; `dbsetting.obj` SHA-256 is
`b2201ae03a137e869df6e484b9a0260e32b5263dfba69ea1c34139215b7880c9`.
The source identity in the preserved load log is the canonical
`/home/johannes/IdeaProjects/sirix/bundles/sirix-query/build/diagnostics/clickbench-official-100m/hits-1m.json.gz`
with 1,000,000 rows; source SHA-256 is
`e4956754bbb0186113dcf7e8262af6343a15bd83c735024d21d2e5c1bc5da695`.
The existing DuckDB oracle is 1.5.2, 4 threads, 7.4 GiB limit, and its summary SHA-256 is
`ebee46fdb92abf18c42242a23010d198aedbeed3b9b8336b87634f322d426635`.

No canonical 100M corpus was loaded, no preserved 100M database was opened, and no 100M
allowance was consumed.

## Measurements

Timed commands, all against the existing fixture and frozen runtime:

```sh
BASE=/home/johannes/IdeaProjects/firstmate/data/sirix-cb-q18-q32-profile-1/evidence
DB=/home/johannes/.treehouse/sirix-cdde48/1/sirix/bundles/sirix-query/build/diagnostics/seg1m/db
RUNTIME=$BASE/runtime-prep-4/frozen/runtime.json
COMMON="--db $DB --runtime $RUNTIME --diagnostic --tries 3 --diagnostic-arg=-Dclickbench.expectedRows=1000000 --diagnostic-arg=-Dsirix.projDiag=true"
PYTHONPATH=$BASE/python-packages python3 bundles/sirix-query/bench/clickbench/rig/measure.py run $COMMON --out $BASE/q18-run3 --diagnostic --queries 18 --diagnostic-args="-XX:StartFlightRecording=filename=$BASE/q18-run3/q18.jfr,settings=profile,dumponexit=true -Xlog:gc*:file=$BASE/q18-run3/gc.log:tags,uptime,time,level"
PYTHONPATH=$BASE/python-packages python3 bundles/sirix-query/bench/clickbench/rig/measure.py run $COMMON --out $BASE/q32-run1 --diagnostic --queries 32 --diagnostic-args="-XX:StartFlightRecording=filename=$BASE/q32-run1/q32.jfr,settings=profile,dumponexit=true -Xlog:gc*:file=$BASE/q32-run1/gc.log:tags,uptime,time,level"
PYTHONPATH=$BASE/python-packages python3 bundles/sirix-query/bench/clickbench/rig/measure.py run $COMMON --out $BASE/cohort-run1 --diagnostic --queries 16,17,18,30,31,32,33,34,35 --diagnostic-args="-XX:StartFlightRecording=filename=$BASE/cohort-run1/cohort.jfr,settings=profile,dumponexit=true -Xlog:gc*:file=$BASE/cohort-run1/gc.log:tags,uptime,time,level"
```

The exact expanded argv is in each run's `diagnostic/command.json`; `...` above only abbreviates
the repeated absolute evidence prefix.

| Run/query | try 1 s | try 2 s | try 3 s | hot selector | phase evidence |
|---|---:|---:|---:|---:|---|
| q18 standalone | 0.979 | 0.079 | 0.132 | 0.079 | scan 255 ms, merge 76 ms, 1/1 pass, retained 25 MiB |
| q32 standalone | 0.712 | 0.073 | 0.044 | 0.044 | scan 183 ms, merge 142 ms, 1/1 pass, retained 85–86 MiB |
| q16 cohort | 0.637 | 0.107 | 0.086 | 0.086 | 1/1 pass, retained 6 MiB |
| q17 cohort | 0.061 | 0.017 | 0.017 | 0.017 | un-ordered LIMIT control, non-bounded group path |
| q18 cohort | 0.267 | 0.082 | 0.042 | 0.042 | 1/1 pass, retained 25 MiB |
| q30 cohort | 0.146 | 0.038 | 0.034 | 0.034 | 1/1 pass, predicate group path |
| q31 cohort | 0.051 | 0.039 | 0.038 | 0.038 | 1/1 pass, retained 6 MiB |
| q32 cohort | 0.492 | 0.059 | 0.042 | 0.042 | 1/1 pass, budget 52,195,783, retained 117 MiB |
| q33 cohort | 0.259 | 0.077 | 0.040 | 0.040 | numeric group route, retained 48 MiB |
| q34 cohort | 0.039 | 0.036 | 0.043 | 0.036 | numeric group route, retained 48 MiB |
| q35 cohort | 0.095 | 0.039 | 0.087 | 0.039 | numeric group route, retained 48 MiB |

These are diagnostic timings, not C6A score legs and not paired effects.

## Correctness

Correctness-only invocation used the frozen runtime classpath and the documented
`ClickBenchRunMain --tries 1 --dump ... --require-vectorized-serving` form over all 43 queries.
Command and output are in [`evidence/correctness/`](evidence/correctness/). The repository
oracle comparison exited 0: **35 MATCH, 8 TIE-AMBIGUOUS, 0 MISMATCH, 0 MISSING**. The
tie-ambiguous results are the expected engine-defined LIMIT ties; q32 is not a semantic mismatch.
The comparison log is [`evidence/correctness/compare.log`](evidence/correctness/compare.log).

## Profiles, allocation, and residency

JFR files: [`q18.jfr`](evidence/q18-run3/q18.jfr), [`q32.jfr`](evidence/q32-run1/q32.jfr),
and [`cohort.jfr`](evidence/cohort-run1/cohort.jfr), with SHA-256 respectively
`1fd14eeac04590545f5709fd1a447a71054641fa09effdcf3920e2734ef5dfec`,
`26825c29db4d7e990cde3d58a4416ca7d3ac1002a4aea3c65b2c962e8b2ded8c`, and
`44378a5831bd6e9cab0ef0ca7419e6490b178fd1ea74a454b2776c137c9851a8`.
The short 1M recordings contain substantial JVM/class-loading and page/decompression startup
sampling. Sirix frames include `ProjectionIndexHOTStorage.captureLeafDirectorySlots`/
`readDirectorySlot`, `HOTLeafPage.decodeKey8BE`, `ByteRunCodec.decode`, and foreign-memory
segment operations; they do not provide a stable aggregate-kernel hot-method ranking at this
fixture size.

GC logs are retained beside each JFR. q18 and q32 had no query GC pause in the printed phase
lines. The cohort recorded one young collection of about 31 ms, with heap 1,747 MiB → 375 MiB;
exit heap was about 1,758 MiB. This is measured allocation/GC context, not a complete allocation
profile: no allocation profiler was installed and no allocation count is claimed.

The phase diagnostics show `top-k` work is not exposed as a large independent component in these
1M runs. q32's standalone `groupBudget` was 67,108,864 groups at 112 bytes/group; cohort q32
used 52,195,783 at 144 bytes/group and retained 117 MiB. The cohort changed residency and
planning state, but did not trigger a second pass. This is direct evidence for residency
sensitivity and against attributing the 1M result to pass count or top-k alone.

## Causal interpretation

**Measured:** q18/q32 share the composite group-aggregate route (`groupAggregates=3` in the
selected runs, `groupSliced=3`); q32 has a larger stride and more retained group state. q18 and
q32 both complete in one pass on 1M. The q32 cohort’s scan/merge phase is 314/169 ms on its
cold try; q18 is 175/54 ms in cohort context. q33 uses a different numeric group route and is
materially cheaper than q32.

**Inference:** The shared engine cost is the per-group table acquisition and merge path, not
the final top-k extraction. At 100M, the retained profile’s 25% worker acquisition + 18.8%
merge acquisition for q32, plus spill/copy samples, points to the same code family. The
residency effect likely changes table width, allocator pressure, page/decode reuse, and GC,
but the bounded cohort cannot isolate each component.

**Query-specific:** q32’s wider 11-lane accumulator and 112-byte group charge explain more
resident state than q18’s 8 lanes/88 bytes. q33’s string/value shape differs from q32 and is
not a clean control for string canonicalization. q17/q30/q31/q34/q35 show that low-cardinality
and predicate/numeric variants do not carry q32’s wall cost on 1M.

**Disconfirming evidence:** q32 remains one pass under reduced cohort budget; q18/q32 are
sub-1-second on 1M; JFR is dominated by startup and HOT/page decode rather than a reliable
aggregate method ranking; and the q18/q32 hot tries vary sharply because executor/page state
warms inside a fresh JVM. Therefore neither “seven passes are the whole gap” nor “top-k is the
whole gap” is supported by this scout.

## Top three implementation candidates

1. **Reduce exact group acquisition and merge cost (recommended).**
   - Locations: `bundles/sirix-core/src/main/java/io/sirix/index/projection/NumericGroupAggTable.java:889`
     (`acquireExact`), `:1324` (`mergePartitionIndexed`), `:1366` (`mergePartition`), and
     `bundles/sirix-core/src/main/java/io/sirix/index/projection/GroupTableSpill.java:1257`
     (`merge`), `:1286` (partition merge), `:822` (`passesFor`).
   - Mechanism: reduce probes, duplicate identity work, merge copies, and transient table
     overlap while retaining exact identity and overflow semantics.
   - Risk: wrong-key coalescing, sparse SUM ordering, overflow behavior, or more resident state;
     synchronization/partition ownership is delicate.
   - Smallest behavioral test: existing `NumericGroupAggTable` displaced-record, same-hash,
     spill/final-worker, and SUM-overflow tests plus one q18/q32 integration answer comparison.
   - Bounded acceptance: on a fresh current-head 1M database, 12 ordinary paired diagnostic
     runs of q16/q18/q31/q32 must preserve all answer files and show a positive family benefit
     with a paired 95% CI above zero; no q30–q35 regression above 5% hot time.

2. **Lower group-table residency and late materialization overlap.**
   - Locations: `bundles/sirix-query/src/main/java/io/sirix/query/scan/SirixVectorizedExecutor.java:9267`
     (`rowGroupMaterializer`), `:12126` (group-budget reporting), and
     `bundles/sirix-query/src/main/java/io/sirix/query/compiler/vectorized/ColumnBatch.java:232`
     / `:267` (deferred-string materialization).
   - Mechanism: keep deferred payloads and reusable buffers out of the live heap/arena until
     winner emission; avoid overlapping worker tables, merge tables, and materialized rows.
   - Risk: extra page reads, repeated decompression, stale borrowed slices, or q33/string
     regressions; can increase cold latency while helping high-cardinality q32.
   - Smallest behavioral test: selected/deferred string tests, row-group materializer lifecycle,
     and all 43 1M oracle comparison.
   - Bounded acceptance: cohort q32 retained MiB must fall at least 15% without increasing
     q32 hot time or q33/q34/q35 hot time by more than 5%, with no additional pass/abort.

3. **Reduce projection-directory and HOT/page decode residency cost.**
   - Locations: `ProjectionIndexHOTStorage.java:2659` (`captureLeafDirectorySlots`), `:3082`
     (`readDirectorySlot`), `:3202` (`resolvedSegmentPageOffset`), and
     `HOTLeafPage.java:1529`/`:1565` (`decodeKey8BE`).
   - Mechanism: reduce directory traversal/decode copies and improve reusable slot/page residency
     so cold q18/q32 setup does not repeatedly touch the same metadata.
   - Risk: stale page references, revision isolation errors, and cache pollution; benefits may
     be mostly cold-start and not affect the retained 100M hot gap.
   - Smallest behavioral test: projection directory/revision tests plus q18/q32 answer equality
     after a fresh process.
   - Bounded acceptance: 12 paired 1M cold-start trials must reduce first-try q18/q32 phase
     setup by at least 10% with no hot regression over 5%; reject if only JFR startup samples
     move while phase counters do not.

## Recommendation

Candidate 1 was later implemented, failed its clean family performance gate, and was reverted.
Candidate 2 was then implemented, failed its retained-residency gate, and was reverted. The
candidate-1 no-mistakes run was mistakenly started and cancelled at review before push/PR;
candidate 2 never entered no-mistakes. The next evidence lane is a group-table-owned residency
reduction or fresh 100M-scale profiling subject to campaign controls. Neither rejected patch
is active at branch tip.

## Evidence index and limits

Raw run directories:

- [`evidence/q18-run3/`](evidence/q18-run3/): q18, three tries, JFR, GC, telemetry, phase log.
- [`evidence/q32-run1/`](evidence/q32-run1/): q32, three tries, JFR, GC, telemetry, phase log.
- [`evidence/cohort-run1/`](evidence/cohort-run1/): q16/q17/q18/q30–q35, three tries, JFR,
  GC, telemetry, phase log.
- [`evidence/correctness/`](evidence/correctness/): frozen-runtime all-43 oracle run and
  comparison.
- [`evidence/runtime-prep-4/`](evidence/runtime-prep-4/): fresh build log, frozen runtime,
  classpath artifacts, provenance and hashes.

The earlier rejected attempts are retained as `runtime-prep.stdout`, `runtime-prep-2.stdout`,
and the empty-output-directory attempts; they launched no JVM. The only claims in this report
are labeled measurement, inference, or unknown above. There is no rank-one claim, ClickHouse
claim, 100M claim, or 100M extrapolation.

## Implementation addendum: indexed source-chunk reuse

Date: 2026-09-10 19:30 Europe/Berlin. This addendum records two preserved implementation
experiments; both were subsequently reverted after their predeclared performance gates failed.

### Provenance and build

**Measurement:** The implementation was made in the disposable worktree
`/home/johannes/.treehouse/sirix-cdde48/1/sirix`, on branch
`fm/sirix-cb-q18-q32-profile-1`, commit `fd9dd0b06` (parent
`df9b763fb`). The working tree is clean. The candidate source change is in
`bundles/sirix-core/src/main/java/io/sirix/index/projection/NumericGroupAggTable.java`;
the focused behavioral coverage is in
`bundles/sirix-core/src/test/java/io/sirix/index/projection/CompositeGroupIdentityCollisionTest.java`.

The candidate was built freshly with:

```sh
./gradlew --no-daemon --console=plain --rerun-tasks --no-build-cache \
  -I bundles/sirix-query/bench/clickbench/rig/export-runtime.gradle \
  :sirix-query:exportRigRuntime
```

The frozen candidate runtime and complete build provenance are in
[`evidence/implementation/runtime-prep/frozen/runtime.json`](evidence/implementation/runtime-prep/frozen/runtime.json).
Exported artifact paths, SHA-256 hashes, classpath hashes, Gradle output, JDK identity,
and the exact JVM envelope are retained under
[`evidence/implementation/runtime-prep/`](evidence/implementation/runtime-prep/).
The JDK is Oracle GraalVM 25.0.3+9.1; the envelope is the canonical `-Xms6g -Xmx14g`
profile recorded in the frozen manifest.

### Change and mechanism

**Inference:** `mergePartitionIndexed` already receives partition indexes in source-handle
order. The old loop resolved the source storage array and offset for every group handle.
The candidate caches the source chunk index and `long[]` chunk, then derives the row base
from the handle's bucket mask and stride. This removes repeated chunk-array lookup and
handle-to-offset helper work while preserving exact-identity merge, displaced records,
sparse SUM, overflow, and partition ownership behavior.

**Measurement:** Focused core tests passed:

```sh
./gradlew --no-daemon --console=plain :sirix-core:test \
  --tests io.sirix.index.projection.CompositeGroupIdentityCollisionTest \
  --tests io.sirix.index.projection.NumericGroupAggTableTest
```

The query smoke/route test command was also run; its raw Gradle output is retained in the
implementation work log. The all-43 candidate correctness run used the frozen
`ClickBenchRunMain` runtime, `--tries 1 --dump ... --require-vectorized-serving`, and the
established DuckDB 1M oracle. It produced **35 MATCH, 8 TIE-AMBIGUOUS, 0 MISMATCH,
0 MISSING**; comparison exited 0. Raw command, run log, answers, and comparison are in
[`evidence/implementation/correctness/`](evidence/implementation/correctness/).

### Clean paired acceptance

**Measurement:** The earlier `acceptance-q163132` directory is explicitly rejected: it
contains legs produced while duplicate supervisors or uncertain wrappers were active. Its
verdict files are not used below. After stopping all task-owned supervisors, a process
census found no competing `measure.py`, `ClickBenchRunMain`, or acceptance supervisor.
One sequential owner then ran 12 complete baseline/candidate pairs into
[`evidence/implementation/acceptance-q163132-clean/`](evidence/implementation/acceptance-q163132-clean/).
Each leg used the rig lease, fresh JVM, existing 1M database, frozen baseline or candidate
runtime, `--diagnostic`, `--tries 3`, and `-Dsirix.projDiag=true`; exact argv and telemetry
are in each pair's `diagnostic/command.json`, `suite.log`, `telemetry.jsonl`, `cooling.jsonl`,
`start.json`, `end.json`, `plan.json`, and `verdict.json`.

The paired statistic is candidate-minus-baseline percentage of the median of tries 2–3 for
each query within each pair. Across 12 pairs:

| Query | Paired median delta | Interpretation |
|---|---:|---|
| q16 | -5.95% | small improvement, variable |
| q18 | +6.42% | regression; disconfirms a universal win |
| q31 | +6.23% | regression/noisy |
| q32 | -17.92% | improvement, high pair variance |

The q30–q35 guard used 3 fresh sequential pairs in
[`evidence/implementation/acceptance-q30q35-clean/`](evidence/implementation/acceptance-q30q35-clean).
Its paired median deltas were q30 +7.69%, q31 -12.50%, q32 -30.49%, q33 +25.60%,
q34 -22.11%, and q35 -28.30%. These guard results are mixed and noisy; they do not
establish a family-wide acceptance win. No score or confidence claim was made by the rig.

**Inference:** The optimization is query-selective and most consistent with q32's larger
indexed partition merge workload. The q18/q31 regressions and mixed guard mean the bounded
fixture does not justify claiming a broad engine improvement or a positive family-level
confidence interval. The code is still a plausible implementation candidate because it is
semantics-preserving and targets the profiled shared merge path, but 100M behavior remains
unknown.

**Unknown:** Whether chunk reuse survives the 100M residency/multi-pass regime, whether the
q18/q31 regressions are startup/thermal variance or a real interaction, and whether the
candidate improves the full 43-query ClickBench score. No 100M leg, reload, or preserved
100M database mutation occurred.

### Candidate ranking and recommendation

1. **Indexed source-chunk reuse in `NumericGroupAggTable.mergePartitionIndexed`** — rejected
   and reverted after the clean family gate. Risk: handle decoding or chunk-boundary mistakes. Smallest behavioral
   test: collision, displaced-record, sparse SUM, and overflow tests plus all-43 oracle
   comparison. Bounded acceptance: clean paired q16/q18/q31/q32 and q30–q35 guard; current
   evidence passes correctness but does not pass a broad-performance gate.
2. **Lower group-table/materialization residency** — candidate 2 was tested as deferred-page
   release and rejected because q32 retained MiB did not change. A group-table-owned residency
   reduction remains unimplemented; locations and risks remain in the scout section above.
3. **Projection-directory/HOT decode residency reduction** — locations and risks remain above;
   the short JFR does not support promoting it.

**Recommendation:** Candidate 1 is rejected and reverted; candidate 2 is rejected and reverted.
The next lane is a group-table-owned residency reduction or fresh 100M-scale profiling subject
to campaign controls. This bounded addendum makes no rank-one or ClickHouse claim.

## Candidate-2 addendum: deferred-page release (rejected)

**Measurement:** After the candidate-1 revert commit `c66514370`, candidate 2 changed
`ColumnarScanBlock` to call `ColumnBatch.clearBackingPages` immediately after synchronous
downstream tuple emission. A lifecycle test in `ColumnBatchTest` proves that decoded strings
remain valid after page and FSST-table references are released. Focused query tests passed,
and the fresh candidate-2 runtime is preserved at
[`evidence/implementation/runtime-prep-candidate2/`](evidence/implementation/runtime-prep-candidate2/).

The all-43 oracle run is preserved at
[`evidence/implementation/correctness-candidate2/`](evidence/implementation/correctness-candidate2/):
**35 MATCH, 8 TIE-AMBIGUOUS, 0 MISMATCH, 0 MISSING**, exit 0.

**Measurement:** The clean sequential candidate-2 acceptance is under
[`evidence/implementation/acceptance-candidate2-clean/`](evidence/implementation/acceptance-candidate2-clean/),
with 3 baseline/candidate pairs, fresh JVMs, the existing 1M database, the rig lease, and
queries q18, q32, q33, q34, q35. q32 retained residency was **117 MiB for every baseline and
candidate leg** (0% reduction), versus the required minimum 15%. q32 warm medians were
0.0855 s baseline versus 0.0605 s candidate at the aggregate across pairs, but q18/q33/q35
were mixed; timing cannot rescue the failed residency gate. Pass counts remained 1/1, with no
pass/abort increase.

**Inference:** The q32 retained table is owned by the group-aggregate path, not by the
`ColumnarScanBlock` deferred-page references. Candidate 2 therefore targeted a real and safe
shortening of one lifetime, but not the retained-MiB mechanism controlling q32. It is rejected
for shipping and must not be promoted.

**Unknown:** Whether the same release helps a different projection-only workload or larger
row-materialization cohort. No 100M run, reload, or preserved 100M database mutation occurred.

**Decision:** Candidate 2 failed the predeclared performance gate and was reverted. Candidate 1's
no-mistakes run was mistakenly started and cancelled at review before push/PR; candidate 2 never
entered no-mistakes. Both original commits, their normal revert commits, and all evidence remain
available as reproducible failed experiments. There is no push or PR.

"""Read the actual paired table metadata and plans without modifying its schema."""
import importlib.util
import json
from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
directory = BASE / 'inspect-ch-indexes-attempt1'
directory.mkdir(exist_ok=False)
binary = '/var/tmp/jsonbench/clickhouse'
expected = 'd2a2611ed56bc6d1544fafe8ece7e888ae2af6e13ea7095993a5105d8c74d4f3'
assert digest(binary) == expected
queries = {
    'version': 'SELECT version()',
    'create': 'SHOW CREATE TABLE bluesky',
    'table': "SELECT database, name, engine, sorting_key, primary_key, sampling_key, partition_key, total_rows, total_bytes FROM system.tables WHERE name='bluesky' FORMAT JSONEachRow",
    'settings': "SELECT name, value, changed FROM system.merge_tree_settings WHERE name IN ('index_granularity','index_granularity_bytes','enable_mixed_granularity_parts','write_final_mark','object_serialization_version','dynamic_serialization_version','object_shared_data_serialization_version') FORMAT JSONEachRow",
    'skipping': "SELECT * FROM system.data_skipping_indices WHERE table='bluesky' FORMAT JSONEachRow",
    'projections': "SELECT * FROM system.projections WHERE table='bluesky' FORMAT JSONEachRow",
    'dictionaries': 'SELECT name, type FROM system.dictionaries FORMAT JSONEachRow',
    'parts': "SELECT name, part_type, rows, marks, bytes_on_disk, primary_key_bytes_in_memory FROM system.parts WHERE table='bluesky' AND active ORDER BY name FORMAT JSONEachRow",
    'describe': 'DESCRIBE TABLE bluesky SETTINGS describe_include_subcolumns=1 FORMAT JSONEachRow',
}
for index, query in enumerate((paired.KIT / 'queries.sql').read_text().splitlines(), 1):
    queries[f'explain-q{index}'] = 'EXPLAIN indexes=1 ' + query.rstrip(';') + " SETTINGS session_timezone='UTC'"
for label, query in queries.items():
    paired.run([binary, 'local', '--path', BASE / 'ch26/ch-data-100m', '--query', query], directory / label)
    print(label, flush=True)
(directory / 'manifest.json').write_text(json.dumps(dict(binary_sha256=expected,
    queries=queries, setup_only=True, ranked=False, schema_mutations=False), indent=2) + '\n')

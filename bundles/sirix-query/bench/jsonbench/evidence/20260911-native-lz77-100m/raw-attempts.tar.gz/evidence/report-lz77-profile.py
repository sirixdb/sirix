"""Render retained CPU profiles without rerunning queries; invoke under the guard."""
from pathlib import Path
import subprocess

from campaign_100m import BASE

directory = BASE / 'profile-debug-lz77-100m-attempt1'
for query in (1, 4):
    for label, sort in (('symbols-self', 'symbol'), ('source-lines', 'symbol,srcline')):
        destination = directory / f'q{query}-{label}.txt'
        if destination.exists():
            raise RuntimeError('refusing to overwrite a profile report')
        with destination.open('w') as stream, destination.with_suffix('.stderr').open('w') as error:
            subprocess.run(['perf', 'report', '-i', str(directory / f'q{query}.perf.data'),
                            '--stdio', '--sort', sort, '--no-children', '--call-graph', 'none',
                            '--percent-limit', '0.2'], stdout=stream, stderr=error, check=True)
        print(str(destination), flush=True)

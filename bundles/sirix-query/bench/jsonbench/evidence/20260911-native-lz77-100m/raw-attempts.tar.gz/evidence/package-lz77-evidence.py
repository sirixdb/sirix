"""Package decoder-lane provenance and exact raw attempts after all phases complete."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from campaign_100m import BASE, EVIDENCE, digest

root = BASE.parents[1]
destination = root / 'bundles/sirix-query/bench/jsonbench/evidence/20260911-native-lz77-100m'
destination.mkdir(exist_ok=False)
directories = [BASE / name for name in (
    'paired-scalar-100m-attempt1', 'paired-lz77-100m-attempt1',
    'paired-lz77-instrument-1m-attempt1', 'training-lz77-100m-attempt1',
    'diagnose-scalar-100m-attempt1', 'diagnose-lz77-100m-attempt1',
    'profile-debug-scalar-100m-attempt1', 'profile-debug-lz77-100m-attempt1',
    'async-native-probe-attempt1', 'async-native-probe-attempt2',
    'async-native-100m-attempt1', 'async-jvm-control-100m-attempt1',
    'inspect-ch-indexes-attempt1', 'contrast-historical-evidence',
    'evidence/native-lz77-v1-test-results')]
for directory in directories:
    if not directory.is_dir():
        raise RuntimeError('required evidence directory missing: ' + str(directory))
files = {path for directory in directories for path in directory.rglob('*') if path.is_file()}
prefixes = (
    'format-native-lz77-v1', 'freeze-native-lz77-v1', 'test-native-lz77-v1',
    'lz77-native-smoke-', 'instrument-lz77-100m-attempt1', 'freeze-instrument-lz77-100m',
    'check-lz77-instrument-1m-attempt1', 'train-lz77-100m-attempt1',
    'optimize-lz77-100m-attempt1', 'freeze-optimized-lz77-100m', 'paired-lz77-100m-attempt1',
    'diagnose-lz77-100m-attempt1', 'build-debug-lz77-100m-attempt1',
    'freeze-debug-lz77-100m-attempt1', 'profile-debug-lz77-100m-attempt1',
    'diagnose-scalar-100m-attempt1', 'build-debug-scalar-100m-attempt1',
    'freeze-debug-scalar-100m-attempt1', 'profile-debug-scalar-100m-attempt1',
    'diagnose-lz77-scalar-1m-attempt1', 'diagnose-lz77-registration-attempt1',
    'trace-lz77-extraction', 'upstream-recheck-lz77-100m',
    'async-native-', 'async-jvm-control-', 'async-profiler-4.2-', 'render-async-lz77-',
    'report-lz77-profile-', 'report-lz77-q4-symbols-', 'inspect-ch-indexes-')
files.update(path for path in EVIDENCE.iterdir() if path.is_file() and path.name.startswith(prefixes))
names = (
    'guard-100m-storage.py', 'scope-exec-100m.py', 'prior_thermal_guard.py', 'campaign_100m.py',
    'freeze-runtime.py', 'freeze-candidate-source.py', 'lz77-lane.sh', 'lz77-validation.gradle',
    'lz77-native-smoke.py', 'check-lz77-1m.py', 'train-lz77-100m.py', 'advance-lz77-100m.py',
    'paired-retention-100m.py', 'diagnose_native_100m.py', 'audit-lz77-paired-100m.py',
    'build-limits.gradle', 'build-debug.gradle', 'build-lz77-debug-100m.sh',
    'native-lz77-v1-source.json', 'native-lz77-v1-tests.json', 'native-lz77-smoke-validation.json',
    'lz77-instrument-1m-validation.json', 'report-lz77-profile.py',
    'profile-async-lz77.py', 'profile-async-lz77-attempt1.py', 'profile-async-lz77-native-attempt1.py',
    'render-async-lz77.py', 'report-lz77-q4-symbols.py', 'inspect-ch-indexes.py',
    'clickbench-jsonbench-contrast.md',
    'training-lz77-100m-manifest.json', 'lz77-instrument-100m-runtime-manifest.json',
    'lz77-optimized-100m-runtime-manifest.json', 'lz77-debug-100m-runtime-manifest.json',
    'lz77-debug-100m-symbols-manifest.json', 'scalar-v1-source.json',
    'scalar-optimized-100m-runtime-manifest.json', 'scalar-instrument-100m-runtime-manifest.json',
    'scalar-debug-100m-runtime-manifest.json', 'scalar-debug-100m-symbols-manifest.json',
    'paired-scalar-100m-attempt1-validation.json', 'lz77-diagnostic-logback.xml',
    'upstream-pin.json', 'retention-import-100m-completion.json',
    'reopened-rowcount-retention-100m.count.json', 'active-corpus-100m.json',
    'corpus-100m-manifest.json', 'clean-corpus-100m-manifest.json',
    'compressed-corpus-100m-manifest.json', 'package-lz77-evidence.py')
for name in names:
    path = EVIDENCE / name
    if not path.is_file():
        raise RuntimeError('required evidence missing: ' + name)
    files.add(path)
for variant in ('control', 'fixed'):
    directory = BASE / ('lz77-native-smoke-' + variant)
    files.update(directory / name for name in ('manifest.json', 'run.stdout', 'run.stderr', 'lz77-smoke'))
files.update(BASE / name for name in ('pgo-lz77-100m/jb', 'pgo-lz77-100m/jb-instr',
                                    'pgo-lz77-100m/jsonbench-100m.iprof',
                                    'pgo-lz77-debug-100m/jb', 'pgo-lz77-debug-100m/jb.debug'))
large = []
small = []
for path in sorted(files):
    if path.is_symlink() or not path.resolve().is_relative_to(BASE) or not path.is_file():
        raise RuntimeError('invalid evidence path: ' + str(path))
    if path.suffix in ('.iprof', '.data', '.jfr', '.debug') or path.stat().st_size > 16 * 1024 * 1024:
        large.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
    else:
        small.append(path)
(destination / 'retained-large-files.json').write_text(json.dumps(large, indent=2) + '\n')
members = []
archive = destination / 'raw-attempts.tar.gz'
with archive.open('wb') as target, gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as stream:
        for path in small:
            relative = str(path.relative_to(BASE))
            stream.add(path, arcname=relative, recursive=False)
            members.append(dict(path=relative, bytes=path.stat().st_size, sha256=digest(path)))
with tarfile.open(archive) as stream:
    actual = {member.name: hashlib.sha256(stream.extractfile(member).read()).hexdigest()
              for member in stream.getmembers()}
assert actual == {row['path']: row['sha256'] for row in members}
record = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), files=members)
(destination / 'raw-files.json').write_text(json.dumps(record, indent=2) + '\n')
for name in ('upstream-pin.json', 'native-lz77-v1-source.json', 'native-lz77-v1-tests.json',
             'paired-scalar-100m-attempt1-validation.json', 'paired-lz77-100m-attempt1-validation.json',
             'lz77-instrument-1m-validation.json'):
    shutil.copy2(EVIDENCE / name, destination / name)
print(json.dumps(dict(archive=str(archive), members=len(members), bytes=record['bytes'],
                     sha256=record['sha256'], retained_large_files=len(large))))

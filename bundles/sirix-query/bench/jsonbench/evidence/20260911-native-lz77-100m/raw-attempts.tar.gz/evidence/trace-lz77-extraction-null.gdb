set pagination off
set confirm off
set disable-randomization off
set print thread-events off
set language c
starti /home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/db-1m-retention-repaired --queries 1 --tries 1 -Dsirix.lz77Codec.diag=true -Djava.io.tmpdir=/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/tmp
set $image_base = (unsigned long)&__svm_code_section - 0x50000
break *($image_base + 0x5e7593)
continue
finish
python
import gdb
returned = int(gdb.parse_and_eval("$rax"))
heap_register = int(gdb.parse_and_eval("(int)__svm_heap_base_regnum"))
heap_base = int(gdb.selected_frame().read_register(heap_register))
print("LZ77 extraction result:", {"return_register": hex(returned), "heap_base": hex(heap_base), "is_null": returned in (0, heap_base)})
end
continue

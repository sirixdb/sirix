"""Convert retained async profiles and summarize frames. Invoke under the guard."""
import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
from campaign_100m import BASE, digest

parser = argparse.ArgumentParser()
parser.add_argument('directory', type=Path)
args = parser.parse_args()
summaries = []
for source in sorted(args.directory.glob('*.jfr')):
    event = source.name.split('-')[0]
    collapsed = source.with_suffix('.collapsed')
    if collapsed.exists():
        raise RuntimeError('refusing to overwrite converted evidence')
    command = [str(BASE / 'async-profiler-4.2/bin/jfrconv'), '--' + event, '-o', 'collapsed',
               str(source), str(collapsed)]
    with source.with_suffix('.convert.stdout').open('w') as out, source.with_suffix('.convert.stderr').open('w') as err:
        subprocess.run(command, stdout=out, stderr=err, check=True, timeout=60)
    leaves = Counter()
    inclusive = Counter()
    total = 0
    for line in collapsed.read_text().splitlines():
        stack, weight = line.rsplit(' ', 1)
        weight = int(weight)
        frames = stack.split(';')
        total += weight
        leaves[frames[-1]] += weight
        for frame in set(frames):
            inclusive[frame] += weight
    record = dict(profile=str(source), sha256=digest(source), event=event, total_weight=total,
                  unit='samples (event-specific, not interchangeable)',
                  top_self=leaves.most_common(30), top_inclusive=inclusive.most_common(40))
    summaries.append(record)
    print(source.name, 'weight', total, 'self', leaves.most_common(3), flush=True)
(args.directory / 'frame-summary.json').write_text(json.dumps(summaries, indent=2) + '\n')

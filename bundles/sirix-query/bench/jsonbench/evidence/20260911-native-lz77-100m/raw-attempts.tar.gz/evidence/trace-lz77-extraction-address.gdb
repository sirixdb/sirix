set pagination off
set confirm off
set disable-randomization off
set print thread-events off
set language c
starti /home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/db-1m-retention-repaired --queries 1 --tries 1 -Dsirix.lz77Codec.diag=true -Djava.io.tmpdir=/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/tmp
set $image_base = (unsigned long)&__svm_code_section - 0x50000
break *($image_base + 0x5e7593)
continue
finish
printf "LZ77 extraction return register: %p\n", $rax
continue

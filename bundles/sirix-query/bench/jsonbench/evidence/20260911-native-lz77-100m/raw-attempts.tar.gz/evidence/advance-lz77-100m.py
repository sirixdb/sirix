"""Sequential guarded decoder campaign; preserves every attempt and checks inbox gates."""
import json
from pathlib import Path
import subprocess
import time

from campaign_100m import BASE, EVIDENCE

INBOX = Path('/home/johannes/IdeaProjects/firstmate/state/sirix-cb-top10.inbox')


def require_pass(name):
    path = EVIDENCE / (name + '.verdict.json')
    if not path.is_file():
        raise RuntimeError('missing completed prerequisite: ' + name)
    verdict = json.loads(path.read_text())
    if verdict['exit_code'] or verdict['failures']:
        raise RuntimeError('phase guard failed: ' + name)


def phase(name, command):
    while list(INBOX.glob('*.msg')):
        print('Waiting for active agent to handle Firstmate inbox before next phase', flush=True)
        time.sleep(5)
    prefix = EVIDENCE / name
    if any(prefix.with_suffix(suffix).exists() for suffix in ('.verdict.json', '.log', '.telemetry.jsonl')):
        raise RuntimeError('refusing to overwrite phase evidence: ' + name)
    print('START ' + name, flush=True)
    subprocess.run(['python3', str(EVIDENCE / 'guard-100m-storage.py'), '--prefix', str(prefix), '--',
                    'systemd-run', '--user', '--scope', '--quiet', '--collect', '--unit=jsonbench-' + name,
                    '--property=MemoryMax=24G', '--property=MemorySwapMax=0',
                    'python3', str(EVIDENCE / 'scope-exec-100m.py'), str(prefix), *map(str, command)], check=True)
    require_pass(name)
    print('PASS ' + name, flush=True)


for prerequisite in ('freeze-native-lz77-v1', 'test-native-lz77-v1',
                     'lz77-native-smoke-control-attempt1', 'lz77-native-smoke-fixed-attempt1'):
    require_pass(prerequisite)
for variant in ('control', 'fixed'):
    if json.loads((BASE / ('lz77-native-smoke-' + variant) / 'manifest.json').read_text()).get('expected_outcome_observed') is not True:
        raise RuntimeError('native smoke did not validate its expected outcome')

phase('instrument-lz77-100m-attempt1', ['bash', EVIDENCE / 'lz77-lane.sh', 'instrument'])
phase('freeze-instrument-lz77-100m',
      ['python3', EVIDENCE / 'freeze-runtime.py', '--label', 'lz77-instrument-100m',
       '--log', EVIDENCE / 'instrument-lz77-100m-attempt1.log',
       '--binary', BASE / 'pgo-lz77-100m/jb-instr', '--jdk', BASE / 'graal-25i4'])
phase('check-lz77-instrument-1m-attempt1', ['python3', EVIDENCE / 'check-lz77-1m.py'])
steering = json.loads((BASE / 'paired-lz77-instrument-1m-attempt1/rounds.json').read_text())
if len(steering) != 2 or any(row['after_over_before']['hot'] >= 1 for row in steering):
    raise RuntimeError('1M steering requires assessment before committing full-tier measurement cost')
phase('train-lz77-100m-attempt1', ['python3', EVIDENCE / 'train-lz77-100m.py'])
phase('optimize-lz77-100m-attempt1', ['bash', EVIDENCE / 'lz77-lane.sh', 'optimize'])
phase('freeze-optimized-lz77-100m',
      ['python3', EVIDENCE / 'freeze-runtime.py', '--label', 'lz77-optimized-100m',
       '--log', EVIDENCE / 'optimize-lz77-100m-attempt1.log',
       '--binary', BASE / 'pgo-lz77-100m/jb',
       '--profile', BASE / 'pgo-lz77-100m/jsonbench-100m.iprof', '--jdk', BASE / 'graal-25i4'])
phase('paired-lz77-100m-attempt1',
      ['python3', EVIDENCE / 'paired-retention-100m.py', '--tier', '100m',
       '--sirix', BASE / 'pgo-lz77-100m/jb', '--db', BASE / 'db-100m-retention',
       '--ch-db', BASE / 'ch26/ch-data-100m', '--rows', '99999968', '--tries', '3', '--rounds', '2',
       '--out', BASE / 'paired-lz77-100m-attempt1'])
print('Decoder paired evidence complete; audit exact answers, routes, cache and guard verdicts, then assess rank.', flush=True)

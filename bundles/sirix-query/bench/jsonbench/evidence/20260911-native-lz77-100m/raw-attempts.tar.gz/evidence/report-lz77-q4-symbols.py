"""Bounded symbol-only rendering of an existing profile; run beneath guard."""
import subprocess
from campaign_100m import BASE

directory = BASE / 'profile-debug-lz77-100m-attempt1'
destination = directory / 'q4-symbols-self.txt'
with destination.open('x') as output, destination.with_suffix('.stderr').open('x') as error:
    subprocess.run(['perf', 'report', '-i', str(directory / 'q4.perf.data'), '--stdio',
                    '--sort', 'symbol', '--no-children', '--call-graph', 'none',
                    '--percent-limit', '0.2'], stdout=output, stderr=error, check=True, timeout=60)

"""Functional native-image packaging control; invoke only under the campaign guard."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess

from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('variant', choices=['control', 'fixed'])
args = parser.parse_args()
source = BASE / 'source-native-lz77-v1'
out = BASE / ('lz77-native-smoke-' + args.variant)
out.mkdir(exist_ok=False)
classpath = (source / 'bundles/sirix-core/build/lz77-smoke-classpath.txt').read_text().strip().split(os.pathsep)
resources = source / 'bundles/sirix-core/build/resources/main'
metadata = Path('META-INF/native-image/io.sirix/sirix-core/reachability-metadata.json')
baseline = json.loads((EVIDENCE / 'native-lz77-v1-source.json').read_text())['base_commit']
if args.variant == 'control':
    replacement = out / 'control-resources'
    shutil.copytree(resources, replacement)
    original = subprocess.check_output(['git', 'show', baseline + ':bundles/sirix-core/src/main/resources/' + str(metadata)], cwd=BASE.parents[1])
    (replacement / metadata).write_bytes(original)
    if classpath.count(str(resources)) != 1:
        raise RuntimeError('ambiguous core resource classpath')
    classpath[classpath.index(str(resources))] = str(replacement)
inputs = {}
for entry in classpath:
    path = Path(entry)
    if path.is_file():
        inputs[entry] = digest(path)
    elif path.is_dir():
        inputs[entry] = {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file()}
    elif entry.endswith('/build/resources/test'):
        inputs[entry] = {'absent_optional_test_resources': True}
    else:
        raise RuntimeError('missing classpath entry: ' + entry)
env = dict(os.environ)
env.pop('_JAVA_OPTIONS', None)
env.pop('JDK_JAVA_OPTIONS', None)
env['JAVA_HOME'] = str(BASE / 'graal-25i4')
env['TMPDIR'] = str(BASE / 'tmp')
env['JAVA_TOOL_OPTIONS'] = '-XX:ActiveProcessorCount=6 -Djava.io.tmpdir=' + str(BASE / 'tmp') + ' -Duser.home=' + str(BASE / 'home')
binary = out / 'lz77-smoke'
command = [BASE / 'graal-25i4/bin/native-image', '-J-Xmx8g', '--enable-preview',
           '--enable-native-access=ALL-UNNAMED', '--add-modules=jdk.incubator.vector',
           '--no-fallback', '-O2', '-march=native', '-H:+UnlockExperimentalVMOptions',
           '-H:+ForeignAPISupport', '--initialize-at-build-time=org.slf4j,ch.qos.logback',
           '-cp', os.pathsep.join(classpath), '-o', binary,
           'io.sirix.page.SirixLZ77NativeImageSmokeTest']
record = dict(variant=args.variant, baseline=baseline,
              source_manifest_sha256=digest(EVIDENCE / 'native-lz77-v1-source.json'),
              classpath=classpath, input_hashes=inputs, build_command=list(map(str, command)))
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
subprocess.run(list(map(str, command)), cwd=out, env=env, check=True)
record['binary_sha256'] = digest(binary)
run = [str(binary), '-Dsirix.lz77Codec.diag.counters=true', '-Djava.io.tmpdir=' + str(BASE / 'tmp')]
record['run_command'] = run
completed = subprocess.run(run, cwd=out, env=env, text=True, capture_output=True)
(out / 'run.stdout').write_text(completed.stdout)
(out / 'run.stderr').write_text(completed.stderr)
record['run_exit_code'] = completed.returncode
print(completed.stdout, end='', flush=True)
print(completed.stderr, end='', flush=True)
if args.variant == 'control':
    passed = completed.returncode != 0 and 'native decoder must be available in this image' in completed.stderr
else:
    passed = completed.returncode == 0 and 'slack and canaries PASS' in completed.stdout
record['expected_outcome_observed'] = passed
(out / 'manifest.json').write_text(json.dumps(record, indent=2) + '\n')
if not passed:
    raise RuntimeError('native smoke did not produce its expected ' + args.variant + ' outcome')
print(args.variant + ' native smoke expected outcome observed', flush=True)

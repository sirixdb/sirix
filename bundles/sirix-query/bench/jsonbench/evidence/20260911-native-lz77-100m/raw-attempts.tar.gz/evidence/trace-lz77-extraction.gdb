set pagination off
set confirm off
set disable-randomization off
break 'io.sirix.page.SirixLZ77NativeDecoder::extractNativeLib()'
run /home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/db-1m-retention-repaired --queries 1 --tries 1 -Dsirix.lz77Codec.diag=true -Djava.io.tmpdir=/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign/tmp
finish
printf "LZ77 extraction return register: %p\n", $rax
continue

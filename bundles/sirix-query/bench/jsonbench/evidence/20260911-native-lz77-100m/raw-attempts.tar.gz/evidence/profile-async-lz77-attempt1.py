"""Native event probes and unranked profiles. Invoke only beneath campaign guard."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
parser = argparse.ArgumentParser()
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--mode', choices=['probe', 'native', 'jvm'], required=True)
args = parser.parse_args()
args.out.mkdir(exist_ok=False)
manifest = json.loads((EVIDENCE / 'lz77-debug-100m-runtime-manifest.json').read_text())
binary = Path(manifest['binary'])
assert digest(binary) == manifest['binary_sha256']
profiler = BASE / 'async-profiler-4.2/lib/libasyncProfiler.so'
assert digest(profiler) == 'cb103963bfc32663561a2608b3e33871a4ef7513a6c88fd7d01ef36a741cca41'
flags = ['-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
         '-Dsirix.projection.promoteMaxBytes=0', '-Djava.io.tmpdir=' + str(BASE / 'tmp'),
         '-Dsirix.lz77Codec.diag=true']
records = []
if args.mode == 'probe':
    cases = [(event, 1) for event in ('cpu', 'wall', 'nativemem', 'alloc', 'lock')]
else:
    cases = [(event, query) for event in (('cpu', 'wall', 'nativemem') if args.mode == 'native'
                                       else ('alloc', 'lock')) for query in (1, 4)]
for event, query in cases:
    paired.cool()
    stem = args.out / f'{event}-q{query}'
    dump = args.out / f'{event}-q{query}-dump'
    profile = args.out / f'{event}-q{query}.jfr'
    small = args.mode == 'probe'
    db = BASE / ('db-1m-retention-repaired' if small else 'db-100m-retention')
    options = f'{"check" if small else "start"},event={event},cstack=dwarf,loglevel=debug'
    if not small:
        options += f',file={profile}'
        if event == 'wall':
            options += ',interval=10ms'
        elif event in ('alloc', 'nativemem'):
            options += ',interval=1m'
        elif event == 'lock':
            options += ',interval=1ms'
        else:
            options += ',interval=1ms'
    app = [db, '--queries', query, '--tries', 1, '--dump', dump]
    if args.mode == 'jvm':
        runtime = json.loads((EVIDENCE / 'lz77-optimized-100m-runtime-manifest.json').read_text())
        jars = []
        for item in runtime['classpath']:
            jar = Path(item['retained'])
            assert digest(jar) == item['sha256']
            jars.append(str(jar))
        command = [BASE / 'graal-25i4/bin/java', '--enable-preview', '--enable-native-access=ALL-UNNAMED',
                   '--add-modules=jdk.incubator.vector', '-XX:-UseJVMCICompiler',
                   '-XX:ActiveProcessorCount=6', *flags, f'-agentpath:{profiler}={options}',
                   '-cp', ':'.join(jars), 'io.sirix.query.bench.jsonbench.JsonBenchRunMain', *app]
    else:
        command = ['/usr/bin/env', f'LD_PRELOAD={profiler}', f'ASPROF_COMMAND={options}',
                   binary, *app, *flags]
    paired.run(command, stem)
    definition = paired.compare.SPECS[query]
    failures = paired.compare.compare(definition,
        paired.compare.read_dump(dump / f'q{query}.jsonl', definition),
        paired.compare.read_reference(BASE / f'ch26/ch-ref-{"1m" if small else "100m"}/q{query}.tsv', definition), False)
    if failures:
        raise RuntimeError(f'{event} Q{query} mismatch: {failures}')
    log = stem.with_suffix('.stderr').read_text()
    record = dict(event=event, query=query, runtime=args.mode, exact=True, ranked=False,
                  routes=paired.routes(stem), profile=str(profile) if profile.exists() else None,
                  stderr=log, command_manifest=str(stem.with_suffix('.command.json')))
    if not small:
        if not profile.exists() or profile.stat().st_size == 0:
            raise RuntimeError(f'{event} Q{query} produced no profile; inspect retained stderr')
        record['profile_sha256'] = digest(profile)
    records.append(record)
    (args.out / 'manifest.json').write_text(json.dumps(dict(binary_sha256=manifest['binary_sha256'],
        profiler_sha256=digest(profiler), ranked=False, records=records), indent=2) + '\n')
    print(f'{args.mode} {event} Q{query}: exact; profile={profile.exists()}', flush=True)

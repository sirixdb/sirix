"""Package exact group-cache attempts without copying large native/profile artifacts."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from campaign_100m import BASE, EVIDENCE, digest

destination = BASE.parents[1] / 'bundles/sirix-query/bench/jsonbench/evidence/20260912-group-repeat-100m'
destination.mkdir(exist_ok=False)
files = set()
for name in ('paired-group-repeat-instrument-1m-attempt1',
             'paired-group-repeat-before-after-100m-attempt1',
             'paired-group-repeat-100m-attempt1', 'training-group-repeat-100m-attempt1'):
    directory = BASE / name
    assert directory.is_dir(), directory
    files.update(path for path in directory.rglob('*') if path.is_file())
for path in EVIDENCE.iterdir():
    if 'group-repeat' in path.name or path.name == 'group_repeat_campaign.py':
        if path.is_dir():
            files.update(child for child in path.rglob('*') if child.is_file() and '__pycache__' not in child.parts)
        elif path.is_file():
            files.add(path)
for name in ('guard-100m-storage.py', 'scope-exec-100m.py', 'prior_thermal_guard.py',
             'campaign_100m.py', 'freeze-runtime.py', 'freeze-candidate-source.py',
             'paired-retention-100m.py', 'build-limits.gradle', 'upstream-pin.json',
             'serial-directory-v2-source.json', 'serial-directory-instrument-100m-runtime-manifest.json',
             'serial-directory-optimized-100m-runtime-manifest.json',
             'paired-serial-directory-100m-attempt1-validation.json',
             'retention-import-100m-completion.json', 'reopened-rowcount-retention-100m.count.json',
             'corpus-100m-manifest.json', 'clean-corpus-100m-manifest.json',
             'compressed-corpus-100m-manifest.json', 'reflink-feasibility.md'):
    path = EVIDENCE / name
    assert path.is_file(), path
    files.add(path)
files.add(EVIDENCE / 'reflink-feasibility-kernel-6.8/downloads.json')
for name in ('jb', 'jb-instr', 'jsonbench-100m.iprof'):
    files.add(BASE / 'pgo-group-repeat-100m' / name)
for name in ('source-group-repeat-v1.tar.gz', 'source-group-repeat-v1-base.tar.gz'):
    files.add(BASE / name)
large, small = [], []
for path in sorted(files):
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(BASE), path
    if path.suffix in ('.iprof', '.data', '.jfr', '.debug') or path.stat().st_size > 16 * 1024 ** 2:
        large.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
    else:
        small.append(path)
(destination / 'retained-large-files.json').write_text(json.dumps(large, indent=2) + '\n')
archive = destination / 'raw-attempts.tar.gz'
members = []
with archive.open('xb') as target, gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as stream:
        for path in small:
            relative = str(path.relative_to(BASE))
            stream.add(path, arcname=relative, recursive=False)
            members.append(dict(path=relative, bytes=path.stat().st_size, sha256=digest(path)))
with tarfile.open(archive) as stream:
    actual = {member.name: hashlib.sha256(stream.extractfile(member).read()).hexdigest()
              for member in stream.getmembers()}
assert actual == {row['path']: row['sha256'] for row in members}
record = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), files=members)
(destination / 'raw-files.json').write_text(json.dumps(record, indent=2) + '\n')
for name in ('upstream-pin.json', 'group-repeat-upstream-recheck.json', 'group-repeat-v1-source.json',
             'group-repeat-v1-instrument-1m-validation.json', 'group-repeat-v1-before-after-100m-validation.json',
             'paired-group-repeat-100m-attempt1-validation.json', 'group-repeat-toolchain-continuity.json'):
    shutil.copy2(EVIDENCE / name, destination / name)
shutil.copy2(EVIDENCE / 'group-repeat-v1-test-results/manifest.json', destination / 'tests.json')
print(json.dumps(dict(archive=str(archive), members=len(members), bytes=record['bytes'],
                     sha256=record['sha256'], retained_large_files=len(large))))

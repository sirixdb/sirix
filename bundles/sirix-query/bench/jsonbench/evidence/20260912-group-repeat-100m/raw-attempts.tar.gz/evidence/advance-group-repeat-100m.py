"""Continue the guarded exact-group lane on existing databases only."""
import json

from group_repeat_campaign import BASE, EVIDENCE, phase

prerequisite = json.loads((EVIDENCE / 'check-group-repeat-instrument-1m-attempt1.verdict.json').read_text())
if prerequisite['exit_code'] or prerequisite['failures']:
    raise RuntimeError('1M correctness and steering must complete first')
phase('audit-group-repeat-instrument-1m-attempt1',
      ['python3', EVIDENCE / 'audit-group-repeat-comparison.py', '--tier', '1m'])
phase('train-group-repeat-100m-attempt1', ['python3', EVIDENCE / 'train-group-repeat-100m.py'])
phase('optimize-group-repeat-100m-attempt1', ['bash', EVIDENCE / 'group-repeat-lane.sh', 'optimize'])
phase('freeze-optimized-group-repeat-100m',
      ['python3', EVIDENCE / 'freeze-runtime.py', '--label', 'group-repeat-optimized-100m',
       '--log', EVIDENCE / 'optimize-group-repeat-100m-attempt1.log',
       '--binary', BASE / 'pgo-group-repeat-100m/jb',
       '--profile', BASE / 'pgo-group-repeat-100m/jsonbench-100m.iprof', '--jdk', BASE / 'graal-25i4'])
phase('check-group-repeat-before-after-100m-attempt1',
      ['python3', EVIDENCE / 'check-group-repeat-before-after-100m.py'])
phase('audit-group-repeat-before-after-100m-attempt1',
      ['python3', EVIDENCE / 'audit-group-repeat-comparison.py', '--tier', '100m'])
phase('paired-group-repeat-100m-attempt1',
      ['python3', EVIDENCE / 'paired-retention-100m.py', '--tier', '100m',
       '--sirix', BASE / 'pgo-group-repeat-100m/jb', '--db', BASE / 'db-100m-retention',
       '--ch-db', BASE / 'ch26/ch-data-100m', '--rows', '99999968', '--tries', '3', '--rounds', '2',
       '--out', BASE / 'paired-group-repeat-100m-attempt1'])
phase('audit-group-repeat-paired-100m-attempt1', ['python3', EVIDENCE / 'audit-group-repeat-paired-100m.py'])
print('Complete canonical before/after and leader pairing retained; assess the full-size evidence.', flush=True)

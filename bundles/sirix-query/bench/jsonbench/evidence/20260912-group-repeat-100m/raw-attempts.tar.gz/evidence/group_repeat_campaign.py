"""Guarded stages for the independent existing-database group lookup experiment."""
import json
import math
from pathlib import Path
import shutil
import subprocess
import time

from campaign_100m import BASE, EVIDENCE, digest

BUDGET = EVIDENCE / 'group-repeat-budget.json'
INBOX = Path('/home/johannes/IdeaProjects/firstmate/state/sirix-cb-top10.inbox')


def initialize():
    if BUDGET.exists():
        return
    free = shutil.disk_usage(BASE).free
    allowed = 4 * 1024 ** 3
    floor = max(20, math.ceil((free - allowed) / 1024 ** 3))
    if free - 20 * 1024 ** 3 < allowed:
        raise RuntimeError('existing-database experiment lacks its build allowance')
    record = dict(started=time.time(), starting_free_bytes=free, additional_build_allowance_bytes=allowed,
                  guard_min_free_gib=floor, permanent_floor_gib=20, new_database_allowed=False,
                  column_major_capacity_decision='open', completed_phases=[])
    with BUDGET.open('x') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')


def phase(name, command):
    initialize()
    while list(INBOX.glob('*.msg')):
        print('Awaiting active agent handling of Firstmate inbox before next stage', flush=True)
        time.sleep(5)
    prefix = EVIDENCE / name
    if any(prefix.with_suffix(suffix).exists() for suffix in ('.log', '.verdict.json', '.telemetry.jsonl')):
        raise RuntimeError('refusing to overwrite stage evidence: ' + name)
    budget = json.loads(BUDGET.read_text())
    print('START ' + name, flush=True)
    subprocess.run(['python3', str(EVIDENCE / 'guard-100m-storage.py'), '--prefix', str(prefix),
                    '--min-free-gib', str(budget['guard_min_free_gib']), '--',
                    'systemd-run', '--user', '--scope', '--quiet', '--collect', '--unit=jsonbench-' + name,
                    '--property=MemoryMax=24G', '--property=MemorySwapMax=0',
                    'python3', str(EVIDENCE / 'scope-exec-100m.py'), str(prefix), *map(str, command)], check=True)
    verdict_path = prefix.with_suffix('.verdict.json')
    verdict = json.loads(verdict_path.read_text())
    if verdict['exit_code'] or verdict['failures']:
        raise RuntimeError('stage guard failed: ' + name)
    owned = [path for path in BASE.iterdir() if 'group-repeat' in path.name]
    sizes = {str(path): int(subprocess.check_output(['du', '-s', '-B1', str(path)], text=True).split()[0])
             for path in owned}
    allocated = sum(sizes.values())
    budget['completed_phases'].append(dict(name=name, finished=time.time(), allocated_candidate_bytes=allocated,
                                           allocations=sizes, verdict_sha256=digest(verdict_path)))
    BUDGET.write_text(json.dumps(budget, indent=2) + '\n')
    if allocated > budget['additional_build_allowance_bytes']:
        raise RuntimeError('candidate artifacts exceed the 4 GiB allowance')
    print('PASS ' + name, flush=True)

"""Audit the complete group-repeat/ClickHouse pairing; retain prior results only as context."""
import json
import math
from pathlib import Path

from campaign_100m import BASE, EVIDENCE, digest

directory = BASE / 'paired-group-repeat-100m-attempt1'
baseline = BASE / 'paired-serial-directory-100m-attempt1'
verdict = json.loads((EVIDENCE / 'paired-group-repeat-100m-attempt1.verdict.json').read_text())
assert verdict['exit_code'] == 0 and verdict['failures'] == []
runtime = json.loads((EVIDENCE / 'group-repeat-optimized-100m-runtime-manifest.json').read_text())
assert digest(Path(runtime['binary'])) == runtime['binary_sha256']
protocol = json.loads((directory / 'protocol.json').read_text())
assert protocol == json.loads((baseline / 'protocol.json').read_text())
assert protocol['rows'] == 99_999_968 and protocol['tries'] == 3 and protocol['rounds'] == 2
raw = [json.loads(line) for line in (directory / 'attempts.jsonl').read_text().splitlines()]
before = [json.loads(line) for line in (baseline / 'attempts.jsonl').read_text().splitlines()]
assert len(raw) == 60
key = lambda row: (row['round'], row['query'], row['engine'], row['attempt'])
assert {key(row) for row in raw} == {
    (rnd, query, engine, attempt) for rnd in (1, 2) for query in range(1, 6)
    for engine in ('sirix', 'ch') for attempt in (1, 2, 3)}
for row in raw:
    assert math.isfinite(row['seconds']) and row['seconds'] > 0
    if row['engine'] == 'sirix':
        expected = [item['route'] for item in before if item['engine'] == 'sirix' and item['query'] == row['query']]
        assert expected and all(row['route'] == value for value in expected)
for query in range(1, 6):
    assert json.loads((directory / f'differential-q{query}.json').read_text()) == []
evictions = list(directory.glob('r*-eviction.json'))
assert len(evictions) == 20
for path in evictions:
    records = json.loads(path.read_text())
    assert records and all(row['resident_after'] == 0 for row in records)
rounds = json.loads((directory / 'rounds.json').read_text())
before_rounds = json.loads((baseline / 'rounds.json').read_text())
assert len(rounds) == 2
for rnd, record in enumerate(rounds, 1):
    assert record['round'] == rnd
    for engine in ('sirix', 'ch'):
        expected = [[next(row['seconds'] for row in raw if key(row) == (rnd, query, engine, attempt))
                     for attempt in (1, 2, 3)] for query in range(1, 6)]
        assert record['result'][engine] == expected
    for mode in ('cold', 'hot'):
        select = (lambda row: row[0]) if mode == 'cold' else (lambda row: min(row[1:]))
        ratios = [(select(sirix) + .010) / (select(clickhouse) + .010)
                  for sirix, clickhouse in zip(record['result']['sirix'], record['result']['ch'])]
        score = math.exp(sum(math.log(value) for value in ratios) / 5)
        assert math.isclose(score, record['metrics'][mode]['geometric_ratio'], rel_tol=1e-12)
telemetry = [json.loads(line) for line in
             (EVIDENCE / 'paired-group-repeat-100m-attempt1.telemetry.jsonl').read_text().splitlines()]
count = json.loads((EVIDENCE / 'reopened-rowcount-retention-100m.count.json').read_text())
assert count['persisted_child_count'] == 99_999_968 and count['exact']
record = dict(rows=99_999_968, exact_queries=5, attempts=60, sirix_route_checks=30,
              verified_cold_blocks=20, binary_sha256=runtime['binary_sha256'],
              source_manifest_sha256=digest(EVIDENCE / 'group-repeat-v1-source.json'),
              profile_sha256=runtime['profile']['sha256'], guard_failures=[],
              guard_samples=verdict['samples'],
              max_C=max(max(row['package_C'].values()) for row in telemetry),
              max_sample_gap_s=max(row.get('sample_gap_s', 0) for row in telemetry),
              rounds=[dict(round=row['round'], metrics=row['metrics']) for row in rounds],
              historical_unpaired_context_only=[
                  {mode: after['metrics'][mode]['geometric_ratio'] / prior['metrics'][mode]['geometric_ratio']
                   for mode in ('cold', 'hot')} for after, prior in zip(rounds, before_rounds)],
              rank_one=all(row['metrics']['hot']['geometric_ratio'] < 1 for row in rounds))
(EVIDENCE / 'paired-group-repeat-100m-attempt1-validation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))

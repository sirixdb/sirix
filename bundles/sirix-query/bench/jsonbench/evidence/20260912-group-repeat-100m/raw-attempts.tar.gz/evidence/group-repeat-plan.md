# Existing-database experiment: repeated dense group acquisition

The separate column-major 100M capacity decision remains open. This experiment does not import,
migrate, overwrite or delete a database. Frozen column-major v5 source and runtime hashes were
verified again when handling inbox 029, including its archive
`d81e02d69c222b755a443b6412eae5bb8b4ee924b2feaec243a332ea7cfed343`.

Use `db-100m-retention` (99,999,968 cleaned rows, revision 1), `ch26/ch-data-100m`, and the current
serial-directory native baseline `pgo-serial-directory-100m/jb`, SHA-256
`50ccd4f1938c0d87a16d5a6a6ebca257175e4b9cbcbec34fe3d9f5f6f0cbfe6c`.

Retained `profile-debug-lz77-100m-attempt1/q1-symbols-self.txt` attributes 13.04% of atom-core and
10.72% of performance-core sampled CPU cycles to `NumericGroupAggTable.acquireDense`; its caller
accounts for another 17.58% and 15.55%. Directory walking remains larger in some profiles, but the
already negative atomic-array, directory-batching and manual-decoding experiments are excluded.

Bounded change: remember the last dense-table key and record handle. A same-key request must still
compare every exact identity lane against current record storage. Dense record handles survive
index growth; backing arrays are re-resolved, and release invalidates the remembered handle. There
is no global state, persisted format change, prepass or allocation per lookup. High-cardinality
workloads pay the additional comparison, so full-size results across all five queries decide
whether the change is retained.

Freeze a fresh source tree from commit `81cdec2d544f6829c5e9c3cd9fe56fe76b9984d8` with only
`NumericGroupAggTable.java` and `RepeatedDenseGroupTest.java` overlaid. Keep the independent
column-major changes in the worktree and its original frozen tree without incorporating them into
this measurement. Never reuse pooled build outputs.

Run focused table, collision, partial-group, sum and composite correctness tests plus query shape
and identity differential tests. Build a fresh instrumented image, run all-five 1M differential
steering on the existing fixture, then train on the verified 100M database with exact output and
route checks. Build the optimized image and retain complete paired 100M Sirix/ClickHouse attempts
under `jsonbench-isolated-v1`; also compare before/after native runtimes on the same full database.
No small-data result completes the goal.

The existing 4 GiB additional-build allowance covers one fresh checkout/build (~1 GiB), native
images and retained jars (<0.5 GiB), profiles/attempts (<1.5 GiB), plus remaining overhead. Record
the starting free-space measurement and raise this experiment's guard free-space minimum to the
ceiling of `(starting free bytes - 4 GiB) / GiB`, never below the unchanged 20 GiB floor. This
conservatively caps observed filesystem growth below 4 GiB. All stages retain continuous thermal,
EPP, profile, throttle-counter and sampling-gap enforcement; only owned benchmark processes may
be stopped. The extra-space decision for a new database is neither resolved nor bypassed here.

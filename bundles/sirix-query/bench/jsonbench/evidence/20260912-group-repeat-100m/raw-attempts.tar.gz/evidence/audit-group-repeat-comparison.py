"""Recompute a complete same-database before/after comparison from raw attempts."""
import argparse
import json
import math

from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('--tier', choices=('1m', '100m'), required=True)
args = parser.parse_args()
small = args.tier == '1m'
label = 'instrument-1m' if small else 'before-after-100m'
directory = BASE / ('paired-group-repeat-' + label + '-attempt1')
phase = 'check-group-repeat-' + label + '-attempt1'
output = EVIDENCE / ('group-repeat-v1-' + label + '-validation.json')
if output.exists():
    raise RuntimeError('refusing to overwrite comparison audit')
protocol = json.loads((directory / 'protocol.json').read_text())
assert protocol['rows'] == (1_000_000 if small else 99_999_968)
assert protocol['rounds'] == 2 and protocol['tries'] == 3
raw = [json.loads(line) for line in (directory / 'attempts.jsonl').read_text().splitlines()]
key = lambda row: (row['round'], row['query'], row['variant'], row['attempt'])
assert len(raw) == 60
assert {key(row) for row in raw} == {(rnd, query, variant, attempt)
    for rnd in (1, 2) for query in range(1, 6) for variant in ('before', 'after') for attempt in (1, 2, 3)}
for row in raw:
    assert math.isfinite(row['seconds']) and row['seconds'] > 0
for query in range(1, 6):
    for variant in ('before', 'after'):
        assert json.loads((directory / f'differential-{variant}-q{query}.json').read_text()) == []
    counters = [row['counters'] for row in raw if row['query'] == query]
    assert all(row == counters[0] for row in counters)
evictions = list(directory.glob('r*-eviction.json'))
assert len(evictions) == 20
for path in evictions:
    entries = json.loads(path.read_text())
    assert entries and all(row['resident_after'] == 0 for row in entries)
rounds = json.loads((directory / 'rounds.json').read_text())
assert len(rounds) == 2
for rnd, record in enumerate(rounds, 1):
    assert record['round'] == rnd
    for variant in ('before', 'after'):
        for query, entry in enumerate(record['queries'][variant], 1):
            times = [next(row['seconds'] for row in raw if key(row) == (rnd, query, variant, attempt))
                     for attempt in (1, 2, 3)]
            assert entry == dict(query=query, times=times, cold=times[0], hot=min(times[1:]))
    for mode in ('cold', 'hot'):
        score = math.exp(sum(math.log((after[mode] + .010) / (before[mode] + .010))
                            for after, before in zip(record['queries']['after'], record['queries']['before'])) / 5)
        assert math.isclose(score, record['after_over_before'][mode], rel_tol=1e-12)
verdict = json.loads((EVIDENCE / (phase + '.verdict.json')).read_text())
assert verdict['exit_code'] == 0 and not verdict['failures']
assert verdict['min_disk_free_bytes'] >= 20 * 1024 ** 3
telemetry = [json.loads(line) for line in (EVIDENCE / (phase + '.telemetry.jsonl')).read_text().splitlines()]
assert len(list(directory.glob('*.iprof'))) == (70 if small else 0)
for variant in ('before', 'after'):
    assert digest(protocol['variants'][variant]) == protocol['binary_hashes'][variant]
record = dict(tier=args.tier, rows=protocol['rows'], exact_queries_per_variant=5, attempts=60,
              route_checks=60, verified_cold_blocks=20, binary_hashes=protocol['binary_hashes'],
              source_manifest_sha256=digest(EVIDENCE / 'group-repeat-v1-source.json'),
              guard_samples=verdict['samples'], guard_failures=[],
              max_C=max(max(row['package_C'].values()) for row in telemetry),
              max_sample_gap_s=max(row.get('sample_gap_s', 0) for row in telemetry),
              min_free_bytes=min(row['disk_free_bytes'] for row in telemetry),
              rounds=[dict(round=row['round'], after_over_before=row['after_over_before']) for row in rounds],
              leaderboard_claim=False, reason='same-engine before/after; independent leader pairing remains required')
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))

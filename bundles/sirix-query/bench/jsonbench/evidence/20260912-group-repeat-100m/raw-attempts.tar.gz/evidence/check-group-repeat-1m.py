"""Guarded paired 1M group-repeat steering; instrumented timings are unranked."""
import importlib.util
import json
import math
from pathlib import Path

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
out = BASE / 'paired-group-repeat-instrument-1m-attempt1'
out.mkdir(exist_ok=False)
db = BASE / 'db-1m-retention-repaired'
variants = {}
manifests = {}
for variant, label in [('before', 'serial-directory-instrument-100m'), ('after', 'group-repeat-instrument-100m')]:
    manifests[variant] = json.loads((EVIDENCE / (label + '-runtime-manifest.json')).read_text())
    binary = Path(manifests[variant]['binary'])
    if digest(binary) != manifests[variant]['binary_sha256']:
        raise RuntimeError('binary changed after runtime freeze: ' + variant)
    variants[variant] = binary
flags = ['-Djava.io.tmpdir=' + str(BASE / 'tmp')]
(out / 'protocol.json').write_text(json.dumps(dict(
    purpose='instrumented 1M correctness and steering; never a leaderboard score',
    variants={key: str(value) for key, value in variants.items()},
    binary_hashes={key: value['binary_sha256'] for key, value in manifests.items()},
    database=str(db), rows=1_000_000, flags=flags, rounds=2, tries=3,
    pairing='per-query AB in round 1, BA in round 2',
    cache='verified evicted files before first attempt; fresh process each attempt; later attempts warm OS cache',
    score='geomean((after query seconds + .010)/(before query seconds + .010))',
    ranked=False, profiles='unique profile path for every process; no profile reused by optimized build'), indent=2) + '\n')
correctness_routes = {}
for variant, binary in variants.items():
    for query in range(1, 6):
        paired.cool()
        stem = out / f'correctness-{variant}-q{query}'
        dump = out / f'dump-{variant}-q{query}'
        paired.run([binary, db, '--queries', query, '--tries', 1, '--dump', dump,
                    '-XX:ProfilesDumpFile=' + str(stem.with_suffix('.iprof')),
                    '-Dsirix.lz77Codec.diag=true', *flags], stem)
        correctness_routes[(variant, query)] = paired.routes(stem)
        expected = 'NATIVE_DECODER_ENABLED=' + 'true'
        if expected not in stem.with_suffix('.stdout').read_text():
            raise RuntimeError('unexpected decoder activation: ' + str(stem))
        definition = paired.compare.SPECS[query]
        failures = paired.compare.compare(
            definition, paired.compare.read_dump(dump / f'q{query}.jsonl', definition),
            paired.compare.read_reference(BASE / f'ch26/ch-ref-1m/q{query}.tsv', definition), False)
        (out / f'differential-{variant}-q{query}.json').write_text(json.dumps(failures) + '\n')
        if failures:
            raise RuntimeError(f'{variant} Q{query} exact differential mismatch: {failures}')
        if variant == 'after' and correctness_routes[(variant, query)] != correctness_routes[('before', query)]:
            raise RuntimeError('route changed between dense-group lookup implementations')
        print(f'{variant} Q{query}: exact MATCH; {expected}', flush=True)
rounds = []
for rnd in (1, 2):
    matrix = {variant: [] for variant in variants}
    for query in range(1, 6):
        for variant in (('before', 'after') if rnd == 1 else ('after', 'before')):
            paired.cool()
            paired.cold_cache(db, out / f'r{rnd}-q{query}-{variant}-eviction.json')
            times = []
            for attempt in range(1, 4):
                stem = out / f'r{rnd}-q{query}-{variant}-a{attempt}'
                result = stem.with_suffix('.result.json')
                wall = paired.run([variants[variant], db, '--queries', query, '--tries', 1, '--json', result,
                                   '-XX:ProfilesDumpFile=' + str(stem.with_suffix('.iprof')), *flags], stem)
                counters = paired.routes(stem)
                if counters != correctness_routes[(variant, query)]:
                    raise RuntimeError('timing used a different route')
                seconds = json.loads(result.read_text())['result'][query - 1][0]
                if not math.isfinite(seconds) or seconds <= 0:
                    raise RuntimeError('invalid instrumented timing')
                times.append(seconds)
                with (out / 'attempts.jsonl').open('a') as stream:
                    stream.write(json.dumps(dict(round=rnd, query=query, variant=variant, attempt=attempt,
                                                 seconds=seconds, process_wall_s=wall, counters=counters)) + '\n')
            matrix[variant].append(dict(query=query, times=times, cold=times[0], hot=min(times[1:])))
            print(f'round {rnd} Q{query} {variant}: {times} (instrumented, unranked)', flush=True)
    scores = {mode: math.exp(sum(math.log((a[mode] + .010) / (b[mode] + .010))
                                  for a, b in zip(matrix['after'], matrix['before'])) / 5)
              for mode in ('cold', 'hot')}
    rounds.append(dict(round=rnd, queries=matrix, after_over_before=scores, ranked=False))
    (out / 'rounds.json').write_text(json.dumps(rounds, indent=2) + '\n')
    print(json.dumps(rounds[-1]), flush=True)

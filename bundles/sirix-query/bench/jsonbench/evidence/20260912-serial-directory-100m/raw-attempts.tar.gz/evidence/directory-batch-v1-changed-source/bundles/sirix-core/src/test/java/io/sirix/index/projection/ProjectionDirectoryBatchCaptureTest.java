/*
 * Copyright (c) 2026, SirixDB. All rights reserved.
 */
package io.sirix.index.projection;

import io.sirix.access.trx.page.HOTTrieReader;
import io.sirix.api.StorageEngineReader;
import io.sirix.index.IndexType;
import io.sirix.index.hot.PathKeySerializer;
import io.sirix.index.projection.ProjectionIndexHOTStorage.DirectorySlotBuffer;
import io.sirix.index.projection.ProjectionIndexHOTStorage.SlotCapture;
import io.sirix.node.LE;
import io.sirix.page.HOTLeafPage;
import org.junit.jupiter.api.Test;

import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** Real packed slot reads with deterministic validation/reload outcomes at batch boundaries. */
final class ProjectionDirectoryBatchCaptureTest {
  private static final int ENTRIES = 80;

  @Test
  void stableBatchesRetainEverySlotIncludingTheShortFinalBatch() {
    try (Fixture fixture = fixture(10, -1, 0)) {
      final HOTTrieReader trie = mock(HOTTrieReader.class);
      when(trie.validateCurrentLeaf()).thenReturn(true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      assertTrue(capture(trie, fixture.leaf, buffer));
      assertPayloads(buffer, 0, ENTRIES, 10);
      assertEquals(ENTRIES, buffer.count);
      verify(trie, times(3)).validateCurrentLeaf();
      verify(trie, never()).recoverTorn(anyInt(), anyString());
    }
  }

  @Test
  void tornFirstBatchIsReplacedWithoutDuplicatedCaptures() {
    try (Fixture stale = fixture(10, -1, 0); Fixture fresh = fixture(20, -1, 0)) {
      final HOTTrieReader trie = reloadingTrie(fresh.leaf, true, false, true, true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      assertTrue(capture(trie, stale.leaf, buffer));
      assertEquals(ENTRIES, buffer.count);
      assertPayloads(buffer, 0, ENTRIES, 20);
      verify(trie, times(1)).recoverTorn(1, "projection parallel directory walk");
    }
  }

  @Test
  void tornFinalBatchPreservesTheAlreadyValidatedPrefix() {
    try (Fixture stale = fixture(10, -1, 0); Fixture fresh = fixture(20, -1, 0)) {
      final HOTTrieReader trie = reloadingTrie(fresh.leaf, true, true, false, true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      assertTrue(capture(trie, stale.leaf, buffer));
      assertEquals(ENTRIES, buffer.count);
      assertPayloads(buffer, 0, 64, 10);
      assertPayloads(buffer, 64, ENTRIES, 20);
    }
  }

  @Test
  void stableCorruptionRollsBackAndEscapesWithoutRetry() {
    try (Fixture fixture = fixture(10, 5, 2)) {
      final HOTTrieReader trie = mock(HOTTrieReader.class);
      when(trie.validateCurrentLeaf()).thenReturn(true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      final IllegalStateException failure =
          assertThrows(IllegalStateException.class, () -> capture(trie, fixture.leaf, buffer));
      assertTrue(failure.getMessage().contains("unknown discriminator"), failure::getMessage);
      assertCleared(buffer, 0, 5);
      verify(trie, never()).recoverTorn(anyInt(), anyString());
    }
  }

  @Test
  void corruptionUnderATornStampRetriesInsteadOfEscaping() {
    try (Fixture stale = fixture(10, 5, 2); Fixture fresh = fixture(20, -1, 0)) {
      final HOTTrieReader trie = reloadingTrie(fresh.leaf, true, false, true, true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      assertTrue(capture(trie, stale.leaf, buffer));
      assertEquals(ENTRIES, buffer.count);
      assertPayloads(buffer, 0, ENTRIES, 20);
    }
  }

  @Test
  void stableUnresolvedReferenceDiscardsOnlyItsUncommittedBatch() {
    try (Fixture fixture = fixture(10, 70, 1)) {
      final HOTTrieReader trie = mock(HOTTrieReader.class);
      when(trie.validateCurrentLeaf()).thenReturn(true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      assertFalse(capture(trie, fixture.leaf, buffer));
      assertCleared(buffer, 64, 70);
      assertPayloads(buffer, 0, 64, 10);
    }
  }

  @Test
  void unresolvedReferenceUnderATornStampDoesNotPrematurelyDecline() {
    try (Fixture stale = fixture(10, 70, 1); Fixture fresh = fixture(20, -1, 0)) {
      final HOTTrieReader trie = reloadingTrie(fresh.leaf, true, true, false, true);
      final DirectorySlotBuffer buffer = new DirectorySlotBuffer();
      assertTrue(capture(trie, stale.leaf, buffer));
      assertEquals(ENTRIES, buffer.count);
      assertPayloads(buffer, 0, 64, 10);
      assertPayloads(buffer, 64, ENTRIES, 20);
    }
  }

  private static HOTTrieReader reloadingTrie(final HOTLeafPage fresh, final boolean first, final Boolean... remaining) {
    final HOTTrieReader trie = mock(HOTTrieReader.class);
    when(trie.validateCurrentLeaf()).thenReturn(first, remaining);
    when(trie.currentLeafPage()).thenReturn(fresh);
    return trie;
  }

  private static boolean capture(final HOTTrieReader trie, final HOTLeafPage leaf, final DirectorySlotBuffer buffer) {
    return ProjectionIndexHOTStorage.captureLeafDirectorySlots(mock(StorageEngineReader.class), trie, 0, leaf,
        new SlotCapture(), buffer);
  }

  private static void assertPayloads(final DirectorySlotBuffer buffer, final int from, final int to, final int base) {
    for (int index = from; index < to; index++) {
      assertArrayEquals(new byte[] {(byte) (base + index)}, buffer.payloads[index], "slot " + index);
    }
  }

  private static void assertCleared(final DirectorySlotBuffer buffer, final int checkpoint, final int end) {
    assertEquals(checkpoint, buffer.count);
    for (int index = checkpoint; index < end; index++) {
      assertNull(buffer.payloads[index], "rejected payload remains retained at " + index);
    }
  }

  private static Fixture fixture(final int payloadBase, final int specialIndex, final int specialKind) {
    final Arena arena = Arena.ofConfined();
    try {
      final MemorySegment packed = arena.allocate(ENTRIES * 14L);
      final int[] offsets = new int[ENTRIES];
      final byte[] key = new byte[8];
      for (int index = 0; index < ENTRIES; index++) {
        final int offset = index * 14;
        offsets[index] = offset;
        packed.set(LE.SHORT, offset, (short) 8);
        PathKeySerializer.INSTANCE.serialize((1L << 16) + index + 1, key, 0);
        MemorySegment.copy(key, 0, packed, ValueLayout.JAVA_BYTE, offset + 2, key.length);
        packed.set(LE.SHORT, offset + 10, (short) 2);
        packed.set(ValueLayout.JAVA_BYTE, offset + 12, (byte) (index == specialIndex
            ? specialKind
            : 0));
        packed.set(ValueLayout.JAVA_BYTE, offset + 13, (byte) (payloadBase + index));
      }
      final HOTLeafPage leaf =
          new HOTLeafPage(1, 1, IndexType.PROJECTION, packed, null, offsets, ENTRIES, ENTRIES * 14, new byte[0], 0);
      return new Fixture(arena, leaf);
    } catch (final RuntimeException | Error failure) {
      arena.close();
      throw failure;
    }
  }

  private record Fixture(Arena arena, HOTLeafPage leaf) implements AutoCloseable {
    @Override
    public void close() {
      try {
        leaf.close();
      } finally {
        arena.close();
      }
    }
  }
}

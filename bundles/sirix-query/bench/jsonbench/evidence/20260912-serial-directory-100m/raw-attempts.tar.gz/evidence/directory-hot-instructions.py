"""Bounded source attribution for only the hottest directory PCs in retained perf data."""
from collections import Counter
import json
import re
import subprocess
from campaign_100m import BASE, digest

out = BASE / 'directory-hot-instructions-attempt2'
out.mkdir(exist_ok=False)
debug = BASE / 'pgo-lz77-debug-100m/jb.debug'
assert digest(debug) == '65ea85306e34750df3eac492b8f599046630c32c4f5a9542e3564aeeed4ae8db'
symbols = subprocess.check_output(['nm', '-n', str(debug)], text=True)
matches = [line for line in symbols.splitlines() if 'captureLeafDirectorySlots' in line]
assert len(matches) == 1
base_address = int(matches[0].split()[0], 16)
for query in (1, 4):
    command = ['perf', 'script', '-i', str(BASE / f'profile-debug-lz77-100m-attempt1/q{query}.perf.data'),
               '-G', '--no-inline', '-F', 'ip,sym,symoff']
    samples = out / f'q{query}-samples.txt'
    with samples.open('x') as stream, (out / f'q{query}-perf.stderr').open('x') as error:
        subprocess.run(command, stdout=stream, stderr=error, check=True, timeout=60)
    counts = Counter()
    for line in samples.read_text().splitlines():
        if 'captureLeafDirectorySlots' not in line:
            continue
        match = re.search(r'\+0x([0-9a-f]+)', line)
        if match:
            counts[int(match[1], 16)] += 1
    if not counts:
        raise RuntimeError('no directory instruction offsets found; retain raw sample format')
    top = [dict(offset=hex(offset), address=hex(base_address + offset), samples=count)
           for offset, count in counts.most_common(24)]
    (out / f'q{query}-top.json').write_text(json.dumps(dict(total=sum(counts.values()), top=top), indent=2) + '\n')
    command = ['addr2line', '-a', '-f', '-C', '-i', '-e', str(debug), *[item['address'] for item in top]]
    with (out / f'q{query}-source.txt').open('x') as stream, (out / f'q{query}-source.stderr').open('x') as error:
        subprocess.run(command, stdout=stream, stderr=error, check=True, timeout=60)
    print(f'Q{query}: {sum(counts.values())} directory samples, 24 hottest offsets resolved', flush=True)

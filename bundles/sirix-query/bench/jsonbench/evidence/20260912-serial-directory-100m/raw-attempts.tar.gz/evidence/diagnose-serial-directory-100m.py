"""Unranked phase attribution and optional perf capture; run only beneath the guard."""
import argparse
import importlib.util
import json
from pathlib import Path

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
parser = argparse.ArgumentParser()
parser.add_argument('--manifest', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--source-manifest', type=Path, required=True)
parser.add_argument('--queries', default='1,4')
parser.add_argument('--perf', action='store_true')
args = parser.parse_args()
manifest = json.loads(args.manifest.read_text())
binary = Path(manifest['binary'])
if digest(binary) != manifest['binary_sha256']:
    raise RuntimeError('Diagnostic binary differs from its frozen manifest')
args.out.mkdir(exist_ok=False)
flags = ['-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
         '-Dsirix.projection.promoteMaxBytes=0', '-Djava.io.tmpdir=' + str(BASE / 'tmp')]
records = []
for query in [int(value) for value in args.queries.split(',')]:
    if query not in range(1, 6):
        raise ValueError('Only the five canonical queries are accepted')
    paired.cool()
    paired.cold_cache(BASE / 'db-100m-retention', args.out / f'q{query}-eviction.json')
    stem = args.out / f'q{query}-diagnostic'
    dump = args.out / f'q{query}-dump'
    command = [binary, BASE / 'db-100m-retention', '--queries', query, '--tries', 1,
               '--dump', dump, '-Dsirix.projDiag=true', '-Dsirix.projection.fillDiag=true', '-Dsirix.lz77Codec.diag=true', *flags]
    paired.run(command, stem)
    routes = paired.routes(stem)
    output = stem.with_suffix('.stdout').read_text() + stem.with_suffix('.stderr').read_text()
    if 'NATIVE_DECODER_ENABLED=true' not in output:
        raise RuntimeError('optimized native decoder was not confirmed')
    if '[parwalk] ENGAGED' in output:
        raise RuntimeError('serial default unexpectedly opened parallel directory workers')
    definition = paired.compare.SPECS[query]
    failures = paired.compare.compare(
        definition, paired.compare.read_dump(dump / f'q{query}.jsonl', definition),
        paired.compare.read_reference(BASE / f'ch26/ch-ref-100m/q{query}.tsv', definition), False)
    (args.out / f'q{query}-differential.json').write_text(json.dumps(failures) + '\n')
    if failures:
        raise RuntimeError(f'Diagnostic Q{query} failed exact differential: {failures}')
    item = dict(query=query, exact=True, routes=routes, ranked=False)
    if args.perf and query in (1, 4):
        paired.cool()
        profile = args.out / f'q{query}.perf.data'
        paired.run(['perf', 'record', '-e', 'cycles:u', '-F', '499', '-g', '--call-graph',
                    'dwarf,16384', '-o', profile, '--', binary, BASE / 'db-100m-retention',
                    '--queries', query, '--tries', 1, *flags], args.out / f'q{query}-profile')
        item['profile_routes'] = paired.routes(args.out / f'q{query}-profile')
        item['profile'] = str(profile)
    records.append(item)
    print(f'Q{query}: diagnostic exact match, unranked; profile={args.perf and query in (1, 4)}', flush=True)
(args.out / 'manifest.json').write_text(json.dumps(dict(
    binary_sha256=manifest['binary_sha256'], source_manifest_sha256=digest(args.source_manifest),
    rows=99_999_968, ranked=False, queries=records), indent=2) + '\n')

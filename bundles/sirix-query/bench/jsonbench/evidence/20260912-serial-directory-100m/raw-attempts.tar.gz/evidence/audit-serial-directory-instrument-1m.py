"""Audit the complete 1M instrumented steering experiment; not a leaderboard score."""
import json
import math
from pathlib import Path
from campaign_100m import BASE, EVIDENCE, digest

out = BASE / 'paired-serial-directory-instrument-1m-attempt1'
verdict = json.loads((EVIDENCE / 'check-serial-directory-instrument-1m-attempt1.verdict.json').read_text())
assert verdict['exit_code'] == 0 and not verdict['failures']
raw = [json.loads(line) for line in (out / 'attempts.jsonl').read_text().splitlines()]
key = lambda row: (row['round'], row['query'], row['variant'], row['attempt'])
assert len(raw) == 60 and {key(row) for row in raw} == {
    (rnd, query, variant, attempt) for rnd in (1, 2) for query in range(1, 6)
    for variant in ('before', 'after') for attempt in (1, 2, 3)}
for variant, label in [('before', 'lz77-instrument-100m'), ('after', 'serial-directory-instrument-100m')]:
    manifest = json.loads((EVIDENCE / (label + '-runtime-manifest.json')).read_text())
    assert digest(Path(manifest['binary'])) == manifest['binary_sha256']
    for query in range(1, 6):
        assert json.loads((out / f'differential-{variant}-q{query}.json').read_text()) == []
        assert 'NATIVE_DECODER_ENABLED=true' in (out / f'correctness-{variant}-q{query}.stdout').read_text()
for query in range(1, 6):
    counters = [row['counters'] for row in raw if row['query'] == query]
    assert all(counter == counters[0] for counter in counters)
    assert counters[0]['groupAggregates'] == 1
for row in raw:
    assert math.isfinite(row['seconds']) and row['seconds'] > 0
profiles = list(out.glob('*.iprof'))
assert len(profiles) == 70 and all(p.stat().st_size > 0 for p in profiles)
evictions = list(out.glob('r*-eviction.json'))
assert len(evictions) == 20
for path in evictions:
    records = json.loads(path.read_text())
    assert records and all(row['resident_after'] == 0 for row in records)
rounds = json.loads((out / 'rounds.json').read_text())
assert len(rounds) == 2
for rnd, record in enumerate(rounds, 1):
    assert record['round'] == rnd and record['ranked'] is False
    for variant in ('before', 'after'):
        for query, item in enumerate(record['queries'][variant], 1):
            times = [next(row['seconds'] for row in raw if key(row) == (rnd, query, variant, attempt))
                     for attempt in (1, 2, 3)]
            assert item == dict(query=query, times=times, cold=times[0], hot=min(times[1:]))
    for mode in ('hot', 'cold'):
        ratios = [(after[mode] + .010) / (before[mode] + .010)
                  for after, before in zip(record['queries']['after'], record['queries']['before'])]
        score = math.exp(sum(math.log(ratio) for ratio in ratios) / 5)
        assert math.isclose(score, record['after_over_before'][mode], rel_tol=1e-12)
record = dict(ranked=False, rows=1_000_000, exact_queries_per_variant=5, attempts=60,
              native_decoder_both_variants=True, unique_unranked_profiles=70,
              verified_cold_blocks=20, guard_samples=verdict['samples'], guard_failures=[],
              after_over_before=[row['after_over_before'] for row in rounds])
(EVIDENCE / 'serial-directory-instrument-1m-validation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

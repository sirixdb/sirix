"""Build or run the read-only locator probe from frozen dependency JARs; guard required."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=('compile', 'steer'))
args = parser.parse_args()
probe = Path(__file__).resolve().parent
build = BASE / 'locator-probe-v1'
classes = build / 'classes'
source = probe / 'ProjectionLocatorProbe.java'
runtime = json.loads((EVIDENCE / 'lz77-optimized-100m-runtime-manifest.json').read_text())
jars = []
for item in runtime['classpath']:
    jar = Path(item['retained'])
    if digest(jar) != item['sha256']:
        raise RuntimeError('dependency differs from the frozen runtime: ' + str(jar))
    jars.append(str(jar))

if args.phase == 'compile':
    classes.mkdir(parents=True, exist_ok=False)
    command = [str(BASE / 'graal-25i4/bin/javac'), '--enable-preview', '--release', '25',
               '-cp', ':'.join(jars), '-d', str(classes), str(source)]
    subprocess.run(command, check=True)
    record = dict(source=str(source), source_sha256=digest(source), command=command,
                  runtime_manifest_sha256=digest(EVIDENCE / 'lz77-optimized-100m-runtime-manifest.json'),
                  classes=[dict(path=str(path), sha256=digest(path)) for path in sorted(classes.rglob('*.class'))],
                  production_changes=False, ranked=False)
    (build / 'build-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record, indent=2))
else:
    frozen = json.loads((build / 'build-manifest.json').read_text())
    assert frozen['source_sha256'] == digest(source)
    for item in frozen['classes']:
        assert digest(Path(item['path'])) == item['sha256']
    spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
    paired = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(paired)
    out = BASE / 'locator-probe-1m-attempt1'
    out.mkdir(exist_ok=False)
    db = BASE / 'db-1m-retention-repaired'
    records = []
    expected_hash = None
    for round_id in (1, 2):
        for mode in (('all', 'selected') if round_id == 1 else ('selected', 'all')):
            paired.cool()
            paired.cold_cache(db, out / f'r{round_id}-{mode}-eviction.json')
            for attempt in (1, 2, 3):
                stem = out / f'r{round_id}-{mode}-a{attempt}'
                command = [BASE / 'graal-25i4/bin/java', '--enable-preview', '--enable-native-access=ALL-UNNAMED',
                           '--add-modules=jdk.incubator.vector', '-XX:-UseJVMCICompiler',
                           '--add-opens=java.base/sun.nio.ch=ALL-UNNAMED',
                           '--add-opens=java.base/java.nio=ALL-UNNAMED', '-XX:ActiveProcessorCount=6',
                           '-Xmx4g', '-Xms2g', '-Dsirix.offheap.bytes=1073741824',
                           '-Djava.io.tmpdir=' + str(BASE / 'tmp'), '-Duser.home=' + str(BASE / 'home'),
                           '-cp', str(classes) + ':' + ':'.join(jars),
                           'io.sirix.index.projection.ProjectionLocatorProbe',
                           db / 'jsonbench', 'bluesky.jn', '0', mode, '3']
                paired.run(command, stem)
                lines = [line for line in stem.with_suffix('.stdout').read_text().splitlines()
                         if line.startswith('LOCATOR_PROBE ')]
                if len(lines) != 1:
                    raise RuntimeError('missing or ambiguous probe result: ' + str(stem))
                record = json.loads(lines[0].removeprefix('LOCATOR_PROBE '))
                assert record['exact_reference_match'] and record['ranked'] is False
                if expected_hash is None:
                    expected_hash = record['selected_inventory_sha256']
                assert record['selected_inventory_sha256'] == expected_hash
                record.update(round=round_id, attempt=attempt, tier='1m', runtime='JVM/C2',
                              ranked=False, command_manifest=str(stem.with_suffix('.command.json')))
                records.append(record)
                (out / 'attempts.json').write_text(json.dumps(records, indent=2) + '\n')
                print(f'{mode} r{round_id} a{attempt}: exact; capture={record["capture_seconds"]:.6f}s; '
                      f'slots={record["captured_slots"]}; values={record["captured_value_bytes"]}', flush=True)

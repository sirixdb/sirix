#!/usr/bin/env bash
set -euo pipefail
campaign_dir='/home/johannes/.treehouse/sirix-cdde48/1/sirix/build/jsonbench-campaign'
export JAVA_HOME="$campaign_dir/graal-25i4"
export PATH="$JAVA_HOME/bin:$PATH"
export GRADLE_USER_HOME="$campaign_dir/gradle-home"
export TMPDIR="$campaign_dir/tmp"
export GRADLE="$GRADLE_USER_HOME/wrapper/dists/gradle-9.7.1-bin/1w1c7tv4s851m17nbqdsro2tv/gradle-9.7.1/bin/gradle"
export GRADLE_FLAGS="--offline --no-daemon --no-build-cache --rerun-tasks --max-workers=4 --init-script=$campaign_dir/evidence/build-limits.gradle -Dorg.gradle.jvmargs=-Xmx2g"
export JAVA_TOOL_OPTIONS="-XX:ActiveProcessorCount=6 -Djava.io.tmpdir=$campaign_dir/tmp -Duser.home=$campaign_dir/home"
unset _JAVA_OPTIONS JDK_JAVA_OPTIONS
export BUILDER_XMX=12g
case "${1:?stage required}" in
    format)
        "$GRADLE" $GRADLE_FLAGS --init-script="$campaign_dir/evidence/directory-batch-validation.gradle" \
            -p "$campaign_dir/../.." :sirix-core:spotlessJavaApply
        ;;
    test)
        "$GRADLE" $GRADLE_FLAGS -p "$campaign_dir/source-directory-batch-v1" \
            :sirix-core:test --tests io.sirix.index.projection.ProjectionDirectoryBatchCaptureTest \
            --tests io.sirix.index.projection.ProjectionParallelDirectoryWalkTest \
            --tests io.sirix.index.projection.ProjectionSideReferenceVersioningMatrixTest \
            --tests io.sirix.index.projection.ProjectionCommittedSlotCorruptionTest \
            --tests io.sirix.index.hot.HOTLeafUseAfterCloseTest \
            --tests io.sirix.page.HOTLeafPageFrameOwnershipTest \
            :sirix-query:test --tests io.sirix.query.JsonBenchShapeServingTest
        ;;
    instrument)
        test ! -e "$campaign_dir/pgo-directory-batch-100m"
        bash "$campaign_dir/source-directory-batch-v1/bundles/sirix-query/bench/jsonbench/pgo-native.sh" \
            "$campaign_dir/db-1m-retention-repaired" --tier 100m --out "$campaign_dir/pgo-directory-batch-100m" --steps 1
        ;;
    optimize)
        test ! -e "$campaign_dir/pgo-directory-batch-100m/jb"
        bash "$campaign_dir/source-directory-batch-v1/bundles/sirix-query/bench/jsonbench/pgo-native.sh" \
            "$campaign_dir/db-100m-retention" --tier 100m --out "$campaign_dir/pgo-directory-batch-100m" --steps 3
        ;;
    *) printf '%s\n' 'unknown stage' >&2; exit 2 ;;
esac

"""Sequential guarded serial-directory campaign; preserves every attempt and checks inbox gates."""
import json
from pathlib import Path
import subprocess
import time

from campaign_100m import BASE, EVIDENCE

INBOX = Path('/home/johannes/IdeaProjects/firstmate/state/sirix-cb-top10.inbox')


def require_pass(name):
    path = EVIDENCE / (name + '.verdict.json')
    if not path.is_file():
        raise RuntimeError('missing completed prerequisite: ' + name)
    verdict = json.loads(path.read_text())
    if verdict['exit_code'] or verdict['failures']:
        raise RuntimeError('phase guard failed: ' + name)


def phase(name, command):
    while list(INBOX.glob('*.msg')):
        print('Waiting for active agent to handle Firstmate inbox before next phase', flush=True)
        time.sleep(5)
    prefix = EVIDENCE / name
    if any(prefix.with_suffix(suffix).exists() for suffix in ('.verdict.json', '.log', '.telemetry.jsonl')):
        raise RuntimeError('refusing to overwrite phase evidence: ' + name)
    print('START ' + name, flush=True)
    subprocess.run(['python3', str(EVIDENCE / 'guard-100m-storage.py'), '--prefix', str(prefix), '--',
                    'systemd-run', '--user', '--scope', '--quiet', '--collect', '--unit=jsonbench-' + name,
                    '--property=MemoryMax=24G', '--property=MemorySwapMax=0',
                    'python3', str(EVIDENCE / 'scope-exec-100m.py'), str(prefix), *map(str, command)], check=True)
    require_pass(name)
    print('PASS ' + name, flush=True)


require_pass('audit-serial-directory-paired-100m-attempt1')
phase('audit-serial-directory-instrument-1m-attempt1', ['python3', EVIDENCE / 'audit-serial-directory-instrument-1m.py'])
phase('diagnose-serial-directory-100m-attempt1',
      ['python3', EVIDENCE / 'diagnose-serial-directory-100m.py',
       '--manifest', EVIDENCE / 'serial-directory-optimized-100m-runtime-manifest.json',
       '--source-manifest', EVIDENCE / 'serial-directory-v2-source.json',
       '--out', BASE / 'diagnose-serial-directory-100m-attempt1'])

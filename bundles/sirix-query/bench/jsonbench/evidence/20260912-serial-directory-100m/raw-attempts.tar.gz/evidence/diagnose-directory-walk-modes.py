"""Bounded native attribution for the existing serial/parallel directory switch; guard required."""
import importlib.util
import json
from pathlib import Path

from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
manifest = json.loads((EVIDENCE / 'lz77-optimized-100m-runtime-manifest.json').read_text())
binary = Path(manifest['binary'])
assert digest(binary) == manifest['binary_sha256']
out = BASE / 'diagnose-directory-walk-modes-attempt1'
out.mkdir(exist_ok=False)
records = []
for tier in ('1m', '100m'):
    db = BASE / ('db-1m-retention-repaired' if tier == '1m' else 'db-100m-retention')
    flags = [] if tier == '1m' else ['-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
                                   '-Dsirix.projection.promoteMaxBytes=0']
    for query in (1, 4):
        for mode in (('parallel', 'serial') if query == 1 else ('serial', 'parallel')):
            paired.cool()
            paired.cold_cache(db, out / f'{tier}-q{query}-{mode}-eviction.json')
            stem = out / f'{tier}-q{query}-{mode}'
            dump = out / f'{tier}-q{query}-{mode}-dump'
            paired.run([binary, db, '--queries', query, '--tries', 1, '--dump', dump,
                        '-Dsirix.projection.parallelWalk=' + ('true' if mode == 'parallel' else 'false'),
                        '-Dsirix.projDiag=true', '-Dsirix.projection.fillDiag=true', '-Dsirix.lz77Codec.diag=true',
                        '-Djava.io.tmpdir=' + str(BASE / 'tmp'), *flags], stem)
            definition = paired.compare.SPECS[query]
            failures = paired.compare.compare(definition,
                paired.compare.read_dump(dump / f'q{query}.jsonl', definition),
                paired.compare.read_reference(BASE / f'ch26/ch-ref-{tier}/q{query}.tsv', definition), False)
            (out / f'{tier}-q{query}-{mode}-differential.json').write_text(json.dumps(failures) + '\n')
            if failures:
                raise RuntimeError('directory-mode diagnostic differential mismatch')
            log = stem.with_suffix('.stderr').read_text()
            stdout = stem.with_suffix('.stdout').read_text()
            if 'NATIVE_DECODER_ENABLED=true' not in log + stdout:
                raise RuntimeError('native decoder was not confirmed')
            engaged = '[parwalk] ENGAGED' in log
            if mode == 'serial' and engaged:
                raise RuntimeError('serial toggle did not select the intended path')
            if tier == '100m' and mode == 'parallel' and not engaged:
                raise RuntimeError('full-tier parallel arm did not engage')
            phases = [line for line in log.splitlines() if 'lazy-handle timings:' in line]
            if len(phases) != 1:
                raise RuntimeError('missing directory timing')
            records.append(dict(tier=tier, query=query, mode=mode, exact=True, ranked=False,
                                parallel_engaged=engaged, routes=paired.routes(stem),
                                phase_line=phases[0], binary_sha256=manifest['binary_sha256']))
            (out / 'manifest.json').write_text(json.dumps(records, indent=2) + '\n')
            print(f'{tier} Q{query} {mode}: exact; {phases[0]}', flush=True)

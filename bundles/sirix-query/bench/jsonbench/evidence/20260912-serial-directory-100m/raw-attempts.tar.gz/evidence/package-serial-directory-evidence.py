"""Retain accepted serial traversal, rejected batching, and the attribution experiments."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile
from campaign_100m import BASE, EVIDENCE, digest

root = BASE.parents[1]
destination = root / 'bundles/sirix-query/bench/jsonbench/evidence/20260912-serial-directory-100m'
destination.mkdir(exist_ok=False)
directories = [BASE / name for name in (
    'paired-lz77-100m-attempt1', 'paired-serial-directory-100m-attempt1',
    'paired-serial-directory-instrument-1m-attempt1', 'training-serial-directory-100m-attempt1',
    'diagnose-serial-directory-100m-attempt1', 'paired-directory-batch-100m-attempt1',
    'paired-directory-batch-instrument-1m-attempt1', 'training-directory-batch-100m-attempt1',
    'diagnose-directory-batch-attempt1', 'diagnose-directory-walk-modes-attempt1',
    'locator-probe-v2-1m-attempt1', 'locator-probe-v2-100m-attempt1',
    'directory-hot-instructions-attempt2')]
files = set()
for directory in directories:
    assert directory.is_dir(), directory
    files.update(path for path in directory.rglob('*') if path.is_file())
prefixes = ('serial-directory-', 'directory-batch-', 'indexdef-', 'locator-probe-',
            'diagnose-directory-', 'directory-hot-', 'directory-disassembly-',
            'upstream-recheck-serial-directory-', 'paired-directory-batch-',
            'training-directory-batch-', 'test-directory-batch-', 'format-directory-batch-',
            'freeze-directory-batch-', 'instrument-directory-batch-', 'optimize-directory-batch-',
            'check-directory-batch-', 'train-directory-batch-', 'freeze-instrument-directory-batch-',
            'freeze-optimized-directory-batch-', 'audit-directory-batch-',
            'paired-serial-directory-', 'training-serial-directory-', 'test-serial-directory-',
            'format-serial-directory-', 'freeze-serial-directory-', 'instrument-serial-directory-',
            'optimize-serial-directory-', 'check-serial-directory-', 'train-serial-directory-',
            'freeze-instrument-serial-directory-', 'freeze-optimized-serial-directory-',
            'audit-serial-directory-', 'diagnose-serial-directory-')
for path in EVIDENCE.iterdir():
    if path.name.startswith(prefixes):
        if path.is_dir():
            files.update(child for child in path.rglob('*') if child.is_file() and '__pycache__' not in child.parts)
        elif path.is_file():
            files.add(path)
names = ('guard-100m-storage.py', 'scope-exec-100m.py', 'prior_thermal_guard.py', 'campaign_100m.py',
         'freeze-runtime.py', 'freeze-candidate-source.py', 'paired-retention-100m.py',
         'build-limits.gradle', 'diagnose_native_100m.py', 'advance-serial-directory-100m.py',
         'post-serial-directory-validation.py', 'package-serial-directory-evidence.py',
         'advance-directory-batch-100m.py', 'resume-directory-batch-100m.py',
         'lz77-optimized-100m-runtime-manifest.json', 'lz77-instrument-100m-runtime-manifest.json',
         'native-lz77-v1-source.json', 'paired-lz77-100m-attempt1-validation.json',
         'upstream-pin.json', 'retention-import-100m-completion.json',
         'reopened-rowcount-retention-100m.count.json', 'corpus-100m-manifest.json',
         'clean-corpus-100m-manifest.json', 'compressed-corpus-100m-manifest.json')
for name in names:
    path = EVIDENCE / name
    assert path.is_file(), path
    files.add(path)
for label in ('serial-directory', 'directory-batch'):
    for name in ('jb', 'jb-instr', 'jsonbench-100m.iprof'):
        files.add(BASE / ('pgo-' + label + '-100m') / name)
for label in ('serial-directory-v1', 'serial-directory-v2', 'directory-batch-v1'):
    files.add(BASE / ('source-' + label + '.tar.gz'))
large, small = [], []
for path in sorted(files):
    assert path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(BASE), path
    if path.suffix in ('.iprof', '.data', '.jfr', '.debug') or path.stat().st_size > 16 * 1024 * 1024:
        large.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
    else:
        small.append(path)
(destination / 'retained-large-files.json').write_text(json.dumps(large, indent=2) + '\n')
archive = destination / 'raw-attempts.tar.gz'
members = []
with archive.open('xb') as target, gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as stream:
        for path in small:
            relative = str(path.relative_to(BASE))
            stream.add(path, arcname=relative, recursive=False)
            members.append(dict(path=relative, bytes=path.stat().st_size, sha256=digest(path)))
with tarfile.open(archive) as stream:
    actual = {member.name: hashlib.sha256(stream.extractfile(member).read()).hexdigest()
              for member in stream.getmembers()}
assert actual == {row['path']: row['sha256'] for row in members}
record = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), files=members)
(destination / 'raw-files.json').write_text(json.dumps(record, indent=2) + '\n')
for name in ('upstream-pin.json', 'serial-directory-v2-source.json', 'serial-directory-v2-tests.json',
             'paired-serial-directory-100m-attempt1-validation.json', 'serial-directory-instrument-1m-validation.json',
             'paired-directory-batch-100m-attempt1-validation.json', 'directory-batch-v1-decision.json',
             'indexdef-trie-directory-explanation.md', 'serial-directory-v2-decision.json'):
    shutil.copy2(EVIDENCE / name, destination / name)
print(json.dumps(dict(archive=str(archive), members=len(members), bytes=record['bytes'],
                     sha256=record['sha256'], retained_large_files=len(large))))

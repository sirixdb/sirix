"""Sequential guarded directory-batch campaign; preserves every attempt and checks inbox gates."""
import json
from pathlib import Path
import subprocess
import time

from campaign_100m import BASE, EVIDENCE

INBOX = Path('/home/johannes/IdeaProjects/firstmate/state/sirix-cb-top10.inbox')


def require_pass(name):
    path = EVIDENCE / (name + '.verdict.json')
    if not path.is_file():
        raise RuntimeError('missing completed prerequisite: ' + name)
    verdict = json.loads(path.read_text())
    if verdict['exit_code'] or verdict['failures']:
        raise RuntimeError('phase guard failed: ' + name)


def phase(name, command):
    while list(INBOX.glob('*.msg')):
        print('Waiting for active agent to handle Firstmate inbox before next phase', flush=True)
        time.sleep(5)
    prefix = EVIDENCE / name
    if any(prefix.with_suffix(suffix).exists() for suffix in ('.verdict.json', '.log', '.telemetry.jsonl')):
        raise RuntimeError('refusing to overwrite phase evidence: ' + name)
    print('START ' + name, flush=True)
    subprocess.run(['python3', str(EVIDENCE / 'guard-100m-storage.py'), '--prefix', str(prefix), '--',
                    'systemd-run', '--user', '--scope', '--quiet', '--collect', '--unit=jsonbench-' + name,
                    '--property=MemoryMax=24G', '--property=MemorySwapMax=0',
                    'python3', str(EVIDENCE / 'scope-exec-100m.py'), str(prefix), *map(str, command)], check=True)
    require_pass(name)
    print('PASS ' + name, flush=True)


for prerequisite in ('freeze-directory-batch-v1', 'test-directory-batch-v1',
                     'freeze-instrument-directory-batch-100m', 'check-directory-batch-instrument-1m-attempt1',
                     'diagnose-directory-batch-attempt1'):
    require_pass(prerequisite)
print('Assessment recorded in directory-batch-steering-assessment.md; optimized full-tier experiment remains unaccepted.', flush=True)

phase('train-directory-batch-100m-attempt1', ['python3', EVIDENCE / 'train-directory-batch-100m.py'])
phase('optimize-directory-batch-100m-attempt1', ['bash', EVIDENCE / 'directory-batch-lane.sh', 'optimize'])
phase('freeze-optimized-directory-batch-100m',
      ['python3', EVIDENCE / 'freeze-runtime.py', '--label', 'directory-batch-optimized-100m',
       '--log', EVIDENCE / 'optimize-directory-batch-100m-attempt1.log',
       '--binary', BASE / 'pgo-directory-batch-100m/jb',
       '--profile', BASE / 'pgo-directory-batch-100m/jsonbench-100m.iprof', '--jdk', BASE / 'graal-25i4'])
phase('paired-directory-batch-100m-attempt1',
      ['python3', EVIDENCE / 'paired-retention-100m.py', '--tier', '100m',
       '--sirix', BASE / 'pgo-directory-batch-100m/jb', '--db', BASE / 'db-100m-retention',
       '--ch-db', BASE / 'ch26/ch-data-100m', '--rows', '99999968', '--tries', '3', '--rounds', '2',
       '--out', BASE / 'paired-directory-batch-100m-attempt1'])
print('Directory-batch paired evidence complete; audit exact answers, routes, cache and guard verdicts, then assess rank.', flush=True)

# Negative instrumented gate: bounded continuation decision

The 1M instrumented comparison passed correctness, routes and guard but regressed
in both rounds: hot after/before1.2594513363 and1.2385279194. Those attempts remain
unaltered. The advance driver stopped before training, as intended.

A separate, unranked Q1 phase diagnostic then checked exact answers at1M and100M
for both instruments under a clean guard (106 samples). At100M, before/after
directory times were18,889.1/17,302.3ms; at1M353.1/277.9ms. The intended directory
mechanism therefore has a signal worth checking in the actual optimized runtime.
This is only one diagnostic observation per size/arm. Other costs, especially
column-body fetch/decode, varied heavily; whole-query differences cannot be
attributed to batching or treated as a ranking improvement.

Worker decision within the authorized campaign: evaluate one fresh full100M PGO
instrument/train/optimize cycle and paired all-five-query comparison, retaining
this negative steering evidence. The existing instrumented build is fresh and
validated; it does not need duplication. Use a new full-tier profile over all
queries, never the diagnostic Q1 profile. Accept the source change only after
exact full-tier answers, unchanged routes, clean guards/cache evidence and a
recomputed paired improvement over the committed native LZ77 build. Otherwise
retain failed evidence and reject or revise this candidate. This is no success
claim, protocol change, prepass, reimport or permission escalation.

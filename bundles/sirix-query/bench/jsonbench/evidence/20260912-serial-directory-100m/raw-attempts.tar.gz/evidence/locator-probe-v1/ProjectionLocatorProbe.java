package io.sirix.index.projection;

import com.google.gson.JsonObject;
import io.sirix.access.Databases;
import io.sirix.access.trx.page.HOTRangeCursor;
import io.sirix.access.trx.page.HOTTrieReader;
import io.sirix.api.Database;
import io.sirix.api.StorageEngineReader;
import io.sirix.api.json.JsonNodeReadOnlyTrx;
import io.sirix.api.json.JsonResourceSession;
import io.sirix.cache.Allocators;
import io.sirix.index.IndexDef;
import io.sirix.index.hot.PathKeySerializer;
import io.sirix.node.LE;
import io.sirix.page.HOTLeafPage;
import io.sirix.page.PageReference;
import io.sirix.settings.Constants;
import java.lang.foreign.MemorySegment;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.List;
import java.util.Objects;

/**
 * Unranked, read-only slot-capture experiment. No production code uses this class.
 * Both arms use the same serial range/stamp protocol. The selected arm avoids touching
 * unrequested slot values; the all arm captures them. This is NOT a whole-query benchmark
 * or a substitute for the parallel production directory reader.
 */
public final class ProjectionLocatorProbe {
  private static final int BLOB_MAGIC = 0x42584950;
  private static final int BLOB_HEADER = 17;

  private ProjectionLocatorProbe() {}

  public static void main(final String[] args) throws Exception {
    if (args.length != 5) {
      throw new IllegalArgumentException("database resource index-id all|selected column-indices-csv");
    }
    final int indexId = Integer.parseInt(args[2]);
    final boolean all = switch (args[3]) {
      case "all" -> true;
      case "selected" -> false;
      default -> throw new IllegalArgumentException("unknown mode: " + args[3]);
    };
    final int[] columns = Arrays.stream(args[4].split(",")).mapToInt(Integer::parseInt).sorted().distinct().toArray();
    if (columns.length == 0 || columns[0] < 0) {
      throw new IllegalArgumentException("at least one nonnegative column is required");
    }
    Allocators.getInstance().init(Long.getLong("sirix.offheap.bytes", 1L << 30));
    try (Database<JsonResourceSession> database = Databases.openJsonDatabase(Path.of(args[0]));
        JsonResourceSession session = database.beginResourceSession(args[1])) {
      final int revision = session.getMostRecentRevisionNumber();
      final IndexDef definition = session.getRtxIndexController(revision).getIndexes().getIndexDefs().stream()
          .filter(def -> def.getID() == indexId && def.isProjectionIndex()).findFirst().orElseThrow();
      if (columns[columns.length - 1] >= definition.getProjectionFields().size()) {
        throw new IllegalArgumentException("column outside selected IndexDef");
      }
      try (JsonNodeReadOnlyTrx trx = session.beginNodeReadOnlyTrx(revision)) {
        final StorageEngineReader reader = trx.getStorageEngineReader();
        final ProjectionIndexMetadata metadata = Objects.requireNonNull(
            ProjectionIndexMetadata.parse(ProjectionIndexHOTStorage.readBlob(reader, indexId, 0)));
        if (metadata.isStale()) {
          throw new IllegalStateException("stale projection");
        }
        final int[] physical = ProjectionIndexFences.readPhysicalOrder(reader, indexId, metadata.rowGroupCount());
        final long started = System.nanoTime();
        final Inventory inventory = capture(reader, indexId, columns, all);
        final long elapsed = System.nanoTime() - started;

        // Validation is deliberately outside the capture timer. It reads the authoritative
        // production representation and compares exact content/locations, not only checksums.
        final List<ProjectionIndexHOTStorage.RowGroupDirectory> reference = Objects.requireNonNull(
            ProjectionIndexHOTStorage.readAllRowGroupDirectoriesFromColumnSegmentSlots(reader, indexId,
                metadata.rowGroupCount(), physical));
        final String selectedHash = validate(reader, inventory, reference, columns, all);
        final JsonObject result = new JsonObject();
        result.addProperty("mode", args[3]);
        result.addProperty("ranked", false);
        result.addProperty("runtime", "JVM-or-native: see command manifest");
        result.addProperty("revision", revision);
        result.addProperty("index_id", indexId);
        result.addProperty("row_groups", reference.size());
        result.addProperty("capture_seconds", elapsed / 1e9);
        result.addProperty("visited_slots", inventory.visited);
        result.addProperty("leaf_object_transitions", inventory.leafTransitions);
        result.addProperty("captured_slots", inventory.count);
        result.addProperty("captured_value_bytes", inventory.bytes);
        result.addProperty("referenced_slots", inventory.references);
        result.addProperty("exact_reference_match", true);
        result.addProperty("selected_inventory_sha256", selectedHash);
        System.out.println("LOCATOR_PROBE " + result);
      }
    }
  }

  private static boolean include(final long key, final int[] columns, final boolean all) {
    if (key < (1L << 16) || key >= ProjectionIndexFences.CHUNK_SLOT_BASE) {
      return false;
    }
    final int kind = (int) (key & 0xffffL);
    return all || kind == 0
        || Arrays.binarySearch(columns, ProjectionIndexColumnSegmentCodec.columnOfColumnSegment(kind - 1)) >= 0;
  }

  private static Inventory capture(final StorageEngineReader reader, final int indexId, final int[] columns,
      final boolean all) {
    final Inventory out = new Inventory();
    final PageReference root = Objects.requireNonNull(ProjectionIndexHOTStorage.rootReference(reader, indexId));
    final byte[] from = new byte[Long.BYTES];
    final byte[] to = new byte[Long.BYTES];
    PathKeySerializer.INSTANCE.serialize(1L << 16, from, 0);
    PathKeySerializer.INSTANCE.serialize(((long) ProjectionIndexHOTStorage.MAX_ROW_GROUPS << 16) | 0xffffL, to, 0);
    HOTLeafPage previous = null;
    try (HOTTrieReader trie = new HOTTrieReader(reader); HOTRangeCursor cursor = trie.range(root, from, to)) {
      int torn = 0;
      while (cursor.hasNext()) {
        final HOTLeafPage leaf = cursor.currentLeafPage();
        final int index = cursor.currentEntryIndex();
        long key = 0;
        long offset = Constants.NULL_ID_LONG;
        byte[] value = null;
        RuntimeException failure = null;
        try {
          key = leaf.decodeKey8BE(index) ^ Long.MIN_VALUE;
          if (include(key, columns, all)) {
            final long valueRef = leaf.valueRef(index);
            final int length = HOTLeafPage.refLength(valueRef);
            if (length > leaf.slotCapacity()) {
              throw new IllegalStateException("slot value exceeds leaf capacity");
            }
            if (length > 0) {
              value = leaf.copyStoredValue(index);
              final boolean referenced;
              if ((key & 0xffffL) == 0) {
                if (value.length < BLOB_HEADER || littleInt(value, 0) != BLOB_MAGIC || value[4] != 0) {
                  throw new IllegalStateException("invalid descriptor marker");
                }
                referenced = littleInt(value, 5) >= 0;
              } else {
                if (value[0] != 0 && value[0] != 1) {
                  throw new IllegalStateException("invalid segment discriminator");
                }
                referenced = value[0] == 1;
              }
              if (referenced) {
                final PageReference ref = leaf.getPageReference(HOTLeafPage.overflowPageRefKey(key, 0));
                if (ref == null || ref.getKey() < 0) {
                  throw new IllegalStateException("missing durable side reference");
                }
                offset = ref.getKey();
              }
            }
          }
        } catch (final RuntimeException problem) {
          failure = problem;
        }
        if (!cursor.validateLeaf()) {
          cursor.recoverTorn(++torn, "selected locator probe");
          continue;
        }
        if (failure != null) {
          throw failure;
        }
        torn = 0;
        out.visited++;
        if (previous != leaf) {
          out.leafTransitions++;
          previous = leaf;
        }
        if (value != null && value.length > 0) {
          out.add(key, offset, value);
        }
        cursor.advance();
      }
    }
    return out;
  }

  private static String validate(final StorageEngineReader reader, final Inventory actual,
      final List<ProjectionIndexHOTStorage.RowGroupDirectory> expected, final int[] columns, final boolean all)
      throws Exception {
    final int maximum = expected.stream().mapToInt(dir -> Math.toIntExact(dir.rowGroupId())).max().orElse(0);
    final int[] logical = new int[maximum + 1];
    Arrays.fill(logical, -1);
    long expectedCount = 0;
    for (int row = 0; row < expected.size(); row++) {
      final ProjectionIndexHOTStorage.RowGroupDirectory dir = expected.get(row);
      logical[Math.toIntExact(dir.rowGroupId())] = row;
      expectedCount++;
      for (final int segment : dir.columnSegmentIds()) {
        if (include((dir.rowGroupId() << 16) | (segment + 1), columns, all)) {
          expectedCount++;
        }
      }
    }
    require(expectedCount == actual.count, "missing or extra captured slots");
    final long[] sorted = Arrays.copyOf(actual.keys, actual.count);
    Arrays.sort(sorted);
    for (int i = 1; i < sorted.length; i++) {
      require(sorted[i - 1] != sorted[i], "duplicate captured slot");
    }
    final MessageDigest digest = MessageDigest.getInstance("SHA-256");
    final byte[] number = new byte[Long.BYTES];
    for (int i = 0; i < actual.count; i++) {
      final long key = actual.keys[i];
      final int physical = Math.toIntExact(key >>> 16);
      require(physical < logical.length && logical[physical] >= 0, "unknown physical row group");
      final ProjectionIndexHOTStorage.RowGroupDirectory dir = expected.get(logical[physical]);
      final byte[] value = actual.values[i];
      final long offset = actual.offsets[i];
      final int kind = (int) (key & 0xffffL);
      if (kind == 0) {
        final int encoded = littleInt(value, 5);
        final byte[] descriptor = encoded < 0 ? Arrays.copyOfRange(value, BLOB_HEADER, value.length)
            : ProjectionIndexHOTStorage.readSegmentBytesAtOffset(reader, offset);
        require(descriptor != null && descriptor.length == (encoded & Integer.MAX_VALUE), "descriptor length");
        require(ProjectionIndexColumnSegmentCodec.contentHash(descriptor) == littleLong(value, 9), "descriptor hash");
        require(Arrays.equals(dir.descriptor(), descriptor), "descriptor content");
      } else {
        final int entry = RowGroupDescriptor.entryIndexOf(dir.descriptor(), kind - 1);
        require(entry >= 0, "undeclared segment");
        if (value[0] == 0) {
          require(Arrays.equals(Arrays.copyOfRange(value, 1, value.length), dir.inlineBytesAt(entry)), "inline bytes");
          require(offset == Constants.NULL_ID_LONG, "inline offset");
        } else {
          require(value.length == 1 && dir.inlineBytesAt(entry) == null, "reference representation");
          require(offset == dir.columnSegmentOffsets()[entry], "durable offset");
        }
      }
      if (include(key, columns, false)) {
        MemorySegment.ofArray(number).set(LE.LONG, 0, key);
        digest.update(number);
        MemorySegment.ofArray(number).set(LE.LONG, 0, offset);
        digest.update(number);
        digest.update(value);
      }
    }
    return HexFormat.of().formatHex(digest.digest());
  }

  private static int littleInt(final byte[] bytes, final int offset) {
    return MemorySegment.ofArray(bytes).get(LE.INT, offset);
  }

  private static long littleLong(final byte[] bytes, final int offset) {
    return MemorySegment.ofArray(bytes).get(LE.LONG, offset);
  }

  private static void require(final boolean condition, final String message) {
    if (!condition) {
      throw new IllegalStateException(message);
    }
  }

  private static final class Inventory {
    private long[] keys = new long[4096];
    private long[] offsets = new long[4096];
    private byte[][] values = new byte[4096][];
    private int count;
    private long visited;
    private long leafTransitions;
    private long bytes;
    private long references;

    private void add(final long key, final long offset, final byte[] value) {
      if (count == keys.length) {
        final int grown = Math.multiplyExact(count, 2);
        keys = Arrays.copyOf(keys, grown);
        offsets = Arrays.copyOf(offsets, grown);
        values = Arrays.copyOf(values, grown);
      }
      keys[count] = key;
      offsets[count] = offset;
      values[count++] = value;
      bytes += value.length;
      if (offset >= 0) {
        references++;
      }
    }
  }
}

"""Bounded phase attribution after negative instrumented steering; guard required."""
import importlib.util
import json
from pathlib import Path
from campaign_100m import BASE, EVIDENCE, digest

spec = importlib.util.spec_from_file_location('paired', EVIDENCE / 'paired-retention-100m.py')
paired = importlib.util.module_from_spec(spec)
spec.loader.exec_module(paired)
out = BASE / 'diagnose-directory-batch-attempt1'
out.mkdir(exist_ok=False)
records = []
for tier in ('1m', '100m'):
    db = BASE / ('db-1m-retention-repaired' if tier == '1m' else 'db-100m-retention')
    variants = [('before', 'lz77-instrument-100m'), ('after', 'directory-batch-instrument-100m')]
    if tier == '100m':
        variants.reverse()
    for variant, label in variants:
        manifest = json.loads((EVIDENCE / (label + '-runtime-manifest.json')).read_text())
        binary = Path(manifest['binary'])
        assert digest(binary) == manifest['binary_sha256']
        paired.cool()
        paired.cold_cache(db, out / f'{tier}-{variant}-eviction.json')
        stem = out / f'{tier}-{variant}'
        dump = out / f'{tier}-{variant}-dump'
        flags = [] if tier == '1m' else ['-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
                                       '-Dsirix.projection.promoteMaxBytes=0']
        paired.run([binary, db, '--queries', 1, '--tries', 1, '--dump', dump,
                    '-XX:ProfilesDumpFile=' + str(stem.with_suffix('.iprof')),
                    '-Dsirix.projDiag=true', '-Dsirix.projection.fillDiag=true', '-Dsirix.lz77Codec.diag=true',
                    '-Djava.io.tmpdir=' + str(BASE / 'tmp'), *flags], stem)
        definition = paired.compare.SPECS[1]
        failures = paired.compare.compare(definition,
            paired.compare.read_dump(dump / 'q1.jsonl', definition),
            paired.compare.read_reference(BASE / f'ch26/ch-ref-{tier}/q1.tsv', definition), False)
        (out / f'{tier}-{variant}-differential.json').write_text(json.dumps(failures) + '\n')
        if failures:
            raise RuntimeError('diagnostic differential failed')
        record = dict(tier=tier, variant=variant, exact=True, ranked=False,
                      binary_sha256=manifest['binary_sha256'], routes=paired.routes(stem))
        records.append(record)
        (out / 'manifest.json').write_text(json.dumps(records, indent=2) + '\n')
        print(f'{tier} {variant} Q1 exact; diagnostic only', flush=True)

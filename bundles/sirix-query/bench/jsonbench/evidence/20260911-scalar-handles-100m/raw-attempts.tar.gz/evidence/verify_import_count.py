"""Reopen a completed store and verify its persisted root-array count, outside query timing."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import time

from campaign_100m import BASE, EVIDENCE, digest


def verify(database_root, expected, prefix):
    if prefix.with_suffix('.count.json').exists():
        raise RuntimeError('Refusing to overwrite retained row-count evidence')
    runtime = json.loads((EVIDENCE / 'retention-instrument-100m-runtime-manifest.json').read_text())
    classpath = []
    for entry in runtime['classpath']:
        if digest(entry['retained']) != entry['sha256']:
            raise RuntimeError('Runtime dependency changed: ' + entry['retained'])
        classpath.append(entry['retained'])
    jdk = BASE / 'graal-25i4'
    for relative, expected_hash in runtime['runtime_hashes'].items():
        if digest(jdk / relative) != expected_hash:
            raise RuntimeError('Runtime changed: ' + relative)
    helper = EVIDENCE / 'VerifyRootArrayCount.java'
    command = [str(jdk / 'bin/java'), '--enable-preview', '--source', '25',
               '--add-modules', 'jdk.incubator.vector',
               '--enable-native-access=ALL-UNNAMED', '--add-opens', 'java.base/sun.nio.ch=ALL-UNNAMED',
               '--add-opens', 'java.base/java.nio=ALL-UNNAMED', '-Xmx512m', '-XX:ActiveProcessorCount=2',
               '-Djava.io.tmpdir=' + str(BASE / 'tmp'), '-Duser.home=' + str(BASE / 'home'),
               '--class-path', ':'.join(classpath), str(helper), str(database_root / 'jsonbench'),
               'bluesky.jn', str(expected)]
    environment = dict(os.environ)
    for name in ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS']:
        environment.pop(name, None)
    record = dict(command=command, helper_sha256=digest(helper), started=time.time(), ranked=False)
    with prefix.with_suffix('.stdout').open('x') as stdout, prefix.with_suffix('.stderr').open('x') as stderr:
        process = subprocess.run(command, env=environment, stdout=stdout, stderr=stderr)
    record['finished'] = time.time()
    record['exit_code'] = process.returncode
    prefix.with_suffix('.command.json').write_text(json.dumps(record, indent=2) + '\n')
    if process.returncode:
        raise RuntimeError('Reopened logical row-count check failed: ' + str(prefix))
    marker = '# verified-row-count '
    lines = [line[len(marker):] for line in prefix.with_suffix('.stdout').read_text().splitlines()
             if line.startswith(marker)]
    if len(lines) != 1:
        raise RuntimeError('Missing or ambiguous authoritative row count')
    count = json.loads(lines[0])
    if count['persisted_child_count'] != expected or not count['exact']:
        raise RuntimeError('Unexpected persisted row count: ' + str(count))
    count['ranked'] = False
    prefix.with_suffix('.count.json').write_text(json.dumps(count, indent=2) + '\n')
    print('Reopened root array: exact ' + str(expected) + ' logical input rows', flush=True)
    return count


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--expected', type=int, required=True)
    parser.add_argument('--prefix', type=Path, required=True)
    args = parser.parse_args()
    verify(args.db, args.expected, args.prefix)

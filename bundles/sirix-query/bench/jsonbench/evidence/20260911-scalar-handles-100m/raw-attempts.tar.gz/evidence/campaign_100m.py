import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
EVIDENCE = BASE / 'evidence'


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def corpus():
    verdict = json.loads((EVIDENCE / 'activate-compressed-corpus-100m-attempt1.verdict.json').read_text())
    if verdict['exit_code'] != 0 or verdict['failures']:
        raise RuntimeError('compressed input activation guard did not pass')
    manifest = json.loads((EVIDENCE / 'active-corpus-100m.json').read_text())
    path = Path(manifest['file'])
    if manifest['rows'] != 99_999_968 or manifest['dropped'] != 32:
        raise RuntimeError('wrong canonical row counts')
    if path.stat().st_size != manifest['physical_bytes'] or digest(path) != manifest['physical_sha256']:
        raise RuntimeError('clean corpus differs from its manifest')
    return path, manifest

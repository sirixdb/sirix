#!/usr/bin/env python3
"""Campaign-only supervisor; reused sensor contract from the accepted 1M gate."""
import argparse
import ctypes
import json
import os
from pathlib import Path
import signal
import shutil
import select
import subprocess
import threading
import time

from prior_thermal_guard import INTERVAL, MAX_SAMPLE_GAP, MAX_TEMP_C
from prior_thermal_guard import package_sensors, snapshot


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prefix', required=True, type=Path)
    parser.add_argument('--min-available-mib', type=int, default=2048)
    parser.add_argument('--min-free-gib', type=int, default=20)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if len(args.command) < 2 or args.command[0] != '--':
        parser.error('command must follow --')
    if args.min_available_mib < 2048:
        parser.error('available-memory floor must be at least 2048 MiB')
    min_available_bytes = args.min_available_mib * 1024 * 1024
    if args.min_free_gib < 20:
        parser.error('disk floor must be at least 20 GiB')
    min_disk_free_bytes = args.min_free_gib * 1024 ** 3
    prefix = args.prefix.resolve()
    prefix.parent.mkdir(parents=True, exist_ok=True)
    failures = []
    process = None
    start = None
    latest = None
    rows = 0
    last_sample = time.monotonic()
    stop = threading.Event()
    owned = {}
    owners = {}
    exited = select.poll()
    # Adopt double-forked descendants, including single-use Gradle daemons.
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        raise OSError(ctypes.get_errno(), 'cannot become child subreaper')
    sensors = package_sensors()
    counters = sorted(Path('/sys/devices/system/cpu').glob('cpu*/thermal_throttle/*throttle_count'))
    if not counters:
        raise RuntimeError('no throttle counters')

    def sample():
        row = snapshot(sensors, counters)
        row['disk_free_bytes'] = shutil.disk_usage(prefix.parent).free
        entries = [line.split() for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')]
        if len(entries) != 1 or len(entries[0]) != 3 or entries[0][2] != 'kB':
            raise RuntimeError('invalid MemAvailable telemetry')
        row['mem_available_bytes'] = int(entries[0][1]) * 1024
        if row['mem_available_bytes'] < 0:
            raise RuntimeError('negative MemAvailable telemetry')
        row['power_profile'] = subprocess.check_output(
            ['powerprofilesctl', 'get'], text=True, timeout=0.4).strip()
        return row

    def validate(row, gap):
        if row['disk_free_bytes'] < min_disk_free_bytes:
            raise RuntimeError(f'disk free {row["disk_free_bytes"]} bytes below floor {min_disk_free_bytes}')
        if row['mem_available_bytes'] < min_available_bytes:
            raise RuntimeError(f'available memory {row["mem_available_bytes"]} bytes below floor {min_available_bytes}')
        if gap > MAX_SAMPLE_GAP:
            raise RuntimeError(f'sampling gap {gap:.3f}s > {MAX_SAMPLE_GAP}s')
        if max(row['package_C'].values()) >= MAX_TEMP_C:
            raise RuntimeError(f'package temperature reached {max(row["package_C"].values())} C')
        if set(row['epp'].values()) != {'balance_power'}:
            raise RuntimeError('EPP must remain balance_power')
        if row['power_profile'] != 'balanced':
            raise RuntimeError('power profile must remain balanced')
        if start and row['epp'] != start['epp']:
            raise RuntimeError('EPP inputs changed')
        if start and row['cpu0_throttle_counts'] != start['cpu0_throttle_counts']:
            raise RuntimeError('thermal-throttle counters changed')

    def discover_descendants():
        for descriptor, _ in exited.poll(0):
            exited.unregister(descriptor)
            pid = owners.pop(descriptor)
            owned.pop(pid, None)
            os.close(descriptor)
        pending = [os.getpid()]
        seen = set(pending)
        while pending:
            parent = pending.pop()
            for thread in (Path('/proc') / str(parent) / 'task').glob('*'):
                try:
                    children = (thread / 'children').read_text().split()
                except FileNotFoundError:
                    continue
                for child_text in children:
                    child = int(child_text)
                    if child in seen:
                        continue
                    seen.add(child)
                    if child not in owned:
                        try:
                            descriptor = os.pidfd_open(child)
                            owned[child] = descriptor
                            owners[descriptor] = child
                            exited.register(descriptor, select.POLLIN)
                        except ProcessLookupError:
                            continue
                    pending.append(child)

    def send_owned(sig):
        for descriptor in list(owned.values()):
            try:
                signal.pidfd_send_signal(descriptor, sig)
            except ProcessLookupError:
                pass

    def terminate_group():
        if process is None:
            return
        # Freeze forks, discover any children created during the preceding scan,
        # then signal only pidfds obtained through our own descendant tree.
        while True:
            discover_descendants()
            count = len(owned)
            send_owned(signal.SIGSTOP)
            discover_descendants()
            if len(owned) == count:
                break
        send_owned(signal.SIGTERM)
        send_owned(signal.SIGCONT)
        time.sleep(0.2)
        send_owned(signal.SIGKILL)

    def observe():
        nonlocal latest, last_sample, rows
        try:
            with prefix.with_suffix('.telemetry.jsonl').open('w') as stream:
                while not stop.is_set():
                    row = sample()
                    now = time.monotonic()
                    gap = now - last_sample
                    row['sample_gap_s'] = gap
                    stream.write(json.dumps(row, sort_keys=True) + '\n')
                    stream.flush()
                    latest = row
                    rows += 1
                    validate(row, gap)
                    last_sample = now
                    stop.wait(INTERVAL)
        except Exception as error:
            failures.append(str(error))

    status = 1
    try:
        start = sample()
        validate(start, 0)
        last_sample = time.monotonic()
        with prefix.with_suffix('.log').open('w') as log:
            process = subprocess.Popen(args.command[1:], start_new_session=True,
                                       stdout=log, stderr=subprocess.STDOUT)
            observer = threading.Thread(target=observe, daemon=True)
            observer.start()
            while process.poll() is None:
                discover_descendants()
                if time.monotonic() - last_sample > MAX_SAMPLE_GAP:
                    failures.append('watchdog: no validated sample within 2 seconds')
                if failures:
                    terminate_group()
                    break
                time.sleep(0.05)
            status = process.wait()
            if status != 0:
                terminate_group()
            end = sample()
            validate(end, time.monotonic() - last_sample)
            latest = end
    except BaseException as error:
        failures.append(f'{type(error).__name__}: {error}')
        terminate_group()
    finally:
        stop.set()
        verdict = dict(command=args.command[1:], exit_code=status, failures=failures,
                       start=start, end=latest, samples=rows, interval_s=INTERVAL,
                       max_gap_s=MAX_SAMPLE_GAP, max_temp_C=MAX_TEMP_C,
                       min_available_bytes=min_available_bytes, min_disk_free_bytes=min_disk_free_bytes)
        prefix.with_suffix('.verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')
        print(json.dumps(dict(prefix=str(prefix), exit_code=status, failures=failures, samples=rows)))
        for descriptor in owned.values():
            os.close(descriptor)
    return 1 if failures else status


if __name__ == '__main__':
    raise SystemExit(main())

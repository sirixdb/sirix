#!/usr/bin/env python3
"""Fail-closed thermal/throttle guard, adapted from the repository rig observer.

The guarded command is the only process group this wrapper creates.  Any invalid
sensor read, missed sample deadline, package temperature >= 90 C, or increase in
cpu0 thermal-throttle counters terminates that group and returns failure.
"""
import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

INTERVAL = 0.5
MAX_SAMPLE_GAP = 2.0
MAX_TEMP_C = 90.0


def read_int(path: Path) -> int:
    value = path.read_text(encoding="ascii").strip()
    if not value or any(char not in "-0123456789" for char in value):
        raise RuntimeError(f"invalid integer sensor input: {path}={value!r}")
    return int(value)


def package_sensors() -> list[Path]:
    sensors: list[Path] = []
    for type_path in sorted(Path("/sys/class/thermal").glob("thermal_zone*/type")):
        if type_path.read_text(encoding="ascii").strip() == "x86_pkg_temp":
            sensor = type_path.parent / "temp"
            if sensor.is_file():
                sensors.append(sensor)
    if not sensors:
        raise RuntimeError("no readable x86 package-temperature sensor")
    return sensors


def throttle_paths() -> list[Path]:
    paths = sorted(Path("/sys/devices/system/cpu/cpu0/thermal_throttle").glob("*throttle_count"))
    if not paths:
        raise RuntimeError("no cpu0 thermal-throttle counters")
    return paths


def policy_snapshot() -> dict[str, str]:
    paths = sorted(Path("/sys/devices/system/cpu").glob("cpu*/cpufreq/energy_performance_preference"))
    if not paths:
        raise RuntimeError("no CPU EPP policy inputs")
    return {str(path): path.read_text(encoding="ascii").strip() for path in paths}


def snapshot(sensors: list[Path], counters: list[Path]) -> dict[str, object]:
    temperatures = {str(path): read_int(path) / 1000.0 for path in sensors}
    throttle = {str(path): read_int(path) for path in counters}
    if not temperatures or any(not (-20.0 <= value <= 150.0) for value in temperatures.values()):
        raise RuntimeError(f"invalid temperature sample: {temperatures}")
    return {
        "epoch": time.time(),
        "monotonic": time.monotonic(),
        "package_C": temperatures,
        "cpu0_throttle_counts": throttle,
        "epp": policy_snapshot(),
    }


def stop_group(process: subprocess.Popen[bytes]) -> None:
    if process.poll() is not None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
        process.wait(timeout=5)
    except (ProcessLookupError, subprocess.TimeoutExpired):
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--log", required=True, type=Path)
    parser.add_argument("--verdict", required=True, type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if not args.command or args.command[0] != "--":
        parser.error("command must follow --")
    command = args.command[1:]
    sensors = package_sensors()
    counters = throttle_paths()
    expected_epp = policy_snapshot()
    start = snapshot(sensors, counters)
    start_counts = start["cpu0_throttle_counts"]
    args.log.parent.mkdir(parents=True, exist_ok=True)
    args.verdict.parent.mkdir(parents=True, exist_ok=True)
    process = subprocess.Popen(command, start_new_session=True)
    stop = threading.Event()
    failure: list[str] = []
    last_monotonic = time.monotonic()

    def observe() -> None:
        nonlocal last_monotonic
        with args.log.open("w", encoding="utf-8") as output:
            while not stop.is_set():
                try:
                    row = snapshot(sensors, counters)
                    now = time.monotonic()
                    gap = now - last_monotonic
                    row["sample_gap_s"] = gap
                    output.write(json.dumps(row, sort_keys=True) + "\n")
                    output.flush()
                    last_monotonic = now
                    if gap > MAX_SAMPLE_GAP:
                        raise RuntimeError(f"sampling stalled for {gap:.3f}s")
                    if max(row["package_C"].values()) >= MAX_TEMP_C:
                        raise RuntimeError(f"package temperature reached {max(row['package_C'].values()):.1f} C")
                    if row["cpu0_throttle_counts"] != start_counts:
                        raise RuntimeError("thermal-throttle counter incremented")
                    if row["epp"] != expected_epp:
                        raise RuntimeError("CPU EPP policy changed")
                except Exception as error:  # fail closed on every observer error
                    failure.append(str(error))
                    stop_group(process)
                    return
                stop.wait(INTERVAL)

    observer = threading.Thread(target=observe, name="jsonbench-thermal-guard")
    observer.start()
    return_code = process.wait()
    stop.set()
    observer.join(timeout=MAX_SAMPLE_GAP + 1.0)
    if observer.is_alive() and not failure:
        failure.append("observer did not stop within promised cadence")
        stop_group(process)
    verdict = {"command": command, "exit_code": return_code, "failure": failure,
               "start": start, "end": snapshot(sensors, counters),
               "interval_s": INTERVAL, "max_sample_gap_s": MAX_SAMPLE_GAP,
               "max_temperature_C": MAX_TEMP_C}
    args.verdict.write_text(json.dumps(verdict, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    return 1 if failure else return_code


if __name__ == "__main__":
    sys.exit(main())

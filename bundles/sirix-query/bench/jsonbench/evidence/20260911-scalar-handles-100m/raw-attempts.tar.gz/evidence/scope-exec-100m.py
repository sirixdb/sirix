import json
from pathlib import Path
import subprocess
import sys
import time

prefix = Path(sys.argv[1])
command = sys.argv[2:]
if not command:
    raise ValueError('missing benchmark command')
relative = Path('/proc/self/cgroup').read_text().strip().split('::', 1)[1]
group = Path('/sys/fs/cgroup') / relative.lstrip('/')


def snapshot():
    names = ['memory.max', 'memory.swap.max', 'memory.current', 'memory.peak',
             'memory.events', 'memory.swap.events', 'cpu.stat']
    result = {name: (group / name).read_text().strip() for name in names}
    cpu_limits = {}
    for ancestor in [group, *group.parents]:
        if not ancestor.is_relative_to('/sys/fs/cgroup'):
            break
        maximum = ancestor / 'cpu.max'
        if maximum.exists():
            cpu_limits[str(maximum)] = maximum.read_text().strip()
    result['cpu.max.ancestors'] = cpu_limits
    return result


before = snapshot()
if before['memory.max'] != str(24 * 1024 ** 3) or before['memory.swap.max'] != '0':
    raise RuntimeError('benchmark scope must enforce 24 GiB and zero swap')
record = dict(command=command, cgroup=str(group), before=before, started=time.time())
prefix.with_suffix('.scope.json').write_text(json.dumps(record, indent=2) + '\n')
try:
    status = subprocess.run(command).returncode
    record['exit_code'] = status
finally:
    record['after'] = snapshot()
    record['finished'] = time.time()
    prefix.with_suffix('.scope.json').write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(status)

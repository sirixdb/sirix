import json
import os
import subprocess
import time

from campaign_100m import BASE, EVIDENCE, corpus, digest

target = BASE / 'ch26/ch-data-100m'
if target.exists():
    raise RuntimeError('refusing to overwrite an existing ClickHouse table')
source, input_manifest = corpus()
binary = '/var/tmp/jsonbench/clickhouse'
expected = 'd2a2611ed56bc6d1544fafe8ece7e888ae2af6e13ea7095993a5105d8c74d4f3'
if digest(binary) != expected:
    raise RuntimeError('ClickHouse binary differs from trusted provenance')
command = ['bash', str(BASE / 'source-45769b0fe/bundles/sirix-query/bench/jsonbench/clickhouse-setup.sh'),
           '100m', str(source), str(EVIDENCE / 'clickhouse-setup-bounded'), str(BASE / 'ch26')]
environment = dict(os.environ)
environment.update(SKIP_BASELINE='1', TMPDIR=str(BASE / 'tmp'))
environment.pop('FORCE', None)
environment.pop('CH_LOAD_SETTINGS', None)
record = dict(command=command, input_sha256=input_manifest['sha256'], binary_sha256=expected,
              started=time.time(), setup_only=True, ranked=False,
              settings=dict(max_threads=6, max_memory_usage=21474836480))
path = EVIDENCE / 'load-clickhouse-100m-attempt1.command.json'
path.write_text(json.dumps(record, indent=2) + '\n')
try:
    status = subprocess.run(command, env=environment).returncode
    record['exit_code'] = status
finally:
    record['finished'] = time.time()
    path.write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(status)

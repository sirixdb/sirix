"""Freeze tracked source plus explicit local changes, never pooled build outputs."""
import argparse
import json
import shutil
import subprocess
import tarfile

from campaign_100m import BASE, EVIDENCE, digest

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
args = parser.parse_args()
if not args.label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-' for c in args.label):
    parser.error('label must contain only lowercase letters, digits and hyphens')
root = BASE.parents[1]
source = BASE / ('source-' + args.label)
archive = BASE / ('source-' + args.label + '.tar.gz')
base_archive = BASE / ('source-' + args.label + '-base.tar.gz')
manifest_path = EVIDENCE / (args.label + '-source.json')
if any(path.exists() for path in (source, archive, base_archive, manifest_path)):
    raise RuntimeError('refusing to overwrite a frozen candidate')
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
changed = subprocess.check_output(
    ['git', 'ls-files', '-z', '--modified', '--others', '--exclude-standard'], cwd=root).decode().split('\0')
changed = sorted(set(path for path in changed if path))
hashes = {}
for relative in changed:
    path = root / relative
    if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(root):
        raise RuntimeError('unsupported source change: ' + relative)
    hashes[relative] = digest(path)
subprocess.run(['git', 'archive', '--format=tar.gz', '--output=' + str(base_archive), revision],
               cwd=root, check=True)
source.mkdir()
with tarfile.open(base_archive) as stream:
    stream.extractall(source, filter='data')
for relative, checksum in hashes.items():
    destination = source / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / relative, destination)
    if digest(destination) != checksum or digest(root / relative) != checksum:
        raise RuntimeError('source changed during freeze: ' + relative)
with tarfile.open(archive, 'w:gz') as stream:
    for child in sorted(source.iterdir()):
        stream.add(child, arcname=child.name)
record = dict(base_commit=revision, overrides=hashes, source=str(source), archive=str(archive),
              archive_sha256=digest(archive), base_archive_sha256=digest(base_archive))
manifest_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))

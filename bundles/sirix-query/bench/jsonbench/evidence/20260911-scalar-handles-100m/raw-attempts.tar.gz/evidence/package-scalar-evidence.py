"""Package stable raw attempts and provenance; retain large profiler files by checksum."""
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

from campaign_100m import BASE, EVIDENCE, digest

root = BASE.parents[1]
destination = root / 'bundles/sirix-query/bench/jsonbench/evidence/20260911-scalar-handles-100m'
destination.mkdir(exist_ok=False)
directories = [
    BASE / name for name in (
        'paired-retention-100m-attempt1', 'paired-scalar-100m-attempt1',
        'paired-scalar-instrument-1m-attempt1', 'training-retention-100m-attempt1',
        'training-scalar-100m-attempt1', 'diagnose-retention-100m-attempt1',
        'diagnose-scalar-100m-attempt1', 'profile-debug-retention-100m-attempt1',
        'evidence/scalar-v1-test-results')]
files = {path for directory in directories for path in directory.rglob('*') if path.is_file()}
prefixes = (
    'load-clickhouse-100m-attempt1', 'load-sirix-100m-retention-attempt1',
    'train-retention-100m-attempt1', 'instrument-retention-100m-attempt1',
    'optimize-retention-100m-attempt1', 'freeze-instrument-retention-100m',
    'freeze-optimized-retention-100m', 'paired-retention-100m-attempt1',
    'diagnose-retention-100m-attempt1', 'build-debug-retention-100m-attempt1',
    'profile-debug-retention-100m-attempt1', 'freeze-debug-retention-100m-attempt1',
    'format-scalar-v1', 'freeze-scalar-v1', 'test-scalar-v1',
    'instrument-scalar-100m-attempt1', 'freeze-instrument-scalar-100m',
    'check-scalar-instrument-1m-attempt1', 'train-scalar-100m-attempt1',
    'optimize-scalar-100m-attempt1', 'freeze-optimized-scalar-100m',
    'paired-scalar-100m-attempt1', 'diagnose-scalar-100m-attempt1',
    'reopened-rowcount-retention-100m', 'run-native-scalar-control-25i4')
files.update(path for path in EVIDENCE.iterdir() if path.is_file() and path.name.startswith(prefixes))
names = (
    'guard-100m-storage.py', 'scope-exec-100m.py', 'prior_thermal_guard.py', 'campaign_100m.py',
    'freeze-runtime.py', 'freeze-candidate-source.py', 'scalar-lane.sh', 'format-scalar.gradle',
    'check-scalar-1m.py', 'train-scalar-100m.py', 'advance-scalar-100m.py',
    'paired-retention-100m.py', 'diagnose_native_100m.py', 'audit-scalar-paired-100m.py',
    'build-limits.gradle', 'build-debug.gradle', 'build-scalar-debug-100m.sh',
    'scalar-v1-source.json', 'scalar-v1-tests.json', 'scalar-lane-profile-selection.json',
    'scalar-instrument-1m-validation.json', 'scalar-v1-native-control-reuse.json',
    'scalar-control-bytecode.txt', 'scalar-v1-bytecode.txt',
    'training-scalar-100m-manifest.json', 'scalar-instrument-100m-runtime-manifest.json',
    'scalar-optimized-100m-runtime-manifest.json', 'source-45769b0fe.json',
    'training-retention-100m-manifest.json', 'retention-optimized-100m-runtime-manifest.json',
    'retention-instrument-100m-runtime-manifest.json', 'retention-debug-100m-runtime-manifest.json',
    'retention-debug-100m-symbols-manifest.json', 'retention-import-100m-completion.json',
    'retention-past-prior-failure-point.json', 'inbox-013-cleanup-verification.json',
    'upstream-pin.json', 'upstream-recheck-retention-100m.txt', 'active-corpus-100m.json',
    'corpus-100m-manifest.json', 'clean-corpus-100m-manifest.json',
    'compressed-corpus-100m-manifest.json', 'load-clickhouse-100m-retention.py',
    'load-sirix-100m-retention.py', 'verify_import_count.py', 'VerifyRootArrayCount.java',
    'package-scalar-evidence.py')
for name in names:
    path = EVIDENCE / name
    if not path.is_file():
        raise RuntimeError('required evidence missing: ' + name)
    files.add(path)
large = []
small = []
for path in sorted(files):
    if path.is_symlink() or not path.resolve().is_relative_to(BASE):
        raise RuntimeError('evidence escapes campaign directory')
    if path.suffix in ('.iprof', '.data', '.jfr'):
        large.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
    else:
        small.append(path)
retained = destination / 'retained-large-files.json'
retained.write_text(json.dumps(large, indent=2) + '\n')
members = []
archive = destination / 'raw-attempts.tar.gz'
with archive.open('wb') as target, gzip.GzipFile(fileobj=target, mode='wb', filename='', mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as stream:
        for path in small:
            relative = str(path.relative_to(BASE))
            stream.add(path, arcname=relative, recursive=False)
            members.append(dict(path=relative, bytes=path.stat().st_size, sha256=digest(path)))
with tarfile.open(archive) as stream:
    actual = {member.name: hashlib.sha256(stream.extractfile(member).read()).hexdigest()
              for member in stream.getmembers()}
assert actual == {row['path']: row['sha256'] for row in members}
record = dict(archive=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), files=members)
(destination / 'raw-files.json').write_text(json.dumps(record, indent=2) + '\n')
for name in ('upstream-pin.json', 'scalar-v1-source.json', 'scalar-v1-tests.json',
             'paired-retention-100m-attempt1-validation.json', 'paired-scalar-100m-attempt1-validation.json',
             'scalar-instrument-1m-validation.json', 'scalar-lane-profile-selection.json',
             'retention-import-100m-completion.json'):
    shutil.copy2(EVIDENCE / name, destination / name)
print(json.dumps(dict(archive=str(archive), members=len(members), bytes=record['bytes'],
                     sha256=record['sha256'], retained_large_files=len(large))))

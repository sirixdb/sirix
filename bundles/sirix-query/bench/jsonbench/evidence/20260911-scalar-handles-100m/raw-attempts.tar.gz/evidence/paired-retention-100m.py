#!/usr/bin/env python3
"""Local paired JSONBench measurements; always launch through the thermal guard."""
import argparse
import ctypes
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parents[1]
KIT = BASE / 'source-45769b0fe/bundles/sirix-query/bench/jsonbench'
COMMON = KIT.parent / 'common'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


evict = load_module('evict', COMMON / 'evict.py')
compare = load_module('compare', KIT / 'compare-results.py')
thermal = load_module('thermal', BASE / 'evidence/prior_thermal_guard.py')


def run(command, stem):
    start = time.monotonic_ns()
    with stem.with_suffix('.stdout').open('w') as out, stem.with_suffix('.stderr').open('w') as err:
        result = subprocess.run(['/usr/bin/time', '-v', '-o', str(stem.with_suffix('.usage.txt')), *[str(v) for v in command]], stdout=out, stderr=err)
    wall = (time.monotonic_ns() - start) / 1e9
    stem.with_suffix('.command.json').write_text(json.dumps(dict(command=[str(v) for v in command],
        exit_code=result.returncode, process_wall_s=wall), indent=2) + '\n')
    if result.returncode:
        raise RuntimeError(f'command exited {result.returncode}: {stem}')
    return wall


def cool():
    deadline = time.monotonic() + 900
    sensors = thermal.package_sensors()
    while max(thermal.read_int(p) for p in sensors) >= 55000:
        if time.monotonic() >= deadline:
            raise RuntimeError('cool gate did not reach <55 C within 900 seconds')
        time.sleep(0.5)


def resident(libc, fd, size):
    if size == 0:
        return 0
    addr = libc.mmap(None, size, evict._PROT_READ, evict._MAP_SHARED, fd, 0)
    if addr is None or addr == evict._MAP_FAILED:
        raise OSError(ctypes.get_errno(), 'mincore mapping failed')
    try:
        pages = (size + evict.PAGE_SIZE - 1) // evict.PAGE_SIZE
        vector = (ctypes.c_ubyte * pages)()
        if libc.mincore(ctypes.c_void_p(addr), size, vector) != 0:
            raise OSError(ctypes.get_errno(), 'mincore failed')
        return min(bytes(vector).translate(evict._LOW_BIT).count(1) * evict.PAGE_SIZE, size)
    finally:
        if libc.munmap(ctypes.c_void_p(addr), size) != 0:
            raise OSError(ctypes.get_errno(), 'munmap failed')


def cold_cache(root, evidence):
    libc = evict._load_libc()
    if libc is None:
        raise RuntimeError('mincore unavailable')
    rows = []
    for directory, _, files in os.walk(root):
        for name in files:
            path = Path(directory) / name
            if not path.resolve().is_relative_to(root.resolve()):
                raise RuntimeError(f'database file escapes its root: {path}')
            with path.open('rb') as file:
                fd = file.fileno()
                size = os.fstat(fd).st_size
                os.fsync(fd)
                before = resident(libc, fd, size)
                os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
                after = resident(libc, fd, size)
                rows.append(dict(file=str(path), bytes=size, resident_before=before, resident_after=after))
    evidence.write_text(json.dumps(rows, indent=2) + '\n')
    if not rows or any(row['resident_after'] for row in rows):
        raise RuntimeError(f'cache eviction did not establish fully cold files: {evidence}')


def routes(stem):
    content = stem.with_suffix('.stdout').read_text()
    lines = [line for line in content.splitlines() if line.startswith('# served:')]
    if len(lines) != 1:
        raise RuntimeError(f'missing or ambiguous route counters: {stem}')
    counters = {key: int(value) for key, value in re.findall(r'(\w+)=(\d+)', lines[0])}
    if counters.get('groupAggregates') != 1:
        raise RuntimeError(f'query was not served by one aggregate route: {stem}: {counters}')
    for key in ('numericGroupBys', 'groupSliced', 'groupDense'):
        if key not in counters:
            raise RuntimeError(f'missing {key} counter')
    return counters


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--tier', required=True)
    p.add_argument('--sirix', required=True, type=Path)
    p.add_argument('--db', required=True, type=Path)
    p.add_argument('--ch', default='/var/tmp/jsonbench/clickhouse', type=Path)
    p.add_argument('--ch-db', required=True, type=Path)
    p.add_argument('--rows', required=True, type=int)
    p.add_argument('--out', required=True, type=Path)
    p.add_argument('--tries', type=int, default=4)
    p.add_argument('--rounds', type=int, default=2)
    a = p.parse_args()
    if a.tries < 2 or a.rounds < 2:
        p.error('at least two tries and two paired rounds are required')
    a.out.mkdir(parents=True, exist_ok=False)
    queries = (KIT / 'queries.sql').read_text().splitlines()
    assert len(queries) == 5
    flags = [] if a.tier == '1m' else ['-Xmx14g', '-Xms12g', '-Dsirix.offheap.bytes=8589934592',
                                     '-Dsirix.projection.promoteMaxBytes=0']
    flags.append('-Djava.io.tmpdir=' + str(BASE / 'tmp'))
    meta = dict(protocol='jsonbench-isolated-v1', pairing='per-query AB in odd rounds, BA in even rounds',
                tier=a.tier, rows=a.rows, tries=a.tries, rounds=a.rounds,
                score='geomean((Sirix query seconds + .010) / (ClickHouse query seconds + .010))',
                cache='first attempt verified evicted files and fresh process; remaining attempts fresh processes, warm OS cache',
                setup_in_ranking=False, process_usage='GNU time -v wraps every engine process; engine-reported query duration remains the ranked latency')
    (a.out / 'protocol.json').write_text(json.dumps(meta, indent=2) + '\n')
    count = a.out / 'count'
    run([a.ch, 'local', '--path', a.ch_db, '--query', 'SELECT count() FROM bluesky'], count)
    assert int(count.with_suffix('.stdout').read_text()) == a.rows
    # Differential for each query is separate from all ranked attempts.
    for q in range(1, 6):
        stem = a.out / f'correctness-q{q}-ch'
        sql = queries[q - 1].rstrip(';') + " SETTINGS session_timezone='UTC'"
        run([a.ch, 'local', '--path', a.ch_db, '--query', sql], stem)
        ours = a.out / f'correctness-q{q}-sirix'
        dump = a.out / f'dump-q{q}'
        result = a.out / f'correctness-q{q}.json'
        run([a.sirix, a.db, '--queries', q, '--tries', 1, '--json', result, '--dump', dump, *flags], ours)
        routes(ours)
        spec = compare.SPECS[q]
        failures = compare.compare(spec, compare.read_dump(dump / f'q{q}.jsonl', spec),
                                   compare.read_reference(stem.with_suffix('.stdout'), spec), False)
        (a.out / f'differential-q{q}.json').write_text(json.dumps(failures) + '\n')
        if failures:
            raise RuntimeError(f'Q{q} differential mismatch: {failures}')
        print(f'Q{q}: exact differential MATCH', flush=True)
    raw = []
    scores = []
    for rnd in range(1, a.rounds + 1):
        matrix = {engine: [] for engine in ('sirix', 'ch')}
        for q in range(1, 6):
            for engine in (('sirix', 'ch') if rnd % 2 else ('ch', 'sirix')):
                cool()
                cold_cache(a.db if engine == 'sirix' else a.ch_db,
                           a.out / f'r{rnd}-q{q}-{engine}-eviction.json')
                attempts = []
                for attempt in range(1, a.tries + 1):
                    stem = a.out / f'r{rnd}-q{q}-{engine}-a{attempt}'
                    if engine == 'sirix':
                        output = stem.with_suffix('.result.json')
                        wall = run([a.sirix, a.db, '--queries', q, '--tries', 1, '--json', output, *flags], stem)
                        row = json.loads(output.read_text())['result'][q - 1]
                        assert len(row) == 1
                        duration = row[0]
                        route = routes(stem)
                    else:
                        sql = queries[q - 1].rstrip(';') + " SETTINGS session_timezone='UTC'"
                        wall = run([a.ch, 'local', '--path', a.ch_db, '--time', '--query', sql], stem)
                        duration = float(stem.with_suffix('.stderr').read_text().splitlines()[-1])
                        route = None
                    if not isinstance(duration, (int, float)) or not math.isfinite(duration) or duration <= 0:
                        raise RuntimeError(f'invalid timing at {stem}: {duration}')
                    item = dict(round=rnd, query=q, engine=engine, attempt=attempt,
                                seconds=duration, process_wall_s=wall, route=route)
                    raw.append(item)
                    with (a.out / 'attempts.jsonl').open('a') as stream:
                        stream.write(json.dumps(item) + '\n')
                    attempts.append(duration)
                matrix[engine].append(attempts)
                print(f'round {rnd} Q{q} {engine}: {attempts}', flush=True)
        metric = {}
        for key in ('cold', 'hot'):
            select = (lambda r: r[0]) if key == 'cold' else (lambda r: min(r[1:]))
            ratios = [(select(s) + .01) / (select(c) + .01)
                      for s, c in zip(matrix['sirix'], matrix['ch'])]
            metric[key] = dict(geometric_ratio=math.exp(sum(math.log(r) for r in ratios) / 5),
                               query_ratios=ratios,
                               sirix_sum_s=sum(select(r) for r in matrix['sirix']),
                               clickhouse_sum_s=sum(select(r) for r in matrix['ch']))
        scores.append(dict(round=rnd, result=matrix, metrics=metric))
        (a.out / 'rounds.json').write_text(json.dumps(scores, indent=2) + '\n')
    print(json.dumps(scores, indent=2), flush=True)


if __name__ == '__main__':
    main()

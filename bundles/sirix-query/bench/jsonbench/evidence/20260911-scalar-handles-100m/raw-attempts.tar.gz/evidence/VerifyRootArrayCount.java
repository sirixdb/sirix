import com.google.gson.JsonObject;
import io.sirix.access.Databases;
import io.sirix.api.Database;
import io.sirix.api.json.JsonNodeReadOnlyTrx;
import io.sirix.api.json.JsonResourceSession;
import io.sirix.cache.Allocators;
import java.nio.file.Files;
import java.nio.file.Path;

/** Campaign verification of existing structural metadata in a newly reopened resource. */
public final class VerifyRootArrayCount {
  public static void main(final String[] args) {
    if (args.length != 3) {
      throw new IllegalArgumentException("Expected database path, resource name and logical row count");
    }
    final Path databasePath = Path.of(args[0]).toAbsolutePath().normalize();
    final long expected = Long.parseLong(args[2]);
    if (!Files.isDirectory(databasePath) || expected < 0) {
      throw new IllegalArgumentException("Existing database and nonnegative row count required");
    }
    Allocators.getInstance().init(512L << 20);
    try (final Database<JsonResourceSession> database = Databases.openJsonDatabase(databasePath);
         final JsonResourceSession session = database.beginResourceSession(args[1]);
         final JsonNodeReadOnlyTrx reader = session.beginNodeReadOnlyTrx()) {
      if (!session.getResourceConfig().storeChildCount()) {
        throw new IllegalStateException("Resource does not persist authoritative child counts");
      }
      if (!reader.moveToDocumentRoot() || !reader.moveToFirstChild() || !reader.isArray()
          || reader.hasRightSibling()) {
        throw new IllegalStateException("Expected one top-level array");
      }
      final long actual = reader.getChildCount();
      final JsonObject record = new JsonObject();
      record.addProperty("database", databasePath.toString());
      record.addProperty("resource", args[1]);
      record.addProperty("revision", reader.getRevisionNumber());
      record.addProperty("array_node_key", reader.getNodeKey());
      record.addProperty("persisted_child_count", actual);
      record.addProperty("expected_rows", expected);
      record.addProperty("exact", actual == expected);
      record.addProperty("method", "Reopened read-only root-array getChildCount; no row traversal");
      System.out.println("# verified-row-count " + record);
      if (actual != expected) {
        throw new IllegalStateException("Logical input count mismatch: " + actual + " != " + expected);
      }
    }
  }
}

from pathlib import Path
import argparse
import hashlib
import json
import shutil

parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--log', required=True, type=Path)
parser.add_argument('--binary', required=True, type=Path)
parser.add_argument('--profile', type=Path)
parser.add_argument('--jdk', required=True, type=Path)
a = parser.parse_args()
base = Path(__file__).resolve().parents[1]
args = next(line for line in a.log.read_text().splitlines() if '[native-image-plugin] Args are:' in line)
classpath = args.split(', -cp, ', 1)[1].split(', ', 1)[0].split(':')
store = base / ('runtime-' + a.label)
store.mkdir()

def sha(path):
    result = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()

artifacts = []
for i, path in enumerate(classpath):
    path = Path(path)
    assert path.resolve().is_relative_to(base), path
    dest = store / (str(i) + '-' + path.name)
    shutil.copy2(path, dest)
    artifacts.append(dict(source=str(path), retained=str(dest), sha256=sha(dest)))
manifest = dict(label=a.label, binary=str(a.binary.resolve()), binary_sha256=sha(a.binary),
    native_args=args, classpath=artifacts, build_log_sha256=sha(a.log),
    jdk=str(a.jdk.resolve()), jdk_release=(a.jdk / 'release').read_text(),
    runtime_hashes={str(path.relative_to(a.jdk)):sha(path) for path in
        (a.jdk / 'bin/java', a.jdk / 'lib/modules', a.jdk / 'lib/server/libjvm.so')})
if a.profile:
    manifest['profile'] = dict(path=str(a.profile.resolve()), sha256=sha(a.profile))
(base / 'evidence' / (a.label + '-runtime-manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(label=a.label, binary_sha256=manifest['binary_sha256'], classpath_artifacts=len(artifacts))))

import json
import os
from pathlib import Path
import subprocess
import time

from campaign_100m import BASE, EVIDENCE, corpus, digest

target = BASE / 'db-100m-retention'
if target.exists():
    raise RuntimeError('refusing to overwrite an existing Sirix database')
source, input_manifest = corpus()
runtime = json.loads((EVIDENCE / 'retention-instrument-100m-runtime-manifest.json').read_text())
classpath = []
for entry in runtime['classpath']:
    if digest(entry['retained']) != entry['sha256']:
        raise RuntimeError(f'changed runtime dependency: {entry["retained"]}')
    classpath.append(entry['retained'])
jdk = BASE / 'graal-25i4'
for relative, expected in runtime['runtime_hashes'].items():
    if digest(jdk / relative) != expected:
        raise RuntimeError(f'changed GraalVM runtime: {relative}')
command = [str(jdk / 'bin/java'), '--add-opens', 'java.base/sun.nio.ch=ALL-UNNAMED',
           '--add-opens', 'java.base/java.nio=ALL-UNNAMED', '--add-modules', 'jdk.incubator.vector',
           '--enable-native-access=ALL-UNNAMED', '--enable-preview', '-Xmx12g', '-Xms10g',
           '-XX:ActiveProcessorCount=6', '-DstorageType=FILE_CHANNEL',
           '-Dsirix.til.diag=1000', '-Dsirix.pageSectionDiag=true', '-Dsirix.offheap.bytes=8589934592',
           '-XX:StartFlightRecording=settings=profile,maxsize=256m,dumponexit=true,filename='
           + str(EVIDENCE / 'load-sirix-100m-retention-attempt1.jfr'),
           '-Djsonbench.projection.incremental=true', '-Djsonbench.projection.required=true',
           '-Djava.io.tmpdir=' + str(BASE / 'tmp'), '-Duser.home=' + str(BASE / 'home'),
           '-cp', ':'.join(classpath), 'io.sirix.query.bench.jsonbench.JsonBenchLoadMain',
           str(target), str(source)]
environment = dict(os.environ)
for name in ['JAVA_TOOL_OPTIONS', '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS']:
    environment.pop(name, None)
record = dict(command=command, input_sha256=input_manifest['sha256'],
              source_commit='45769b0feee0df55d9358a11805bccbea2dc41d3', started=time.time(),
              setup_only=True, ranked=False,
              heap_reason='12 GiB heap + 8 GiB off-heap leave 4 GiB native overhead inside the 24 GiB scope')
path = EVIDENCE / 'load-sirix-100m-retention-attempt1.command.json'
path.write_text(json.dumps(record, indent=2) + '\n')
try:
    process = subprocess.Popen(command, env=environment)
    record['pid'] = process.pid
    path.write_text(json.dumps(record, indent=2) + '\n')
    proc = Path('/proc') / str(process.pid)
    with (EVIDENCE / 'load-sirix-100m-retention-progress.jsonl').open('x') as output:
        while process.poll() is None:
            progress = dict(time=time.time(), pid=process.pid)
            try:
                progress['memory'] = {line.split(':', 1)[0]: line.split(':', 1)[1].strip()
                                      for line in (proc / 'status').read_text().splitlines()
                                      if line.startswith(('VmRSS:', 'VmHWM:', 'VmSize:', 'VmSwap:', 'Threads:'))}
                for descriptor in (proc / 'fd').iterdir():
                    if descriptor.resolve() == source:
                        info = (proc / 'fdinfo' / descriptor.name).read_text().splitlines()
                        progress['compressed_position'] = int(next(line.split()[1] for line in info
                                                                    if line.startswith('pos:')))
                        progress['compressed_fraction'] = progress['compressed_position'] / input_manifest['physical_bytes']
                        break
            except (FileNotFoundError, ProcessLookupError):
                progress['process_exiting'] = True
            output.write(json.dumps(progress) + '\n')
            output.flush()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                pass
    status = process.wait()
    record['exit_code'] = status
finally:
    record['finished'] = time.time()
    path.write_text(json.dumps(record, indent=2) + '\n')
raise SystemExit(status)

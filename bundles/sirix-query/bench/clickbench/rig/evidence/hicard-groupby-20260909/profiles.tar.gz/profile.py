import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(root / 'bundles/sirix-query/bench/clickbench/rig'))
import measure
import runner

original_command = runner.command
launched = False

def command(runtime, database, **kwargs):
    global launched
    if launched:
        raise RuntimeError('profile allowance: one JVM in this invocation')
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    available = int(memory['MemAvailable'].split()[0]) * 1024
    if available < 26 << 30:
        raise RuntimeError(f'busy box: MemAvailable {available} below 26 GiB')
    argv = original_command(runtime, database, **kwargs)
    output = Path(sys.argv[sys.argv.index('--out') + 1]).resolve()
    evidence = output / 'profile-launch.json'
    with evidence.open('x') as stream:
        json.dump(dict(available_bytes=available, argv=argv, profiling_jvms=1,
                       paired_jvms=0, maximum_pairs=12), stream, indent=2)
    launched = True
    return argv + ['--dump', str(output / 'answers')]

runner.command = command
sys.exit(measure.main())

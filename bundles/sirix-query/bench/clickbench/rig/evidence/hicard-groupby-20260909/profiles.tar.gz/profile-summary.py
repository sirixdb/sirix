from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import re

p=Path('build/hicard/profile-full-02')
windows=[]
for line in (p/'diagnostic/query-boundaries.jsonl').read_text().splitlines():
    b=json.loads(line)
    m=re.search(r'# q(\d+) try (\d+): wall=([\d.]+)',b['line'])
    q,attempt,wall=int(m[1]),int(m[2]),float(m[3])
    if q in (12,14,16,18,31,32,33) and attempt in (2,3):
        windows.append(dict(query=q,attempt=attempt,wall_s=wall,end=b['received_epoch'],
                            start=b['received_epoch']-wall,samples=Counter()))
for line in (p/'samples.tsv').read_text().splitlines():
    time,thread,stack=line.split('\t')
    time=datetime.fromisoformat(time.replace('Z','+00:00')).timestamp()
    for w in windows:
        if w['start']<=time<=w['end']:
            c=w['samples']; c['total']+=1
            for name,needle in [('lookup','NumericGroupAggTable.acquire'),('table','NumericGroupAggTable'),
                                ('topk','GroupTopKSelector'),('rehash','NumericGroupAggTable.rehash'),
                                ('spill','GroupTableSpill.spillStripes'),
                                ('string_merge','SegmentValueMerge.mergeRange')]:
                if needle in stack: c[name]+=1
            if 'NumericGroupAggTable.acquire' in stack:
                c['lookup_merge' if 'mergeStripes' in stack or 'mergePartition' in stack else 'lookup_scan']+=1
            break
pending=[]
for line in (p/'diagnostic/suite.log').read_text().splitlines():
    if 'groupAgg pass done' in line:
        pending.append(line)
    m=re.match(r'# q(\d+) try (\d+):',line)
    if m:
        for w in windows:
            if (w['query'],w['attempt'])==(int(m[1]),int(m[2])):
                w['passes']=len(pending)
                for field in ('scanMs','mergeMs','sharedRehashes'):
                    w[field]=sum(int(re.search(field+r'=(\d+)',l)[1]) for l in pending)
        pending=[]
(p/'profile-summary.json').write_text(json.dumps(windows,indent=2)+'\n')
for q in (12,14,16,18,31,32,33):
    ws=[w for w in windows if w['query']==q]
    c=sum((w['samples'] for w in ws),Counter()); total=c['total']
    print(q,'wall',round(sum(w['wall_s'] for w in ws)/2,3),'scan',sum(w['scanMs'] for w in ws)/2,
          'merge',sum(w['mergeMs'] for w in ws)/2,'passes',ws[0]['passes'],
          'samples',total,{k:round(100*v/total,1) for k,v in c.items() if k!='total'})

from collections import Counter
from datetime import datetime
import json
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
epoch = lambda text: datetime.fromisoformat(text.replace('Z', '+00:00')).timestamp()
samples = []
for line in (path / 'samples.tsv').read_text().splitlines():
    time, thread, stack = line.split('\t')
    samples.append((epoch(time), thread, stack.split(';')))
bounds = [json.loads(line) for line in (path / 'diagnostic/query-boundaries.jsonl').read_text().splitlines()]
result=[]
for b in bounds:
    match = re.match(r'# q(\d+) try (\d+): wall=([\d.]+) s', b['line'])
    q, attempt, wall = int(match[1]), int(match[2]), float(match[3])
    if q not in (12, 14, 16, 18, 31, 32, 33) or attempt == 1:
        continue
    end = b['received_epoch']
    selected = [(thread, stack) for time, thread, stack in samples if end-wall <= time <= end]
    leaf = Counter(stack[0] for thread, stack in selected)
    classes = Counter()
    inclusive = Counter()
    for thread, stack in selected:
        classes[stack[0].rsplit('.',1)[0]] += 1
        for method in {frame.split(':')[0] for frame in stack}:
            inclusive[method] += 1
    row = dict(query=q, attempt=attempt, wall_s=wall, samples=len(selected),
               threads=Counter(thread for thread, stack in selected), leaves=leaf.most_common(18),
               classes=classes.most_common(12), inclusive=inclusive.most_common(35))
    result.append(row)
    print(f'q{q} try{attempt}: {wall}s {len(selected)} samples')
    for method, count in leaf.most_common(12):
        print(f' {100*count/max(1,len(selected)):5.1f}% {method}')
(path/'sample-analysis.json').write_text(json.dumps(result,indent=2)+'\n')

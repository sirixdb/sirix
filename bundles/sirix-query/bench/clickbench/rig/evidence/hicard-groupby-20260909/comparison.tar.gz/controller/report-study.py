from collections import Counter
import csv
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import statistics
import sys
import tarfile

ROOT = Path.cwd()
RIG = ROOT/'bundles/sirix-query/bench/clickbench/rig'
sys.path.insert(0, str(RIG))
from measurement import score_result
from scipy.stats import t

source = ROOT/'build/hicard/comparison-01'
out = RIG/'evidence/hicard-groupby-20260909'
plan = json.loads((source/'plan.json').read_text())
pairs = json.loads((source/'pairs.json').read_text())
report = json.loads((source/'report.json').read_text())
assert len(pairs) == plan['planned_pairs'] == 12
assert [p['order'] for p in pairs] == plan['orders']
proofs = []
pass_records = []
cpu_gc_records = []
leg_links = []
for i, pair in enumerate(pairs, 1):
    for arm in ('baseline', 'candidate'):
        d = source/f'pair-{i:04}-{arm}'
        proof = json.loads((d/'answer-equality.json').read_text())
        assert proof['byte_identical'] is True and not proof['mismatches']
        assert len(proof['sha256']) == 44
        if proofs:
            assert proof['sha256'] == proofs[0]['sha256']
        launch = json.loads((d/'launch-allowance.json').read_text())
        assert launch['available_bytes'] >= 26 << 30
        proofs.append(dict(leg=d.name, **proof, launch=launch))
        target = RIG/'legs'/f'query-SEGHCB-P{i:02}-{arm.upper()}.json'
        raw_leg = (d/'leg.json').read_bytes()
        if target.exists():
            assert target.read_bytes() == raw_leg, f'never overwrite differing leg {target}'
        else:
            target.write_bytes(raw_leg)
        leg_links.append(str(target.relative_to(RIG)))
        pending = []
        for line in (d/'suite/suite.log').read_text().splitlines():
            if line.startswith('[groupPlan] '):
                fields = dict(re.findall(r'(\w+)=([^ ]+)', line))
                pending.append(fields)
            detail = re.match(r'# q(\d+) try (\d+): wall=([\d.]+) s cpu=([\d.]+) s .* gc=(\d+) pauses ([\d.]+) s', line)
            if detail:
                cpu_gc_records.append(dict(pair=i, arm=arm, query=int(detail[1]), attempt=int(detail[2]),
                                           wall_s=float(detail[3]), cpu_s=float(detail[4]),
                                           gc_pauses=int(detail[5]), gc_s=float(detail[6])))
            m = re.match(r'# q(\d+) try (\d+):', line)
            if m:
                for fields in pending:
                    pass_records.append(dict(pair=i, arm=arm, query=int(m[1]), attempt=int(m[2]), **fields))
                pending = []
assert sorted(p['launch']['leg'] for p in proofs) == list(range(1, 25))
scored = [(score_result(p['baseline']['result'], plan['protocol']['board_best_hot']),
           score_result(p['candidate']['result'], plan['protocol']['board_best_hot'])) for p in pairs]
critical = t.ppf(.975, 11)

def interval(values):
    mean = statistics.mean(values)
    half = critical * statistics.stdev(values)/math.sqrt(len(values))
    return [mean-half, mean+half]

families = {}
for name, queries in [('seven', [12,14,16,18,31,32,33]), ('composite', [16,18,31,32]), ('string', [12,14,33])]:
    differences = [sum(a['ln'][q]-b['ln'][q] for q in queries) for a,b in scored]
    families[name] = dict(queries=queries, benefit_ln=statistics.mean(differences), ci95=interval(differences),
                          baseline_hot_s=statistics.mean(sum(a['hot'][q] for q in queries) for a,b in scored),
                          candidate_hot_s=statistics.mean(sum(b['hot'][q] for q in queries) for a,b in scored),
                          paired_benefits_ln=differences)
summary = dict(allowance=dict(profiling_jvms=2, paired_jvms=24, pairs=12, remaining_pairs=0),
               all43_byte_identical_every_leg=True, families=families,
               seconds_saved_ci95=interval([a['hot_seconds']-b['hot_seconds'] for a,b in scored]),
               candidate_pass_records=pass_records, cpu_gc_records=cpu_gc_records,
               answer_proofs=proofs, leg_artifacts=leg_links)
(out/'study-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
for f in ('plan.json','report.json','report.md','queries.csv','pairs.json'):
    shutil.copyfile(source/f, out/f)

lines = ['# Bounded aggregation heap allowance: fixed paired result', '',
         f"Baseline `{plan['baseline_runtime']['source_commit']}`; candidate `{plan['candidate_runtime']['source_commit']}`.", '',
         '**Rig signs:** benefit = baseline − candidate, positive means improvement. In the table, delta = candidate − baseline, positive means regression. Rows are sorted by delta descending (regressions first).', '',
         f"{report['resolution']}: {report['reason']}", '',
         f"12 fixed balanced pairs, seed 0; C6A hot min(try2,try3) with the 0.01-second scoring floor. The 1.5-ln prespecified target is a resolution target, not the measured effect.", '',
         '| Measure | Baseline | Candidate | Benefit (baseline − candidate) |',
         '|---|---:|---:|---:|',
         f"| Suite hot seconds | {report['baseline_mean_hot_seconds']:.6f} | {report['candidate_mean_hot_seconds']:.6f} | {report['mean_seconds_saved']:+.6f} |",
         f"| Sum-ln | {report['baseline_mean_sum_ln']:.6f} | {report['candidate_mean_sum_ln']:.6f} | {report['benefit_ln']:+.6f} |", '',
         f"Paired suite benefit 95% CI: [{report['ci95'][0]:+.6f}, {report['ci95'][1]:+.6f}] ln. Seconds-saved 95% CI: [{summary['seconds_saved_ci95'][0]:+.6f}, {summary['seconds_saved_ci95'][1]:+.6f}].",
         f"Rig estimated 80%-power detectable effect: {report['detectable_ln_80pct']:.6f} ln; required pairs {report['required_pairs']}, conservative requirement {report['conservative_required_pairs']}. No additional runs were launched.", '',
         '## Correctness and execution', '',
         'Every one of all 43 lossless answer files was byte-identical in every one of the 24 legs, including each baseline against the pre-change profile. The separate sparse SUM-ordering defect remains known and non-passing; this candidate reproduces the same wrong bytes, as documented in SUM_ORDERING_DEFECT.md. It was not fixed or hidden by this lever.', '',
         'Local validation: 89 passing tests, one explicitly skipped known-defect test. Synthetic allocation failure and incorrect cardinality estimates recovered through the existing abort/restart path with exact answers. The probing prototype at 1703ebe2d is absent from the measured candidate.', '',
         '| Query | Baseline profile passes | Predicted candidate | Candidate hot-pass counts (frequency across 24 tries) | Candidate hot abort counts |',
         '|---|---:|---:|---|---|']
for q, before, predicted in [(16,2,1),(18,4,1),(32,7,2)]:
    records=[r for r in pass_records if r['arm']=='candidate' and r['query']==q and r['attempt'] in (2,3)]
    assert len(records)==24, (q,len(records))
    counts=Counter(int(r['passes']) for r in records)
    aborts=Counter(int(r['aborts']) for r in records)
    lines.append(f'| q{q} | {before} | {predicted} | {dict(sorted(counts.items()))} | {dict(sorted(aborts.items()))} |')
lines += ['', 'Baseline pass counts come from the unchanged baseline profile; the new optional compact plan summary is available only in the candidate. Both runtime manifests carry the same diagnostic property. Fewer passes do not divide lookup work by the old pass count: range filtering already rejects other partitions before probing. Larger tables can increase cache misses, and the paired result above is the evidence of payoff.', '', '## Family effects', '', '| Family | Baseline seconds | Candidate seconds | Benefit ln | Paired 95% CI ln |', '|---|---:|---:|---:|---|']
for name,f in families.items():
    lines.append(f"| {name} | {f['baseline_hot_s']:.6f} | {f['candidate_hot_s']:.6f} | {f['benefit_ln']:+.6f} | [{f['ci95'][0]:+.6f}, {f['ci95'][1]:+.6f}] |")
lines += ['', '## Every query, sorted by delta', '', '| Query | Baseline s | Candidate s | Delta s | Baseline ln | Candidate ln | Delta ln |', '|---|---:|---:|---:|---:|---:|---:|']
for q in sorted(report['queries'], key=lambda r:-r['benefit_ln'], reverse=True):
    lines.append(f"| q{q['query']} | {q['baseline_hot_s']:.6f} | {q['candidate_hot_s']:.6f} | {q['candidate_hot_s']-q['baseline_hot_s']:+.6f} | {q['baseline_ln']:.6f} | {q['candidate_ln']:.6f} | {-q['benefit_ln']:+.6f} |")
lines += ['', '## Supplied DuckDB reference', '',
          'DuckDB values are the supplied 20-leg per-query medians from this laptop at 50 W; no DuckDB run was performed. Sirix values here are means of the rig hot selector across 12 candidate legs, so this is a reference comparison, not a new paired cross-engine study.', '',
          '| Query | Candidate s | Supplied DuckDB s | Candidate / DuckDB | Remaining parity gap ln |',
          '|---|---:|---:|---:|---:|']
lookup = {r['query']:r for r in report['queries']}
for q,duck in [(12,.333),(14,.392),(16,.819),(18,1.514),(31,.507),(32,1.904),(33,1.734)]:
    ours = lookup[q]['candidate_hot_s']
    lines.append(f'| q{q} | {ours:.6f} | {duck:.3f} | {ours/duck:.3f} | {math.log((.01+ours)/(.01+duck)):+.6f} |')
lines += ['', '## CPU and GC diagnostics', '',
          'These are means across both hot tries in every leg (24 observations per arm), rather than the min-of-two selector used for scoring. GC pause durations are wall-time diagnostics, not a decomposition of total CPU time.', '',
          '| Query | Baseline CPU s | Candidate CPU s | Baseline GC s | Candidate GC s | Baseline GC pauses | Candidate GC pauses |',
          '|---|---:|---:|---:|---:|---:|---:|']
for q in (12,14,16,18,31,32,33):
    values = {}
    for arm in ('baseline','candidate'):
        records = [r for r in cpu_gc_records if r['query']==q and r['arm']==arm and r['attempt'] in (2,3)]
        assert len(records)==24, (q,arm,len(records))
        values[arm] = {field:statistics.mean(r[field] for r in records) for field in ('cpu_s','gc_s','gc_pauses')}
    a,b = values['baseline'],values['candidate']
    lines.append(f"| q{q} | {a['cpu_s']:.3f} | {b['cpu_s']:.3f} | {a['gc_s']:.3f} | {b['gc_s']:.3f} | {a['gc_pauses']:.2f} | {b['gc_pauses']:.2f} |")
lines += ['', '## Envelope, artifacts and remaining allowance', '',
          'Every 100M JVM ran under the rig exclusive lease, with MemAvailable >= 26 GiB immediately before launch, one benchmark JVM, the unchanged -Xms6g -Xmx14g heap, 10 GiB arena and canonical 5 GiB eager budget. Both MSR power limits were checked at 50 W; platform-managed domains are retained in the telemetry and rig report. No DuckDB run or database/corpus write occurred.', '',
          f"Observed power summary: `{json.dumps(report['observed_power'], sort_keys=True)}`.", '',
          'Two profile JVMs and 12 paired comparisons consumed this task allowance. **Remaining paired allowance: zero, including no-mistakes fix agents and verifiers.** Any further 100M run needs Firstmate authorization.', '',
          'The original leg documents are committed under rig/legs/query-SEGHCB-P*.json. Raw logs, telemetry, commands, answer proofs and frozen-runtime manifests are archived with SHA-256 member verification. Runtime binaries are reproducible from the recorded commits and dependency/JDK hashes. profiles.tar.gz preserves the pre-change JFR recordings and analysis inputs.', '']
(out/'RESULT.md').write_text('\n'.join(lines))
print('Report and all 24 leg artifacts written; all equality and allowance checks passed.')

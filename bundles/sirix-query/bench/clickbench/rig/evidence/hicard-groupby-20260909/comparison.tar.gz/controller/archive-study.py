from pathlib import Path
import hashlib
import json
import tarfile

root = Path.cwd()
source = root/'build/hicard/comparison-01'
out = root/'bundles/sirix-query/bench/clickbench/rig/evidence/hicard-groupby-20260909'
assert len(json.loads((source/'pairs.json').read_text())) == 12
files = []
for p in source.rglob('*'):
    if not p.is_file():
        continue
    rel = p.relative_to(source)
    if 'source' in rel.parts:
        continue
    if 'frozen' in rel.parts and p.name != 'runtime.json':
        continue
    files.append((p, str(rel)))
for name in ('comparison-driver.log','report-study.py','archive-study.py','baseline-origin-test.log','prototype-origin-test.log'):
    p = root/'build/hicard'/name
    if p.is_file():
        files.append((p, 'controller/'+name))
files.sort(key=lambda pair:pair[1])
assert len(files) < 1500
assert all(p.stat().st_size < 50_000_000 for p,_ in files)
archive = out/'comparison.tar.gz'
assert not archive.exists(), 'never replace a raw archive'
manifest = {}
with tarfile.open(archive,'w:gz',compresslevel=6) as tf:
    for p,name in files:
        tf.add(p,arcname=name,recursive=False)
        manifest[name] = dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
with tarfile.open(archive) as tf:
    for name,entry in manifest.items():
        data = tf.extractfile(name).read()
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
(out/'comparison-manifest.json').write_text(json.dumps(dict(archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),members=manifest),indent=2)+'\n')
print(f'Archived and verified {len(files)} raw files, {archive.stat().st_size} compressed bytes')
